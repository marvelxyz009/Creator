# Tái sinh Tề Thiên

## Chương 1 · Ngày đá biết đau

Hắn tỉnh lại vì không thở được.

Ngực bị ép chặt, hai cánh tay mắc trước mặt. Muốn duỗi chân cũng không có chỗ. Hắn quẫy trong bóng tối, đầu gối thúc phải một lớp vỏ cứng; từ chỗ ấy, tiếng rạn chạy lên sát tai.

Một khe sáng hé ra. Gió lùa vào, lạnh buốt và tanh mùi biển. Hắn dồn hết sức đạp thêm lần nữa.

Vỏ đá bật tung. Cả khối tròn bọc lấy hắn lăn khỏi hõm đá; vừa gặp gió, lớp vỏ còn lại đã tách ra. Hắn ngã sấp giữa những mảnh vụn, ho sặc sụa, hai tay quào trên mặt đá nóng.

Không khí tràn vào phổi. Hắn nằm như thế một lúc, thở đến đau cả ngực mới dám ngẩng đầu.

Một luồng sáng chói lòa qua mắt khiến hắn vội cúi xuống. Khi những đốm trắng trước mặt tan dần, biển hiện ra dưới chân núi, xanh thẫm đến tận chân trời. Sóng vỡ quanh các cột đá đỏ; xa hơn một chút, mây thấp mắc giữa những chóp núi, che khuất từng mảng rừng.

Trước mắt hắn đáng lẽ phải là một màn hình. Bên cạnh màn hình có cốc nước uống dở. Điện thoại vừa rung, hay đã rung từ lâu? Càng cố nhớ, những hình ảnh ấy càng rời rạc. Tiếng xe ngoài cửa sổ, một cái tên trên màn hình, ngón tay chưa kịp chạm vào nút nghe.

Rồi chẳng còn gì.

Hắn chống tay ngồi dậy, định nhìn xem người có bị thương không. Ánh mắt vừa chạm xuống mu bàn tay đã dừng lại.

Lông. Một lớp lông vàng nâu mọc từ cổ tay xuống tận các ngón.

Hắn lật bàn tay, sờ lên mặt. Đầu ngón chạm phải cái mõm nhô ra, rồi lớp lông ngắn phủ hai bên má. Sau lưng, có thứ vừa quét qua đá. Hắn ngoái lại; một cái đuôi dài cong lên theo động tác ấy.

Nắm lấy nó, kéo nhẹ, hắn lập tức nhăn mặt.

Của mình thật.

Hắn bật dậy. Ít nhất, hắn đã định bật dậy như một con người. Nhưng hai bàn chân quá dài, trọng tâm lại dồn về phía trước. Chưa đứng thẳng được, hắn đã ngã ngồi xuống một mảnh đá, đau đến ứa nước mắt.

Lần này hắn không vội đứng nữa.

Phía sau là khối đá lớn đã nứt toác. Những lỗ nhỏ rải quanh mặt đá, còn ở giữa là một hõm rỗng phủ bụi trắng. Hắn nhìn khối đá, nhìn biển, rồi cúi xuống lớp lông trên ngực mình.

Khỉ sinh ra từ đá.

Một cái tên vốn chẳng liên quan gì đến đời hắn bỗng trở nên gần đến đáng sợ.

*Tôn Ngộ Không?*

Hắn ngẩng nhìn trời. Ngoài vài con chim bay vòng trên bãi đá, không có gì khác. Không tiếng chuông, không ai xuống giải thích. Gió vẫn thổi; dưới kia, biển cứ đập vào chân núi.

Hắn đưa tay vuốt mặt lần nữa. Cái mõm vẫn còn đó.

Nếu thật sự là Ngộ Không, nơi này hẳn là Hoa Quả Sơn. Hắn sẽ tìm được một cái động sau thác, làm vua của đàn khỉ, vượt biển tìm Bồ Đề rồi học phép trường sinh. Sau đó còn gậy Như Ý, Long Cung, Thiên Đình…

Nghĩ đến Ngũ Hành Sơn, hắn vô thức co vai.

Năm trăm năm dưới một ngọn núi. Chỉ cần tưởng tượng không trở mình được trong một đêm, hắn đã thấy khó chịu. Năm trăm năm ấy tuyệt đối không thể cứ thế rơi xuống đầu mình.

Hắn nhìn về phía rừng. Trước hết phải tìm thác. Có nơi trú rồi mới tính chuyện ra biển; tìm được thầy càng sớm, hắn càng có thời gian chuẩn bị.

Một ý nghĩ khác chen vào. Thạch hầu vốn do tinh hoa trời đất sinh ra, biết đâu chỉ cần ngồi xuống đã có thể luyện công?

Hắn thử xếp bằng. Đuôi mắc dưới mông, chân phải không chịu nằm yên, còn trong đầu thì trống trơn. Những câu từng nghe trên phim chỉ nhớ được đôi chữ. Đôi chữ ấy không cho hắn biết phải làm gì với hơi thở đang ra vào lồng ngực.

Ngồi thêm cũng chẳng có ích. Hắn gỡ cái đuôi ra, chống tay lên đá rồi chậm rãi đứng dậy. Hai chân vẫn loạng choạng, nhưng khi hơi cúi người và để đuôi duỗi ra sau, hắn giữ được thăng bằng.

Thử bước một bước, rồi thêm bước nữa. Đến mép bãi đá, hắn đã đi được mà không phải nhìn xuống chân.

---

Đường xuống núi không khó tìm. Những khe đá nhỏ dẫn vào rừng, nơi bóng cây che mát và mùi đất thay dần mùi muối. Hắn men theo một lối giữa bụi rậm, thỉnh thoảng phải dừng lại gỡ gai khỏi lông.

Thân thể này khỏe hơn hắn tưởng. Chỉ hơi nhún chân đã nhảy qua được một gốc cây; khổ nỗi, cú nhảy xa quá khiến hắn chúi vào bụi lá bên kia. Lần sau hắn co chân ít hơn, đáp trúng phiến đá mình đã chọn. Cái đuôi tự vung ra để giữ người lại.

Hắn quay nhìn khoảng cách vừa vượt qua. Nếu trước kia, chắc phải lấy đà mới nhảy nổi.

Đang định thử lần nữa thì từ dưới rừng vọng lên một tiếng gọi gấp. Hắn chưa từng nghe thứ tiếng ấy, nhưng lại hiểu ngay lời cảnh báo.

*Đừng xuống!*

Một con khỉ đực nhảy lên cành thấp ngay trước mặt. Nó có bộ lông nâu sẫm, vành tai trái mất một mẩu. Vừa trông thấy hắn, nó khựng lại, bàn tay vẫn nắm cành phía trên, mắt liếc về đỉnh núi.

— Tiếng động trên ấy là gì?

Hắn định trả lời như thường lệ, nhưng tiếng phát ra khỏi miệng là một chuỗi âm ngắn và lạ. Con khỉ kia vẫn hiểu. Chính hắn cũng nghe ra nghĩa của chúng.

— Đá vỡ.

— Ngươi ở đó à?

Hắn phủi bụi trắng trên ngực.

— Vừa ra khỏi đó.

Con tai sứt nhìn hắn thêm một cái. Chưa kịp hỏi tiếp, nó đã quay phắt xuống dưới khi tiếng gọi lại vang lên. Lần này có cả tiếng đá lở.

Hắn chạy theo.

Qua vài bụi cây, mặt đất bỗng mở ra thành một khe sâu. Một cây lớn đứng sát bờ, rễ bò qua các kẽ đá rồi thòng xuống vách. Đất dưới gốc cây vừa sụp một mảng, để lộ lớp đá nhẵn bên trong.

Một khỉ con nằm co trên gờ đá phía dưới. Gờ chỉ vừa đủ chỗ cho nó; mỗi lần nó cựa, sỏi lại tuột khỏi chân, lăn mất vào bóng tối. Từ chỗ hắn đứng xuống đó khoảng hai thân khỉ. Còn từ gờ tới đáy khe, hắn không muốn đoán.

Khỉ mẹ lông nâu đỏ đang nằm sấp trên bờ, cố với xuống. Phía sau, một khỉ cái già giữ chặt chân bà, kéo ngược lại.

— Lùi lên! Bờ còn lở đấy!

Khỉ mẹ chẳng buồn nghe, cứ gọi con:

— Con ơi! Nhìn mẹ này!

Khỉ con ngẩng đầu, kêu lên. Bàn tay nhỏ xíu cào trên đá nhưng không tìm được chỗ bám.

Con tai sứt lao tới một mỏm đất nhô ra gần gờ hơn.

— Để ta xuống.

Nó vừa đặt chân lên, đất đã trượt. Hắn túm cánh tay kéo nó lại, đúng lúc mỏm đất rời khỏi bờ, đập vào vách rồi vỡ tung.

— Ngươi làm gì thế? — Nó giằng tay.

Hắn chỉ xuống chỗ vừa lở.

— Muốn rơi cùng nó à?

Con tai sứt còn định nói, nhưng dưới chân khỉ con có tiếng rạn. Cả hai cùng quay lại. Một vết nứt mới chạy ngang gờ đá.

Hắn nhìn quanh tìm đường xuống. Bên trái, một lối đất chắc chạy khỏi mép khe rồi vòng lên sườn núi. Xa xa giữa lá cây có một dải trắng mờ; có thể là thác nước hắn đang tìm.

Chỉ cần đi theo lối ấy, hắn sẽ rời được chỗ này.

Khỉ mẹ vẫn không với tới con. Bàn tay bà quờ xuống rồi lại phải chống lên bờ đang rã, mỗi lần như thế khỉ con đều chồm về phía mẹ. Sớm muộn gì nó cũng trượt.

Hắn nhìn dải trắng lần nữa, rồi quay về gốc cây.

— Rễ nào bám chắc?

Khỉ già ngẩng đầu. Lông bà bạc xám, hai bàn tay vẫn ghì cổ chân khỉ mẹ.

— Cái lớn bên trái. Đừng nắm cái vỏ trắng.

Hắn kéo thử rễ bên trái. Lá trên cây rung lên, mấy hạt đất rơi ra từ vách, nhưng gốc rễ không nhúc nhích. Hắn dồn sức kéo thêm lần nữa.

— Ngươi giữ chỗ này giúp ta.

Con tai sứt nhìn xuống khỉ con, rồi bò lên một rễ ngang phía trên, chèn chân vào chạc rễ. Nó ôm đoạn rễ thòng sát gốc cây, thúc hắn:

— Xuống đi. Đưa nó lên ta đỡ.

Khỉ mẹ chồm tới định theo. Khỉ già kéo bà về phía đất chắc sau gốc cây.

— Sang đây đón con. Ngươi đứng trên đầu nó, đất lại rơi xuống.

Hắn bám rễ, xoay người ra ngoài vách. Gió từ đáy khe tạt lên làm lông trên ngực dựng cả lên. Đến lúc chân rời khỏi bờ, hắn mới thấy hai bàn tay mình ướt mồ hôi.

Rơi từ đây xuống thì thạch hầu có sống nổi không?

Hắn không muốn thử.

Bàn chân trái tìm được một chỗ lồi trên vách. Chân phải kẹp rễ; hắn dồn thử trọng lượng lên đó, thấy giữ được mới hạ tay xuống. Cứ thế, từng chút một, hắn xuống ngang gờ đá.

Khỉ con lập tức nhào tới.

— Khoan!

Đã muộn. Hai bàn tay nhỏ chộp lấy cổ tay phải hắn, kéo cả người lệch sang bên. Chân trái tuột khỏi chỗ bám. Vai trái va mạnh vào vách, đau đến tối sầm mắt.

Khỉ con treo ở tay hắn, chân cào loạn. Trên đầu, con tai sứt siết rễ, chửi một tiếng. Hắn cắn răng giữ tay trái, quờ chân tìm lại điểm tựa. Vỏ rễ cứa sâu vào lòng bàn tay phải.

— Lên vai ta! Đừng bám tay!

Khỉ con càng bấu chặt hơn. Hắn cúi xuống sát nó, nhưng cái cổ tay đang chịu cả sức nặng khiến ngón tay tê dần.

Tiếng khỉ mẹ vang lên từ trên bờ:

— Con, ôm cổ! Như bám mẹ ấy!

Nó nhìn lên. Một bàn tay rời khỏi cổ tay hắn, nắm lấy lông ngực, rồi bàn tay còn lại cũng buông. Nó trèo qua vai trái, vòng chân quanh cổ hắn. Chỗ vừa đập vào đá đau nhói, nhưng bàn tay phải đã nhẹ đi.

Hắn giữ người sát vách, chờ nó bám chắc rồi mới nhấc tay phải lên cao hơn. Da trong lòng bàn tay đã rách; máu làm rễ trơn hơn mỗi lần hắn đổi chỗ nắm.

Phải đưa nó lên trước khi tay mất sức.

Hắn đạp vào vách, kéo người lên một đoạn. Trên rễ ngang, con tai sứt thò tay xuống, nhưng khoảng cách vẫn còn quá xa. Hắn nhấc chân phải, kẹp vào khúc rễ cao hơn và kéo tiếp.

Gờ đá dưới họ gãy lìa.

Khỉ con siết cổ hắn. Hơi thở mắc lại trong ngực. Hắn không nhìn xuống; ngay trước mắt là bàn tay đang chìa ra của con tai sứt. Chỉ cần lên thêm một chút.

Những ngón tay nâu sẫm cuối cùng cũng khóa vào cẳng tay hắn.

— Buông một tay ra! Ta giữ được!

— Giữ rễ. Đỡ nó trước.

Con tai sứt lùi chân sâu vào chạc, đổi chỗ bám. Hắn rướn vai cho khỉ con với lên. Khỉ mẹ đã nằm đợi phía sau gốc cây; vừa chộp được cánh tay con, bà liền kéo nó vào lòng, còn con tai sứt đỡ chân nó qua rễ ngang.

Tiếng khóc nấc vang trên bờ. Hắn nghe mà biết ít nhất khỉ con đã thoát.

Tay phải gần như không còn cảm giác. Hắn bám bằng tay trái, dùng chân đẩy người lên; tới gần mép thì con tai sứt túm lông sau lưng kéo thêm. Hắn bò qua rễ ngang rồi nằm vật dưới gốc cây, thở hổn hển.

Máu từ lòng bàn tay nhỏ xuống lá khô. Vai trái vừa cử động đã đau.

Con tai sứt ngồi bên cạnh, cũng đang thở dốc.

— Ngươi nặng hơn ta tưởng.

Hắn nằm thêm một lúc mới đủ hơi đáp:

— Ta cũng chưa biết mình nặng thế.

Nó cúi nhìn hắn. Hắn khép mắt, để mặc nó nhìn. Chuyện sinh từ đá cứ để sau; lúc này, ngay việc ngồi dậy cũng phải tính.

---

Khỉ già trở lại với một nắm lá mềm.

— Bà ơi, tay nó chảy máu nhiều quá — con tai sứt nói, nhường chỗ cho bà. Bà gỡ bụi quanh vết rách, đặt lá sạch vào tay hắn rồi khép các ngón lại.

— Ép lấy. Đừng mở ra xem mãi.

Hắn giữ bàn tay sát ngực. Lá mát, một lúc sau máu mới thấm ra ngoài, chậm hơn trước. Khỉ mẹ ngồi cách đó vài bước, ôm con trong lòng; khỉ con thỉnh thoảng giật mình, lại dụi mặt sâu hơn vào bụng mẹ.

Khỉ mẹ nhìn sang hắn. Bà cúi đầu khẽ, rồi bẻ một quả xanh đặt bên cạnh.

Hắn nhận bằng tay trái. Vị chua làm quai hàm tê đi, nhưng vừa nuốt miếng đầu đã nhận ra mình đói đến thế nào. Hắn ăn gần hết quả, chỉ bỏ lại phần sát hạt.

Con tai sứt đang phủi đất trên đùi bị khỉ già gọi lại:

— Lần sau đừng đứng lên mép ấy.

— Hôm qua ta vẫn đứng ở đó.

— Hôm qua có đứa nào rơi đâu.

Nó ngậm miệng. Hắn nhìn hai con khỉ, bỗng thấy cuộc cãi vã ấy quen hơn tất cả những gì đã gặp từ lúc ra đời.

Khỉ già gọi bầy. Những con trốn trong tán cây lần lượt xuống: khỉ lớn, khỉ nhỏ, vài con mẹ địu con trên bụng. Có con xuống đến nơi vẫn cố nhặt một quả rơi, bị giục mới vội chạy theo.

Hắn đếm được mười bảy con, rồi một tiếng gọi từ trên cành khiến phải ngẩng lên đếm lại.

Khỉ già tới trước mặt hắn.

— Ngươi đi với đàn nào?

Hắn nhìn về đỉnh núi đã khuất sau cây.

— Chưa có đàn.

Bà chờ thêm, nhưng hắn không biết giải thích thế nào mà khỏi bị xem là vừa ngã hỏng đầu.

— Vậy theo chúng ta. Còn đi được chứ?

Hắn chống tay trái đứng dậy. Chân hơi run, nhưng đã đỡ nhiều. Bà nhìn bàn tay phải hắn đang ôm trước ngực, rồi chỉ về lối bên trái.

— Đi sau ta. Thấy ta vòng chỗ nào thì vòng theo. Đừng chạy như thằng tai sứt kia.

— Ta có chạy đâu! — Tiếng phản đối vọng xuống từ một cành cây.

Khỉ già chỉ liếc lên. Con tai sứt tụt xuống một cành thấp hơn, chờ bầy đi qua rồi mới theo.

Hắn bước sau bà, thỉnh thoảng phải quay bàn tay để chỗ rách khỏi cọ vào ngực. Nếu đúng là Ngộ Không, thương tích này hẳn chẳng đáng gì so với những thứ sẽ phải chịu sau này. Nhưng hắn vẫn ước lúc kéo khỉ con lên, mình đã chọn được chỗ nắm khác.

Làm sao học phép càng sớm càng tốt? Hắn nghĩ lại đến câu hỏi ấy khi đàn khỉ bắt đầu leo lên một dốc thấp. Trong ngực có hơi ấm lan ra sau khi ăn, nhưng hắn không biết đó là linh khí hay chỉ vì vừa đỡ đói. Công pháp chưa có; ngay đến phương hướng vượt biển cũng mới là mấy dòng nhớ mang máng.

Khỉ già dừng trước một thân cây nghiêng về phía khe. Trên vỏ cây có ba vết cào dài, cao hơn đầu bà. Bà ngửi rồi kéo con tai sứt khỏi lối bên phải, dẫn cả đàn vòng qua một tảng đá chẻ đôi.

Hắn ghi nhớ tảng đá, nhớ cả bụi quả đỏ bên cạnh mà không con nào hái. Chỗ này không có trong trí nhớ về Tây Du. Từng lối đi, từng thứ ăn được, hắn vẫn phải học lại từ đầu.

---

Đến vũng nước, khỉ già đột ngột đứng lại.

Con tai sứt nhảy xuống tảng đá bên bờ, cúi người rồi cũng dừng. Hắn bước tới sau nó và thấy đáy vũng đã lộ ra, lá mục dính thành mảng trên lớp bùn đen. Chỉ ở chỗ sâu nhất còn một hõm nước đục, nổi đầy xác côn trùng.

— Sáng còn nước mà. — Con tai sứt nhìn ngược lên lòng suối.

Khỉ già cúi sờ bùn. Lớp mặt đã se, nhưng bên dưới còn mềm. Bà xua mấy khỉ nhỏ đang muốn xuống uống, đẩy chúng về phía các con mẹ.

Hắn nhìn vệt ẩm trên đá. Nước trước đó cao hơn rất nhiều; chẳng biết vì sao lại rút nhanh đến thế.

Ngay cạnh hõm nước cuối cùng có một dấu chân lớn. Hắn xòe tay trái bên cạnh để so, thấy dấu ấy rộng hơn cả bàn tay. Đầu mỗi ngón hằn một lỗ nhọn, nước đang rịn trở lại một trong những lỗ đó.

Chưa cũ.

Hắn nhìn lên bờ, tìm được dấu thứ hai đè trên lá và một cành thấp vừa gãy. Mặt gãy còn sáng màu. Dấu chân hướng ngược lên lòng suối, nhưng hai dấu ấy chưa đủ cho hắn đoán con vật đi một mình hay theo đàn.

Con tai sứt đã nhặt một hòn đá.

— Ta lên xem.

Khỉ già chắn trước mặt nó.

— Không đi một mình. Đến cây gãy thì quay về.

Hắn ngẩng lên. Cách đó không xa, một thân cây đổ ngang suối; bên kia, lòng suối khuất sau các tảng đá lớn.

Khỉ con lại kêu. Mẹ nó đang dỗ, nhưng nó cứ với tay về phía vũng. Mấy con nhỏ khác cũng nhìn hõm nước, bị giữ lại thì bắt đầu nhốn nháo.

Hắn có thể hỏi khỉ già về dải trắng mình thấy trên sườn núi. Nếu là thác, có lẽ nước ở đó chưa cạn. Nhưng bà biết lối quanh đây, còn hắn mới chỉ nhìn được từ xa; muốn đem cả đàn đi, trước hết cũng phải biết có đường tới nơi hay không.

— Ta đi cùng nó — hắn nói.

Khỉ già nhìn chiếc lá đã thấm máu trong tay hắn.

— Leo được nữa không?

— Chỉ xem rồi về. Chỗ nào phải leo thì để nó lên.

Con tai sứt xoay hòn đá trong tay.

— Nếu gặp con để lại dấu này?

Hắn nhìn những lỗ móng cạnh vũng nước.

— Chạy. Đừng ném đá vào nó.

Khỉ già chìa tay. Con tai sứt chần chừ một lát mới đặt hòn đá vào đó.

— Xem nước chảy đi đâu — bà dặn. — Đừng qua cây gãy.

Con tai sứt bước vào lòng suối trước. Hắn theo sau, tránh chạm bàn tay phải xuống đá, mắt nhìn hai bên bờ tìm thêm dấu chân. Khi tới một đoạn đá trơn, hắn đợi nó đi qua rồi mới đặt chân vào đúng chỗ nó vừa đứng.

Phía sau vẫn còn tiếng gọi khát nước của lũ khỉ nhỏ. Hắn quay lại, thấy khỉ mẹ bẻ phần quả còn sót, đưa cho con ngậm.

Hắn siết chiếc lá trong tay, bước tiếp.

Công pháp, trường sinh, Thiên Đình… những việc ấy chưa đi đâu cả. Nhưng trước khi trời tối, hắn cần biết nước ở ngọn núi này đã chảy về đâu.


# Tái sinh Tề Thiên

## Chương 2 · Đàn khỉ không chờ vua

Lòng suối cạn đi lên dốc, mỗi đoạn lại hẹp thêm một chút.

Con tai sứt đi trước, nhảy từ tảng đá này sang tảng đá khác như thể chân nó tự biết chỗ nào chắc. Hắn theo sau, chậm hơn nhiều. Bàn tay phải vẫn ôm trước ngực, nên mỗi lần phải bám, hắn chỉ còn tay trái, hai bàn chân và cái đuôi. Cái đuôi ấy giờ đã chịu nghe lời hơn lúc mới ra khỏi đá; lúc hắn chao người trên một hòn đá tròn, nó tự quấn lấy mỏm đá bên cạnh, giữ hắn lại trước khi hắn kịp nghĩ.

— Đi chậm thế thì tối mất. — Con tai sứt ngoái lại, đứng chờ trên một tảng đá cao.

— Ngươi có hai tay.

— Ngươi có cái đuôi dài hơn ta.

Hắn không cãi nữa. Nói thêm câu nào cũng phải thở, mà leo dốc thì hơi thở không thừa.

Hai bên bờ, vệt rêu khô vẽ thành một đường ngang trên đá, cao gần tới ngực hắn. Nước từng chảy đến tận đó. Giờ lòng suối chỉ còn những hốc bùn se mặt, vài con cá nhỏ nằm cứng đờ giữa lá mục. Mùi tanh bốc lên mỗi khi gió lặng.

Ở một khúc quanh, hắn dừng lại. Trên mặt bùn có thêm một dấu móng, giống hệt dấu ở vũng nước, mũi chân vẫn hướng lên thượng nguồn. Cạnh đó, trên cạnh sắc của một tảng đá, mắc vài sợi lông thô, màu sẫm như vỏ cây ướt. Hắn nhón lấy một sợi bằng tay trái. Sợi lông cứng và dài hơn ngón tay hắn, đầu hơi xoăn.

Không phải lông khỉ.

Con tai sứt nhảy xuống bên cạnh, ngửi sợi lông rồi nhăn mũi.

— Hôi.

— Ngươi từng ngửi mùi này chưa?

Nó nghĩ một lúc.

— Có thể rồi. Mùa trước, bên sườn cây cào. — Nó liếc về phía tay phải, nơi rừng dày lên thành một mảng tối. — Bà không cho tới đó.

Hắn thả sợi lông xuống, nhìn theo dấu chân. Con vật đi ngược suối, cùng hướng với dòng nước đã biến mất. Nếu nó khát, nó sẽ đi tìm nước. Nếu nó đi tìm nước, chỗ nó tới cũng là chỗ đàn khỉ cần.

Ý nghĩ ấy không làm hắn yên tâm hơn chút nào.

---

Cây gãy hiện ra khi bóng chiều đã ngả dài qua lòng suối.

Đó là một thân cây lớn đổ chéo từ bờ trái sang bờ phải, rễ bật tung lên như một bàn tay xòe ngửa, đất bám ở rễ đã khô thành tảng. Thân cây cao hơn đầu hắn, vỏ bong từng mảng. Phía bên kia, lòng suối khuất sau mấy tảng đá to như mái nhà.

Hắn vừa tới gần thì nghe thấy.

Tiếng nước. Rất khẽ, lẫn trong tiếng lá, nhưng đúng là tiếng nước chảy, đều đều ở đâu đó phía trên.

Con tai sứt cũng nghe. Tai nó vểnh lên, cả người đã nghiêng về phía thân cây.

— Có nước.

— Bà bảo đến cây gãy thì quay về.

— Bà bảo thế vì bà không biết bên kia có nước. — Con tai sứt đặt tay lên vỏ cây. — Ta qua xem rồi về ngay. Ngươi đợi ở đây.

Hắn nhìn thân cây. Trèo qua không khó, ngay cả với một tay. Bên kia có tiếng nước, và ở đâu đó trên sườn núi có dải trắng hắn đã thấy lúc đứng bên khe. Nếu đúng là thác, nếu sau thác có động, thì chỉ cần qua cây gãy là hắn đã đi được nửa đường tới thứ mình biết chắc sẽ có.

Mình biết chắc thật không?

Hắn nhớ những vết cào trên thân cây nghiêng, nhớ khỉ già đã kéo con tai sứt khỏi lối bên phải mà chẳng cần giải thích. Trong trí nhớ của hắn không có cái cây nào như thế, cũng không có dấu móng rộng hơn bàn tay. Trong trí nhớ của hắn, khỉ đá chỉ cần nhảy qua thác là thành vua.

— Không qua — hắn nói.

Con tai sứt quay lại, mắt mở to.

— Ngươi sợ à?

— Ta không biết bên kia có gì. Ngươi cũng không biết. Gặp nó ở chỗ hẹp, ngươi chạy được, ta thì chạy bằng một tay.

— Thế thì ngươi đợi.

— Rồi về nói với bà thế nào? Rằng ta đứng nhìn ngươi đi?

Con tai sứt mím miệng. Nó nhìn thân cây, rồi nhìn tay phải đang ôm lá của hắn, rồi lại nhìn thân cây.

Hắn nắm một cành chĩa ra từ thân cây đổ, kéo người lên. Tay trái gồng, chân kẹp vỏ cây, đuôi quấn quanh một mấu gỗ. Hắn không bước sang bờ bên kia, chỉ ngồi xổm trên thân cây, ở chỗ cao nhất.

Từ đó, hắn nhìn được qua mấy tảng đá lớn.

Lòng suối phía trên vẫn khô. Đá trắng bạc dưới nắng chiều, cành khô mắc thành từng đống. Xa hơn một đoạn, ở chỗ lòng suối uốn sang trái, có một vệt sáng lấp lánh. Nước. Nhưng nước không chảy xuống phía hắn. Nó rẽ ngang, đổ vào một khe đá bên phải rồi mất hút sau sườn núi.

Ngay chỗ rẽ, đá và cành cây chất thành một đống ngổn ngang, chắn ngang dòng cũ. Từ xa thế này, hắn không nhìn ra đống ấy do đất lở xuống hay do thứ gì kéo tới. Hắn chỉ thấy nó cao, và nước đã tìm đường khác.

— Thấy gì? — Con tai sứt hỏi từ dưới.

— Nước còn. Nhưng nó chảy đi chỗ khác.

— Chỗ nào?

Hắn chưa kịp trả lời thì một hòn đá lăn xuống ở phía trên, va vào đá khác, lộc cộc một hồi dài. Rồi im. Trong cái im ấy có một tiếng thở, nặng và chậm, như hơi phì ra từ một lồng ngực rất lớn.

Lông trên gáy hắn dựng đứng.

Hắn không thấy gì cả. Chỉ có đá, cành khô và bóng chiều. Nhưng tiếng thở ấy vang lên lần nữa, gần hơn, hoặc hắn tưởng là gần hơn.

Hắn tụt xuống khỏi thân cây, gần như rơi, chân đáp xuống cạnh con tai sứt.

— Về.

Lần này con tai sứt không cãi.

---

Họ về tới vũng nước khi trời đã chuyển màu tím xám.

Vũng trống trơn.

Hõm nước đục cuối cùng vẫn nằm đó, xác côn trùng vẫn nổi. Nhưng trên bờ không còn con khỉ nào. Không khỉ già, không hai mẹ con khỉ hôm qua, không lũ khỉ nhỏ kêu khát. Chỉ có dấu chân khỉ giẫm lẫn lộn trên bùn và vài vỏ quả bị vứt lại.

Hắn đứng giữa bờ vũng, nhìn quanh. Một cảm giác lạ chạy qua ngực, không hẳn là sợ. Giống như ở đời trước, đến muộn một buổi hẹn, đẩy cửa vào thì phòng đã tắt đèn.

— Đi rồi.

— Ừ. — Con tai sứt đã cúi xuống bên một bụi cây ở rìa bờ, chẳng có vẻ gì ngạc nhiên.

— Không đợi chúng ta?

— Đàn không chờ ai. — Nó nói như thể hắn vừa hỏi vì sao nước lại ướt. — Trời tối rồi. Lũ nhỏ khát.

Nó vạch một cành thấp ra cho hắn xem. Cành bị bẻ gập ngang giữa, chưa gãy hẳn, đầu cành chĩa về phía tay trái.

— Bà để lại đấy. Đi theo hướng này.

Hắn nhìn cành cây gập ấy một lúc lâu. Lúc mới ra khỏi đá, hắn còn nghĩ chuyện làm vua đàn khỉ, chuyện dẫn cả bầy vào động. Giờ cả bầy đã đi mất mà không cần hỏi ý hắn. Họ để lại cho hắn một cái cành bẻ cong, đúng như để lại cho con tai sứt, không hơn.

Hắn bật cười một tiếng, khô khốc.

— Cười gì?

— Không có gì. Đi thôi.

Đi trong rừng lúc chạng vạng khó hơn hắn tưởng. Bóng cây hòa vào nhau, rễ nổi lên chỗ nào cũng giống đá, đá chỗ nào cũng giống rễ. Con tai sứt đi trước, cứ vài chục bước lại dừng, sờ tay lên một cành cây ngang tầm mắt. Lần nào cũng thấy một cành bẻ gập. Có lần nó tìm mãi không thấy, phải đi vòng ba lượt mới gặp một bụi cỏ bị vặn xoắn ở gốc.

— Sao ngươi biết cái này là của bà? — hắn hỏi.

— Bà bẻ thấp. Con mẹ lông đỏ bẻ cao hơn, bẻ đứt luôn. — Con tai sứt lại dừng, chỉ một cành. — Kia, đứt. Con mẹ lông đỏ.

Hắn nhìn mãi mới thấy cái cành đứt ấy. Nếu chỉ có một mình, chắc giờ này hắn vẫn còn đứng ở vũng nước.

Bàn tay phải bắt đầu nhức theo nhịp tim. Lá ép đã khô, dính vào vết thương. Hắn không dám gỡ ra, chỉ siết nhẹ các ngón lại như khỉ già dặn.

---

Chỗ đàn dừng chân là một vách đá thấp dưới tán cây lớn.

Trăng mỏng đã lên, đủ để hắn thấy mặt vách phủ một lớp rêu sẫm, ẩm và bóng. Từ khe đá trên cao, nước rỉ ra thành giọt, nhỏ xuống một hõm đá dưới chân vách. Mỗi giọt rơi kêu một tiếng tách rất nhỏ. Hõm đá chỉ to cỡ vài lòng bàn tay, nước trong đó chưa đầy một ngụm.

Cả đàn ngồi quanh vách, im lặng hơn hắn từng nghe. Khỉ mẹ lông nâu đỏ đang cúi bên hõm nước, khỉ con hôm qua áp mặt cạnh mẹ, cái lưỡi nhỏ liếm liếm mặt đá ướt. Sau họ là hai con mẹ khác địu con, rồi mấy khỉ nhỏ ngồi xếp hàng không ra hàng, đứa nào cũng nhìn chằm chằm vào hõm nước.

Khỉ già ngồi trên một mỏm đá ngay cạnh vách. Thấy hai đứa về, bà chỉ nhìn qua từ đầu đến chân, như đếm xem có thiếu gì không.

— Về rồi. Ngồi đó.

Bà hất cằm về phía cuối hàng.

Hắn ngồi xuống. Cổ họng khô rát từ lúc leo dốc, càng nghe tiếng nước nhỏ giọt lại càng khát. Hắn nhìn một khỉ đực to con ngồi trước mình, nó cũng chẳng chen lên, chỉ chờ.

Mẹ trước, con nhỏ trước, rồi đến già, rồi đến đực. Kẻ mới đến ngồi cuối. Không ai nói ra luật ấy, nhưng hắn nhìn một lúc là hiểu.

Con tai sứt ngồi xuống cạnh hắn, gãi tai.

— Ngươi đi trước ta được mà — hắn nói nhỏ.

— Hôm nay ta đi xa với ngươi. Bà bảo ngồi cuối thì ngồi cuối.

Trong lúc chờ, khỉ già gọi hắn lại gần.

— Nói đi. Thấy gì?

Hắn kể. Dấu móng thứ ba, sợi lông thô, mùi hôi mà con tai sứt bảo giống mùi bên sườn cây cào. Cây gãy, tiếng nước. Chỗ nước rẽ vào khe đá bên phải, đống đá và cành ở chỗ rẽ. Tiếng đá lăn và tiếng thở.

— Thấy con vật không?

— Không.

— Đống đá ấy, ở bên này hay bên kia cây gãy?

— Bên kia. Xa hơn một đoạn.

— Ngươi có qua không?

Hắn liếc sang con tai sứt. Nó nhìn đi chỗ khác.

— Không. Ta trèo lên thân cây để nhìn.

Khỉ già im lặng một lúc. Tiếng nước tách, tách sau lưng bà.

— Được.

Chỉ một chữ. Hắn không biết bà khen hay chỉ ghi nhận, nhưng cái nhìn của bà đã bớt đi chút gì đó dè chừng.

Hắn nuốt khan, rồi nói tiếp điều đã định hỏi từ lúc ở vũng nước:

— Trên sườn núi phía kia có một dải trắng. Từ chỗ khe lúc cứu khỉ con nhìn sang. Có thể là thác. Nếu có thác thì có nước.

— Ta biết chỗ đó.

Hắn khựng lại.

— Bà biết?

— Muốn tới đó phải qua sườn cây cào. Mùa trước có hai đứa đi. — Bà nói đều đều, như kể chuyện quả chín muộn. — Một đứa về.

Bà nhìn bàn tay phải của hắn.

— Ngươi thấy từ xa. Ta đi qua rồi.

Hắn không nói được gì. Cả ngày nay hắn vẫn nghĩ dải trắng ấy là bí mật chỉ mình hắn biết, là con đường hắn sẽ dẫn đàn đi. Hóa ra bà đã biết từ trước khi hắn ra đời, và bà có lý do để không đi.

— Đá này — bà gõ ngón tay lên vách ẩm — mùa khô nào cũng khóc. Ban ngày khóc ít, ban đêm khóc nhiều. Đủ cho lũ nhỏ. Không đủ cho cả đàn lâu.

— Bao lâu?

— Đến khi rêu khô.

Hắn nhìn lớp rêu trên vách. Ở mép dưới, rêu đã ngả màu nâu.

Khi đến lượt hắn, hõm đá đã cạn gần hết. Hắn cúi xuống, liếm lớp nước mỏng còn đọng ở đáy, rồi chờ thêm ba giọt nữa mới có được một ngụm nhỏ. Nước lạnh và có vị đá. Nó không làm hết khát, nhưng cổ họng bớt rát.

Con tai sứt chờ sau hắn. Hắn nhích sang, nhường chỗ.

---

Cả đàn ngủ trên cây lớn cạnh vách.

Hắn chọn một chạc ba khá chắc, kê lưng vào thân cây, quấn đuôi quanh một cành để khỏi trượt. Con tai sứt leo lên chạc bên cạnh, cao hơn hắn một chút. Dưới kia, vẫn nghe tiếng nước tách tách.

Ngủ không được. Bàn tay nhức, vai trái đau mỗi lần cựa. Còn đầu hắn thì cứ quay về cái đống đá chắn dòng, về tiếng thở trong bóng chiều.

— Này. — Giọng con tai sứt vọng xuống. — Sao lúc ấy ngươi không qua?

— Ta nói rồi.

— Ngươi nói là không biết bên kia có gì. — Nó cựa mình, cành cây kêu cót két. — Nhưng ngươi to hơn bà. Ngươi kéo được cả ta với đứa nhỏ lên khe. Sao lại nghe bà?

Hắn nghĩ một lúc. Có rất nhiều câu trả lời. Vì trong trí nhớ của hắn chưa từng có con vật nào để lại dấu như thế. Vì hắn mới sống được một ngày. Vì nếu con tai sứt chết ở bên kia cây gãy, hắn sẽ phải nhìn khỉ già mà kể lại.

— Vì bà biết chỗ này. Ta thì không.

— Ngươi sẽ biết.

— Ừ. Nhưng chưa phải hôm nay.

Con tai sứt không nói gì nữa. Một lúc sau, hắn nghe nó trở mình, thở đều. Nó vẫn nằm ở chạc cây ấy, cách hắn chưa tới một sải tay.

Hắn nhắm mắt, thử thở như lúc mới ra khỏi đá, khi còn ngồi xếp bằng trên bãi đá. Hít vào, chậm, để không khí xuống tận bụng. Thở ra. Trong ngực vẫn có hơi ấm mơ hồ, ở đâu đó sau xương ức, nhưng chẳng biết là linh khí hay chỉ là cơ thể đang cố giữ nhiệt trong đêm. Hắn thử dồn chú ý vào chỗ ấm. Vai trái nhói lên một cái, mọi thứ tan biến.

Hắn mở mắt, nhìn lên. Qua tán lá, trời đầy sao, nhiều đến mức hắn chưa từng thấy ở đời trước.

Thác, động, thầy, phép trường sinh. Kế hoạch ấy vẫn còn đó. Chỉ là giờ nó có thêm một điều kiện mà lúc ở bãi đá hắn chưa hề nghĩ tới: đàn khỉ này phải sống được đến lúc đó. Mà muốn chúng sống, trước hết phải có nước khi rêu trên vách khô.

---

Sáng hôm sau, đàn đi kiếm ăn từ lúc sương chưa tan.

Khỉ già dẫn đầu, theo một lối hắn nhận ra là lối hôm qua: qua thân cây có ba vết cào, vòng quanh tảng đá chẻ đôi. Bụi quả đỏ vẫn ở đó, trĩu quả, đỏ au dưới nắng sớm. Đàn đi qua mà không con nào ngoái lại.

Hắn chậm bước.

Cả bụi chưa ai động tới. Trong khi các cây khác quanh đây đã bị vặt trụi tới tầm khỉ với được, bụi này vẫn nguyên. Hôm qua hắn để ý nhưng chưa nghĩ ra vì sao. Giờ bụng đói, hắn nghĩ ra một lời giải có vẻ hợp lý: có lẽ quả này mọc chỗ trống, khỉ sợ bị chim săn để ý, nên bỏ qua. Mà bỏ qua thì càng nhiều.

Hắn với tay trái, ngắt một chùm.

Bên cạnh, một khỉ nhỏ chẳng biết đã đi theo từ lúc nào, thấy hắn hái cũng lập tức chồm lên với tay vào bụi.

Một cái bóng xám lao tới. Khỉ già gạt phăng tay khỉ nhỏ, rồi đập mạnh vào cổ tay trái của hắn. Chùm quả rơi xuống đất, lăn mấy vòng.

— Ném đi.

Hắn sững người. Cả đàn đã dừng lại, quay nhìn.

— Ta chỉ…

— Ăn vào thì đau bụng. Nôn cả đêm. — Bà vẫn giữ cổ tay khỉ nhỏ, giọng không to nhưng ai cũng nghe rõ. — Năm trước một đứa ăn. Sáng ra không dậy nữa.

Khỉ nhỏ rụt tay, chạy về sau lưng một con mẹ.

Hắn nhìn chùm quả đỏ dưới đất. Mặt nóng lên dưới lớp lông. Hắn đã tự nghĩ ra cả một lý do nghe rất thông minh. Lý do ấy suýt nữa giết một đứa nhỏ chỉ biết bắt chước hắn.

— Ta không biết — hắn nói.

— Giờ biết rồi. — Bà buông tay, quay đi. — Không biết thì hỏi. Hoặc nhìn đàn ăn gì.

Con tai sứt đi ngang qua, chẳng nói gì, chỉ liếc hắn một cái. Cái liếc ấy còn khó chịu hơn một lời chê.

---

Bà dẫn đàn tới một cây lớn mọc giữa khoảng rừng thưa. Dưới gốc rụng đầy những hạt nâu to cỡ đầu ngón cái, vỏ dày và cứng.

Đàn tản ra. Khỉ lớn lùng sục quanh gốc, tìm những hạt đã nứt sẵn hoặc bị sâu đục, cạy ruột ra ăn. Khỉ nhỏ cắn thử hạt nguyên, gặm mãi không thủng, đành vứt đi. Khỉ con hôm qua cầm một hạt, xoay xoay trong tay, đưa lên miệng cắn, rồi nhăn mặt nhìn mẹ.

Hắn nhặt một hạt, bóp thử bằng tay trái. Cứng như đá cuội.

Hạt nguyên nằm đầy dưới gốc, hạt nứt sẵn thì ít. Cả đàn đang đói ngồi giữa một đống thức ăn không cắn được.

Hắn nhìn quanh. Cách gốc cây vài bước có một tảng đá phẳng, mặt hơi lõm. Hắn đi tới, đặt hạt lên chỗ lõm, rồi nhặt một hòn đá cỡ nắm tay.

Ở đời trước, hắn từng xem một đoạn phim về những con khỉ ở xa lắm, dùng đá đập hạt bên bờ sông. Hắn chỉ nhớ có thế. Không nhớ chúng cầm đá thế nào, kê hạt ra sao.

Tay phải không dùng được. Hắn ngồi xổm, dùng ngón chân trái giữ hạt cho khỏi lăn, tay trái giơ đá lên, đập xuống.

Hạt bắn ra khỏi chỗ lõm. Đá đập trúng ngón chân cái.

Hắn rít lên một tiếng, ôm chân. Mấy con khỉ gần đó ngẩng lên nhìn. Con tai sứt, đang ngồi cạy một hạt nứt dở trên cành thấp, phát ra một tiếng nghe như cười.

Hắn không nhìn lên. Nhặt hạt lại, đặt vào chỗ lõm, lần này xoay cho phần đầu nhọn chúc xuống, để chỗ lõm giữ nó. Ngón chân lùi ra xa hơn, chỉ chặn ở mép. Đập nhẹ hơn.

Cạch. Hạt chưa vỡ, nhưng đã có một vết nứt chạy dọc.

Lần thứ ba, vỏ tách đôi. Bên trong là một nhân trắng ngà, to gần bằng cả hạt.

Hắn nhặt lên, cho vào miệng. Ngậy, hơi chát ở vỏ lụa. Ngon hơn quả chua hôm qua nhiều.

Khi hắn ngẩng lên, khỉ con lông nâu nhạt đã ngồi ngay trước mặt, cách chỉ một sải tay. Hai mắt tròn xoe nhìn hòn đá trong tay hắn. Đằng sau nó, hai khỉ nhỏ khác cũng đã bò lại gần, rồi một con mẹ.

Hắn đặt thêm một hạt lên đá, đập. Lần này chỉ hai cú. Hắn bẻ đôi nhân, đưa một nửa cho nó.

Nó nhìn mẹ. Mẹ nó ngồi xuống cạnh con, không ngăn. Khỉ con cầm lấy, ngửi, rồi nhét cả vào miệng.

Sau đó thì chẳng còn ai cạy hạt sâu nữa.

Hắn đập cho đến khi cổ tay trái mỏi nhừ. Lũ khỉ nhỏ nhặt hạt nguyên mang tới, chất thành đống bên cạnh tảng đá. Mấy con lớn đứng xem một lúc rồi cũng tìm đá thử. Phần lớn đập trượt, có con đập vỡ nát cả nhân, có con giữ hạt bằng tay rồi đập trúng tay, kêu toáng lên.

Con tai sứt tụt xuống từ cành cây từ lúc nào. Nó ngồi xổm cạnh hắn, nhìn hắn đập thêm hai hạt.

— Chậm quá — nó nói. — Ta làm nhanh hơn.

— Làm đi.

Nó tìm một tảng đá khác, nhặt một hòn đá to gấp đôi hòn của hắn, đập xuống một cú. Hạt vỡ vụn, nhân văng tung tóe. Nó nhìn đống vụn, rồi nhìn hắn.

— Nhỏ tay thôi — hắn nói. — Đầu nhọn chúc xuống.

Con tai sứt hừ một tiếng. Nhưng hạt tiếp theo, nó xoay đầu nhọn xuống, đập nhẹ hơn. Vỏ tách đôi gọn gàng. Nó cầm nửa hạt lên, nhìn rất lâu như không tin.

— Dễ thế à?

— Ngươi tự làm đấy chứ.

Đến khi nắng lên quá ngọn cây, con tai sứt đã đập nhanh hơn hắn thật. Hai tay nó đều lành, nó dùng tay giữ hạt rồi rụt tay ra đúng lúc đá rơi xuống. Hắn nhìn mà vừa buồn cười vừa hơi tức.

---

Khỉ già gọi cả đàn lại quanh đống nhân hạt.

Bà chia. Không ai giành. Mẹ và con nhỏ trước, rồi đến những con già, rồi các con khác theo thứ tự hắn đã thấy ở vách đá đêm qua. Hắn ngồi cuối như đêm qua, không đòi gì.

Đến lượt hắn, bà đặt vào lòng bàn tay trái hắn một nắm nhân. Nắm ấy không nhiều hơn của con tai sứt, cũng không ít hơn. Bằng phần của một con khỉ đã làm việc cả buổi sáng.

— Mai — bà nói — ngươi với thằng tai sứt dạy lũ nhỏ đập. Ta không muốn ngón tay chúng gãy hết.

Chỉ thế. Bà không hỏi hắn từ đâu tới, cũng không gọi hắn bằng tên gì khác ngoài “ngươi”. Nhưng hắn ngồi nhìn nắm nhân trong tay khá lâu mới ăn.

Khỉ con lông nâu nhạt bò tới, ngồi sát chân hắn, chìa tay. Hắn cho nó hai hạt. Mẹ nó nhìn sang, rồi ngồi dịch lại gần thêm một chút.

---

Gần trưa, đàn quay về vách đá để uống.

Khỉ già đi trước. Đến gốc cây lớn, bà dừng lại đột ngột, giống hệt hôm qua bên bờ vũng nước. Cả đàn phía sau dồn lại.

Hắn lách lên.

Dưới chân vách, lớp bùn quanh hõm đá đã bị giẫm nát. Hõm nước khô khốc, đến đáy cũng không còn ẩm. Mép đá quanh hõm có vệt trơn bóng, như đã bị liếm đi liếm lại nhiều lần. Lớp rêu thấp nhất trên vách bị cào toạc một mảng, rủ xuống thành từng sợi.

Giữa bùn là một dấu chân. Rộng hơn bàn tay hắn, đầu mỗi ngón hằn một lỗ nhọn.

Cạnh đó, dấu thứ hai, rồi thứ ba, nối nhau đi về phía sườn cây cào, nơi rừng dày lên thành một mảng tối.

Không ai lên tiếng. Lũ khỉ nhỏ nhìn hõm đá khô, rồi nhìn mẹ. Khỉ con lông nâu nhạt kêu khẽ một tiếng.

Khỉ già cúi xuống, đặt bàn tay vào trong dấu chân. Bàn tay bà chỉ chiếm được một nửa.

— Nó cũng khát — bà nói.

Hắn nhìn những dấu chân dẫn về sườn cây cào, rồi quay lại nhìn về phía thượng nguồn, nơi hôm qua hắn đã thấy nước rẽ vào khe đá. Nước ở ngọn núi này không biến mất. Nó đã chảy sang chỗ khác.

Và giờ, thứ để lại dấu chân này cũng đang tìm nước, ở đúng những chỗ đàn khỉ cần.


# Tái sinh Tề Thiên

## Chương 3 · Nước đổi dòng

Nắng trưa rọi thẳng xuống vách đá, hong khô cả những vệt ẩm cuối cùng trên lớp rêu.

Lũ khỉ nhỏ không còn kêu nữa. Chúng nằm bẹp trên những cành thấp, bụng phập phồng, lưỡi thè ra. Khỉ con lông nâu nhạt rúc trong lòng mẹ, mắt nhắm hờ. Thỉnh thoảng khỉ mẹ lại cúi xuống liếm mặt con, như thể chút nước bọt ấy có thể thay được một ngụm nước.

Khỉ già đi một vòng quanh chân vách, ngửi từng vết cào trên rêu, rồi leo lên mỏm đá cũ ngồi im. Hắn đợi bà lên tiếng. Bà không nói gì một lúc lâu.

— Lên cây — cuối cùng bà bảo. — Chỗ nào có bóng thì nằm đó. Đêm nay đá khóc lại, ta xuống.

— Nếu nó cũng xuống? — con tai sứt hỏi.

Khỉ già không đáp. Câu hỏi ấy, ai cũng biết câu trả lời.

Hắn đứng dưới gốc cây, nhìn những dấu chân lớn in trong bùn. Chúng đi một mạch về phía sườn cây cào, không quay lại. Từ chiều hôm qua tới giờ, hắn đã thấy nước ở ngọn núi này làm gì: nó vẫn chảy, chỉ là không chảy về phía đàn khỉ nữa.

Hắn trèo lên mỏm đá, ngồi xuống cạnh khỉ già.

— Chỗ nước rẽ. Nếu dỡ được đống đá ấy, nước sẽ chảy lại xuống lòng suối cũ.

Bà quay sang nhìn hắn.

— Dỡ bằng gì?

— Bằng tay. Đống đá đó không phải đá liền, ta thấy có cả cành cây mắc vào. Rút được mấy hòn dưới đáy là nước tự xói phần còn lại.

— Ngươi thấy từ trên thân cây gãy. Ngươi chưa sờ vào nó.

— Đúng. — Hắn chỉ xuống bùn. — Nhưng con vật ấy đi về sườn cây cào rồi. Dấu chân không quay lại. Lúc này nó ở xa chỗ nước rẽ nhất.

Con tai sứt đã leo lên từ lúc nào, ngồi chồm hổm ở mép đá.

— Đi luôn đi. Đợi đến đêm thì lũ nhỏ chết khát hết.

Khỉ già nhìn những cành cây nơi lũ nhỏ đang nằm, rồi nhìn hắn, rồi nhìn con tai sứt. Bà gõ ngón tay lên mặt đá ba cái, chậm rãi.

— Ta đi cùng.

Hắn ngẩn ra. Chân bà chậm, cả đàn ai cũng biết.

— Chân ta chậm — bà nói, như đoán được ý hắn. — Mắt ta không chậm. Hai đứa đào, ta ngồi trên cao nhìn. Ta gọi ba tiếng thì bỏ hết, chạy. Không quay lại nhặt cái gì. Nghe rõ chưa?

— Rõ.

— Còn ngươi? — Bà nhìn con tai sứt.

Con tai sứt gãi cái tai khuyết.

— Rõ rồi.

Khỉ già leo xuống, đi tới chỗ con khỉ đực to con nhất đàn đang nằm trên một cành ngang. Bà nói gì đó với nó, hắn không nghe rõ. Con khỉ đực ngồi dậy, chuyển tới chỗ cao nhất trên cây, nơi nhìn được bốn phía.

---

Lần này họ qua cây gãy.

Con tai sứt chui qua khe hở dưới thân cây, chỗ thân cây gác lên một tảng đá, rồi chờ ở bên kia. Hắn chui theo, vai trái quệt vào vỏ cây đau nhói. Khỉ già không chui. Bà trèo lên thân cây, bước từng bước trên đó như đi trên một cái cầu quen, rồi tụt xuống phía bên kia.

Bên này cây gãy khác hẳn.

Dọc bờ phải lòng suối có một lối mòn rộng, đất bị nện chặt. Cỏ hai bên rạp xuống. Những cành cây ven lối bị bẻ gãy ở độ cao hơn cả đầu khỉ già, mặt gãy đã thâm màu. Một đống phân lớn nằm giữa lối, đầy hạt quả và mảnh xương nhỏ.

Khỉ già ngửi đống phân, rồi ngửi không khí. Lông trên lưng bà dựng lên một thoáng rồi xẹp xuống.

— Mùa trước cũng mùi này — bà nói rất khẽ, không rõ với ai.

Hắn không hỏi mùa trước là chuyện gì. Bà đã kể rồi: hai đứa đi, một đứa về.

Họ đi men theo lối mòn, không ai nói thêm câu nào. Tiếng nước to dần. Đến khúc lòng suối uốn sang trái, hắn thấy nó.

Từ trên thân cây gãy nhìn tới, hắn tưởng đó là một đống đá lở. Đứng gần mới biết mình nhầm.

Đá được xếp. Không ngay hàng như người xếp, nhưng hòn to nằm dưới, hòn nhỏ chèn kẽ, chắn ngang trọn lòng suối chính. Cành cây được cài vào những chỗ hở, có cành còn nguyên lá héo. Trên mặt mấy hòn đá lớn hằn những vệt trắng dài, song song: vết móng, như thứ gì đã ôm lấy hòn đá mà lăn tới đây.

Phía trên đống đá, nước dâng thành một vũng rộng, nước xanh đen, sâu đến mức không thấy đáy. Từ mép vũng, nước tràn qua một khe đá bên phải, chảy xuống một cái hõm khuất dưới vách núi. Ở đó lại có một vũng nữa, nhỏ hơn, mép vũng có một ổ lá khô bị đè bẹp, to như cái ổ của cả chục con khỉ. Quanh ổ vương vãi xương thú nhỏ.

— Nó làm cái này — con tai sứt nói, giọng lạc đi.

Hắn không đáp. Trong đầu chợt hiện lên mấy con hải ly hắn từng xem trên màn hình ở đời trước. Nhưng hải ly không có móng to như thế, cũng không đắp đập cho mình có chỗ tắm mát vào mùa khô.

Đây không chỉ là một con thú.

Khỉ già đã leo lên một mỏm đá cao ở bờ trái, nơi nhìn được cả lối mòn lẫn cái hõm có ổ lá. Bà ngồi xuống, đuôi quấn quanh chân, mắt không rời phía rừng.

— Đào đi.

---

Hắn đi một vòng quanh đống đá trước khi đụng tay.

Phía dưới, nơi nước rỉ ra qua kẽ, đá nhỏ hơn và lỏng hơn. Phía trên là mấy hòn đá to, nặng đến mức hắn không chắc cả hai đứa có đẩy nổi không. Nếu đẩy hòn to, nó sẽ lăn xuống phía mình. Nếu rút hòn nhỏ ở đáy, chỗ lòng suối cũ, nước sẽ tự tìm đường qua, mỗi lúc xói rộng thêm.

— Đừng đụng mấy hòn trên — hắn nói. — Rút cành ra trước. Rồi đến mấy hòn nhỏ dưới này.

Con tai sứt không cần bảo đến lần thứ hai. Nó leo lên đống đá, nắm một cành cây cài trong kẽ, chân chèn vào đá, giật mạnh. Cành bật ra. Nó ném xuống, nắm cành tiếp theo.

Hắn ngồi xuống chỗ thấp nhất. Tay phải không dùng được, nên hắn tì vai phải vào một hòn đá cỡ đầu mình, hai chân đạp vào hòn bên cạnh, dồn sức. Hòn đá nhích đi một chút. Đẩy lần nữa. Nó lăn khỏi chỗ, rơi tõm xuống phía dưới.

Từ chỗ trống ấy, một tia nước phụt ra, bắn vào ngực hắn. Lạnh buốt.

Hắn suýt bật cười. Từ lúc ra khỏi đá đến giờ, hắn chưa được chạm vào nhiều nước như thế.

— Thêm nữa!

Họ đào. Con tai sứt giật cành, hắn đẩy đá. Những hòn đá nhỏ có thể nhấc bằng tay trái, hắn ném xuống dòng cũ. Những hòn lớn hơn thì dùng vai, dùng chân, có lúc cả hai đứa cùng đẩy. Mỗi khi một hòn bật ra, tia nước lại to thêm, réo lên giữa các kẽ đá.

Lá ép trong tay phải đã rơi mất từ lúc nào. Vết rách bị nước lạnh táp vào, rát như có ai lấy móng cào. Hắn kệ.

Đến khi mặt trời ngả hẳn về sau núi, lỗ hổng ở đáy đã rộng bằng thân hắn. Nước không còn phụt từng tia nữa mà cuồn cuộn chảy qua, kéo theo sỏi và lá mục, đổ xuống lòng suối cũ. Mặt vũng phía trên bắt đầu hạ xuống, để lộ một vệt đá ướt quanh mép.

— Chảy rồi! — con tai sứt hét lên.

Nó nhảy lên một hòn đá phía trên, định giật thêm một cành. Hòn đá dưới chân nó chao đi.

Hắn thấy trước khi kịp nghĩ: nước đã xói rỗng phần dưới, hòn đá ấy không còn gì đỡ. Hắn chồm lên, tay trái túm lấy đuôi con tai sứt, giật mạnh về phía mình.

Cả hai ngã nhào xuống nước nông. Hòn đá lăn xuống ngay chỗ con tai sứt vừa đứng, đập vào những hòn khác, vỡ ra một mảnh.

Con tai sứt ngồi bệt trong nước, nhìn hòn đá, rồi nhìn hắn.

— Lần thứ hai rồi đấy — hắn nói, thở dốc. — Ngươi thích đứng chỗ sắp lở lắm à?

Con tai sứt chưa kịp đáp thì một tiếng gọi chói tai vọng xuống từ mỏm đá cao.

Một tiếng.

Hai tiếng.

Ba.

---

Hắn bỏ hết.

Không nhìn lại đống đá, không nhìn dòng nước. Hắn vùng dậy khỏi nước, đẩy con tai sứt về phía lối mòn, rồi chạy.

Trên mỏm đá, khỉ già đã tụt xuống, đang chạy dọc theo bờ trái về phía cây gãy. Bà chạy chậm, nhưng chạy trước. Bà đã thấy trước tất cả.

Hắn chỉ ngoái lại một lần.

Từ trong rừng phía cái hõm có ổ lá, một khối đen lù lù bước ra. Nó đi bốn chân, chậm rãi, cho tới khi nhìn thấy đống đá bị dỡ và dòng nước đang chảy xuống lòng suối cũ.

Rồi nó đứng dậy.

Đứng trên hai chân sau, nó cao gấp ba khỉ già. Lông đen thô phủ kín người, chỉ có trên ngực một vệt lông trắng cong như vầng trăng non. Hai chi trước buông thõng, mỗi móng dài bằng ngón tay hắn. Cái đầu to, tai tròn, mõm dài. Đôi mắt nhỏ, đen, nhìn qua dòng nước.

Nhìn thẳng vào hắn.

Không phải cái nhìn của con thú đang tìm mồi. Ở đời trước hắn đã thấy chó nhìn, mèo nhìn; hai ngày nay hắn đã thấy cả đàn khỉ nhìn. Cái nhìn này khác. Nó dừng lại trên mặt hắn lâu hơn cần thiết, như đang ghi nhớ.

Rồi nó gầm lên.

Tiếng gầm dội vào vách núi, dội ngược lại, làm lá cây ven suối rung lên. Hắn quay đầu chạy, không ngoái lại lần nào nữa.

Phía sau, tiếng nước bị rẽ ra, tiếng đá lăn, tiếng bốn chân nặng nề nện xuống lối mòn. Nó chạy nhanh hơn hắn tưởng. Trên đất bằng, một khối thịt to như thế lẽ ra phải chậm. Nhưng nó không chậm.

Con tai sứt chạy trước hắn hai bước. Khỉ già đã gần tới cây gãy.

— Chui dưới! — hắn hét. — Đừng trèo!

Khỉ già hiểu ngay. Bà không trèo lên thân cây như lúc đi nữa mà rạp người xuống, lách qua khe hở chỗ thân cây gác lên tảng đá. Con tai sứt chui theo. Hắn lao vào sau cùng, vai trái cà vào đá, đau đến hoa mắt, rồi bò ra phía bên kia.

Ngay sau lưng hắn, cả thân cây gãy rung lên.

Con gấu lao vào thân cây, móng cào lên vỏ, rồi chồm lên định trèo qua. Thân cây cao quá ngực nó. Nó phải bám, phải nhấc cả khối người nặng nề lên, phải tìm chỗ đặt chân sau trên vỏ cây trơn. Chỉ mất vài nhịp thở. Nhưng vài nhịp thở ấy đủ cho ba con khỉ lao vào rừng, nhảy lên cây, leo lên những cành nhỏ dần, nhỏ dần.

Hắn dừng lại ở một chạc cây mảnh, cao gần ngọn. Cành dưới chân hắn oằn xuống, run run. Con tai sứt ở cây bên cạnh. Khỉ già ở cao hơn cả hai.

Con gấu đã qua được cây gãy. Nó tới dưới gốc cây hắn đang đậu, đứng dậy, vươn một chi trước lên. Móng cào lên thân cây, cách chân hắn chưa tới hai thân khỉ. Rồi nó lắc cây. Cả thân cây rung lên, lá rơi lả tả. Hắn ôm chặt cành, đuôi quấn quanh một nhánh khác, nhắm mắt.

Cây không gãy.

Con gấu buông thân cây, gầm thêm một tiếng. Nó ngẩng nhìn hắn rất lâu.

Rồi nó quay lưng, đi về phía cây gãy. Không chạy. Đi.

Hắn mở mắt, nhìn theo cho đến khi khối đen khuất sau thân cây đổ. Hắn hiểu nó đang làm gì. Nó không phí sức với ba con khỉ trên ngọn cây. Nó về sửa chỗ hỏng.

Nước quan trọng hơn.

---

Họ về tới vũng khi trời đã chạng vạng.

Nước đã về trước họ.

Dòng suối cũ chảy lại thành một rãnh nước đục, nhỏ hơn ngày trước nhiều, nhưng đủ để lấp hõm bùn và dâng lên thành một vũng nông. Cả đàn đã ở đó. Lũ khỉ nhỏ lội cả xuống nước, té nước vào nhau, kêu chí chóe. Mấy con mẹ cúi xuống uống, hớp từng ngụm dài. Khỉ con lông nâu nhạt ngồi ngay mép vũng, uống đến nỗi bụng căng tròn, rồi ngẩng lên, nước nhỏ tong tong xuống cằm.

Hắn quỳ xuống bờ, vục mặt vào nước.

Nước có vị bùn, có vị lá mục, có cả vị máu từ bàn tay phải của hắn. Hắn uống như chưa bao giờ được uống.

Con tai sứt nằm ngửa ngay bên cạnh, nửa người ngâm trong nước, mắt nhắm, miệng toe toét.

— Nó đắp, ta phá — nó nói với bầu trời. — Xem ai chán trước.

Khỉ già ngồi trên bờ. Bà đã uống, nhưng không lội xuống. Bà nhìn dòng nước chảy tới từ phía thượng nguồn.

— Nó thấy rồi — bà nói.

Không ai đáp. Lũ nhỏ vẫn té nước.

Hắn ngồi dậy, quay sang khỉ già. Bà không nhìn hắn. Bà nhìn những cái cây quanh vũng, nhìn cái cây lớn nơi đàn hay đậu, như đang đếm lối thoát.

— Bà nghĩ nó sẽ tới đây?

— Nó thấy mặt ngươi. — Bà chậm rãi quay sang. — Nó biết đường xuống đây. Nước chảy tới đâu, nó biết.

Hắn nhớ lại đôi mắt nhỏ ấy. Cái nhìn dừng lại lâu hơn cần thiết.

---

Đêm đó đàn ngủ trên cây lớn cạnh vũng, sau khi khỉ già bắt tất cả leo lên những cành cao nhất.

Hắn không ngủ được. Bàn tay phải đã được khỉ mẹ lông nâu đỏ ép lá mới, nhưng vẫn nhức. Vai trái sưng lên một cục.

Hắn nghĩ về con gấu.

Trong trí nhớ của hắn về Tây Du, Hoa Quả Sơn là đất lành. Khỉ chơi đùa, ăn quả, nhảy vào thác rồi có vua. Không có con gấu nào đắp đập giữ nước. Không có con thú nào nhìn người ta như đang ghi nhớ một khuôn mặt. Có thể những trang sách ấy đã bỏ qua mấy chuyện vặt vãnh như thế. Có thể thế giới này vốn khác.

Dù là gì, hắn cũng không biết nó sẽ làm gì tiếp.

Nếu là Đại Thánh trong trí nhớ, chuyện này chẳng có gì đáng nghĩ. Một gậy. Có khi chẳng cần gậy, một cái búng tay. Hắn nhìn xuống bàn tay trái, xòe ra trong bóng tối. Năm ngón khỉ, móng ngắn, lòng bàn tay chai. Hôm nay bàn tay này đẩy được mấy hòn đá cỡ cái đầu, kéo được con tai sứt khỏi một hòn đá đang lăn. Thế là hết.

Hơi ấm trong ngực lại lan ra khi hắn nghĩ đến đó, mơ hồ như mọi lần. Hắn nắm chặt bàn tay lại.

Phải mạnh hơn. Nhanh hơn.

---

Sáng hôm sau, hắn bị đánh thức bởi sự im lặng.

Tiếng nước chảy đã tắt.

Hắn tụt xuống cây. Vũng nước vẫn còn, nhưng đã thấp hơn đêm qua một đốt tay. Rãnh nước dẫn từ thượng nguồn xuống chỉ còn những vũng nhỏ đứng yên, không chảy nữa.

Đàn khỉ lục tục xuống theo. Không ai té nước.

Khỉ già đứng ở bờ vũng, ngay chỗ đêm qua bà ngồi. Bà không nhìn thượng nguồn. Bà nhìn xuống chân.

Hắn bước tới, thấy ngay.

Dấu chân. Không phải một, mà rất nhiều, chồng lên nhau quanh bờ vũng, có dấu in sâu như đã đứng ở đó rất lâu. Bùn bờ vũng bị cào thành những rãnh dài, song song. Và trên thân cây lớn nơi cả đàn vừa ngủ, ở độ cao ngang đầu một con khỉ già đứng trên vai một con khác, có ba vết cào mới. Vỏ cây bị xé toạc, lộ lớp gỗ trắng bên trong, nhựa còn đang rỉ.

Nó đã tới đây trong đêm. Đứng dưới gốc cây cả đàn đang ngủ. Rồi bỏ đi.

Lũ khỉ nhỏ nép vào mẹ. Khỉ con lông nâu nhạt nhìn vết cào trên thân cây, rồi giấu mặt vào ngực mẹ.

Con tai sứt nhìn về phía thượng nguồn, hai bàn tay nắm lại.

— Nó đắp lại rồi. Ta lên phá tiếp.

— Không — khỉ già nói.

— Nhưng…

— Không. — Bà không cao giọng. — Đêm qua nó đứng đây. Ngươi đi phá, đêm nay nó trèo lên.

Con tai sứt mở miệng, rồi ngậm lại. Nó quay đi, ngồi xuống một tảng đá, lưng quay về phía đàn.

Hắn đứng nhìn ba vết cào trên thân cây. Ngày đầu tiên, trên đường tới vũng, hắn cũng đã thấy ba vết cào như thế trên một thân cây nghiêng bên sườn núi. Khi ấy khỉ già kéo con tai sứt khỏi lối bên phải mà không giải thích. Giờ hắn hiểu.

Những vết cào ấy không chỉ để mài móng.

Nó đang nói: chỗ này là của ta.

Dòng nước, vũng nước, cái cây đàn khỉ đậu. Tất cả.

Hắn nhìn đàn khỉ quanh mình, những đứa nhỏ đang nép vào mẹ, cái vũng mỗi lúc một thấp. Hôm qua hắn đã đổi được dòng nước. Chỉ một đêm. Đổi lại, con gấu đã biết mặt hắn, biết chỗ đàn ngủ.

Nếu không tìm được nước ở chỗ khác, đàn sẽ phải đi xin nước ở chỗ của nó.

Hoặc phải đủ sức để không cần xin.


# Tái sinh Tề Thiên

## Chương 4 · Lần dẫn khí đầu

Khỉ già không để đàn ở lại bờ vũng.

Ngay sáng hôm ấy, bà dẫn cả đàn lên khu rừng thấp phía đông, nơi những cây quả mọc dày và tán lá đan vào nhau thành mái. Ban ngày ở đó, tránh xa cái cây có ba vết cào. Ban đêm xuống đá khóc, uống theo lượt, luôn có hai con ngồi trên cao canh. Phần nước còn lại trong vũng cũ, bà để dành cho những đứa nhỏ nhất, chỉ cho uống lúc trưa nắng gắt, và chỉ khi khỉ đực to con đã leo lên ngọn cây nhìn quanh.

Không ai cãi. Kể cả con tai sứt.

Hắn giữ lời hứa hôm trước. Dưới gốc một cây hạt cạnh rừng quả, hắn bày ra hai tảng đá phẳng, chỉ cho lũ nhỏ cách xoay đầu nhọn xuống, cách để ngón chân xa chỗ đập. Khỉ con lông nâu nhạt là đứa chăm nhất và cũng vụng nhất. Nó đập trượt bảy lần liền, lần thứ tám thì đập trúng hạt nhưng làm nát bét cả nhân. Nó nhìn đống vụn rồi nhìn hắn, mặt như sắp khóc. Hắn bẻ cho nó nửa hạt của mình.

Tay hắn làm việc, nhưng đầu hắn ở chỗ khác.

Hắn nghĩ về đôi mắt nhỏ của con gấu, về ba vết cào trên thân cây. Về bàn tay mình xòe ra trong đêm. Về hơi ấm lan trong ngực mỗi khi hắn nghĩ đến chuyện phải mạnh hơn.

Hơi ấm ấy có từ lúc ăn quả đầu tiên. Có lúc ngồi xếp bằng trên bãi đá, có lúc nằm trên chạc cây nhìn sao. Lúc nào nó cũng mơ hồ như hơi nóng còn sót lại trong hòn đá phơi nắng. Nhưng nó không biến mất.

Nếu đó thật là linh khí, thì nơi nó rõ nhất hẳn là chỗ hắn sinh ra.

---

Rạng sáng hôm sau, hắn lẻn khỏi cây khi cả đàn còn ngủ.

Đường lên đỉnh núi dài hơn hắn nhớ. Hôm đầu tiên hắn chỉ đi xuống, vừa đi vừa ngã. Giờ đi lên, một tay ôm trước ngực, vai trái mỗi lần bám lại nhói, hắn phải dừng thở mấy lần. Đến khi lên tới bãi đá, trời phía đông đã chuyển sang màu xám bạc.

Khối tiên thạch vẫn ở đó, nứt toác như ngày đầu. Hõm rỗng ở giữa vẫn phủ bụi trắng. Hắn trèo vào hõm, ngồi xuống đúng chỗ mình đã nằm co lúc chưa ra đời. Vừa khít. Như thể đá vẫn nhớ hình dáng hắn.

Gió biển thổi lên, mặn và lạnh. Dưới chân núi, sóng đập vào những cột đá đỏ.

Hắn ngồi xếp bằng, lần này để đuôi vòng ra trước, không đè dưới mông. Hít vào, chậm. Thở ra, chậm hơn.

Lúc đầu chẳng có gì. Chỉ có gió, tiếng sóng, và cái lạnh luồn qua lớp lông. Hắn suýt bỏ cuộc như lần trước.

Rồi mặt trời nhô lên khỏi mặt biển.

Tia nắng đầu tiên chạm mép khối đá, trượt xuống, rơi vào hõm, rơi lên người hắn. Và hơi ấm trong ngực hắn cựa mình.

Hắn không biết tả thế nào khác. Nó không còn là hơi nóng sót lại trong đá nữa. Nó động. Như một dòng nước nhỏ vừa tìm thấy rãnh. Hắn hít vào, nó dâng lên. Hắn thở ra, nó chìm xuống, chậm rãi, từ sau xương ức xuống dưới, qua dạ dày, dừng lại ở chỗ thấp hơn rốn một chút. Ở đó, nó tụ thành một đốm ấm nhỏ bằng hạt quả.

Hắn mở choàng mắt.

Bụi trắng trong hõm đá quanh hắn, chỗ nắng chiếu vào, đang lay động. Không có gió trong hõm. Bụi vẫn lay động.

Hắn ngồi im không dám nhúc nhích, chỉ dám thở. Mỗi hơi thở, đốm ấm dưới rốn lại sáng thêm một chút, như than hồng được thổi.

Khi mặt trời lên cao hơn, cảm giác ấy nhạt dần. Không mất hẳn, chỉ dịu xuống thành một hơi ấm âm ỉ ở bụng. Hắn đứng dậy, hai chân run run. Không phải vì mệt.

Hắn đã cảm được nó. Không phải đoán, không phải tưởng tượng. Có thật.

Hắn phải cố lắm mới không hét lên với cả mặt biển.

---

Hắn về tới rừng quả khi đàn đã đi kiếm ăn. Không ai hỏi hắn đi đâu. Chỉ có con tai sứt, đang treo người trên một cành thấp, nheo mắt nhìn hắn.

— Ngươi đi đâu từ sáng?

— Lên núi.

— Làm gì?

— Ngồi.

Con tai sứt nhìn hắn như nhìn một hòn đá biết nói.

— Ngồi?

Hắn gật đầu, ngồi xuống cạnh đống hạt, cầm đá lên đập. Hắn không biết giải thích thế nào. Rằng có thứ gì đó chảy trong người hắn khi mặt trời mọc? Con tai sứt sẽ nghĩ hắn ăn nhầm quả đỏ.

Chiều hôm đó, con tai sứt biến mất một lúc lâu. Lúc nó quay về, lông ướt mồ hôi, nó tới thẳng chỗ hắn, ngồi xuống, nói nhỏ:

— Ta lên gần cây gãy.

Hắn ngẩng phắt lên.

— Bà cấm…

— Ta không qua. Ta trèo lên cây cao ở bờ bên này nhìn sang. — Nó dừng lại, nuốt nước bọt. — Nó đứng trên đống đá. Đắp lại cao hơn hôm trước. Nó đứng trên đó, nhìn xuống lòng suối. Nhìn rất lâu. Như đang đợi ai.

Không cần hỏi nó đợi ai.

Đêm ấy ở đá khóc, hắn ngồi canh lượt đầu cùng khỉ đực to con. Rêu trên vách khô thêm một mảng. Lũ nhỏ uống xong vẫn liếm môi.

Hắn nhìn bàn tay trái mình, nghĩ về đốm ấm dưới rốn. Một ngày. Nếu một ngày đã cảm được, thì mười ngày, hai mươi ngày?

Con gấu không đợi hai mươi ngày.

---

Rạng sáng thứ hai trên bãi tiên thạch, hơi ấm đến nhanh hơn.

Mặt trời chưa nhô hẳn, đốm ấm dưới rốn đã sáng lên. Hắn thở, nó dâng, nó chìm. Lần này hắn cảm thấy nó rõ đến mức gần như có thể chạm vào. Có thể đẩy.

Hắn nhớ mang máng trong những bộ phim cũ, người ta vận khí lên tay, đấm một cái là đá vỡ.

Hắn biết đó chỉ là phim. Hắn biết mình không có công pháp, không có thầy, ngay cả cái tên của thứ đang chảy trong người cũng không chắc. Hắn biết tất cả những điều đó.

Nhưng con gấu đang đứng trên đống đá, nhìn xuống lòng suối.

Hắn hít một hơi thật dài, và thay vì để hơi ấm chìm xuống, hắn kéo nó lên.

Nó không muốn lên. Nó nặng như kéo một xô nước từ đáy giếng. Hắn kéo mạnh hơn. Từ rốn lên ngực, từ ngực sang vai phải. Vai phải nóng ran. Xuống cánh tay. Cánh tay như có ai đổ nước ấm vào trong da. Xuống cổ tay, vào nắm tay.

Bàn tay phải nắm chặt lại, vết rách trong lòng bàn tay căng ra. Hắn không thấy đau. Hắn chỉ thấy nóng, nóng hừng hực, như cả bàn tay là một hòn than.

Trước mặt hắn, ở mép hõm đá, có một mảnh vỏ tiên thạch cỡ cái đầu.

Hắn đấm xuống.

Cạch.

Một vết nứt chạy dọc mảnh đá, từ chỗ nắm tay chạm vào đến tận mép bên kia.

Hắn nhìn vết nứt. Trong một nhịp thở, hắn thấy mình đã đúng. Hắn đã làm được.

Rồi cơn nóng quay ngược lại.

Không phải chìm xuống từ tốn như lúc trước. Nó dội ngược lên, từ nắm tay lên cổ tay, lên khuỷu tay, lên vai, như nước sôi bị ép chảy ngược trong một cái ống quá hẹp. Cả cánh tay phải hắn co giật. Các ngón tay quặp lại, không mở ra được. Vết rách trong lòng bàn tay toác ra, máu chảy tràn qua kẽ ngón.

Hắn há miệng định kêu, nhưng chỉ có tiếng ọe. Dạ dày thắt lại. Hắn nôn ra một bãi nước chua lẫn vụn hạt.

Nắng chói lóa. Bầu trời nghiêng đi. Hắn ngã ngửa ra khỏi hõm đá, lưng đập xuống bãi đá phẳng, cánh tay phải vẫn co giật bên cạnh như không còn là của mình.

Thằng ngu, hắn nghĩ. Đúng là thằng ngu.

Rồi mọi thứ tối sầm.

---

Có ai đang kéo hắn.

Hắn mở mắt, thấy một cái tai khuyết lắc lư ngay trên mặt mình. Con tai sứt đang túm lông vai trái hắn, lôi hắn xềnh xệch xuống một con dốc đá. Vai trái đau buốt.

— Thả… vai…

— Im. — Con tai sứt thở hổn hển. — Ngươi nặng như con lợn rừng.

Nó đổi sang túm lông lưng, kéo tiếp. Hắn cố dùng chân đẩy theo. Cánh tay phải vẫn co quắp trước ngực, nóng như vừa lôi từ lửa ra.

— Sao ngươi…

— Ta theo ngươi từ sáng. — Con tai sứt không nhìn hắn. — Ngươi lên núi hai sáng liền. Ta muốn xem ngươi ngồi cái gì.

Nó dừng lại, nhìn bàn tay phải đầy máu của hắn.

— Ngươi ngồi xong rồi đấm đá. Rồi ngã. Rồi nôn. — Nó nhíu mày. — Ngươi lên đó định đi luôn à?

Hắn không trả lời được. Cơn nóng lại dội lên, hắn nghiến răng, mắt tối sầm lần nữa.

---

Hắn sốt suốt cả ngày hôm ấy.

Những lúc tỉnh, hắn thấy mình nằm trên một chạc cây rộng, có lá lót bên dưới. Khỉ già ngồi cạnh. Có lúc bà đặt lá ướt lên trán hắn, lên cánh tay phải. Nước từ lá chảy xuống, mát lạnh. Hắn mơ màng nhận ra đó là nước đá khóc. Thứ nước cả đàn phải chia nhau từng ngụm.

— Đừng… phí…

— Im.

Bà cầm cánh tay phải hắn lên, áp lòng bàn tay mình vào đó. Rồi bà rụt tay lại, nhíu mày.

— Ngươi mang cái gì trong người mà nóng như đá phơi nắng?

Hắn không biết trả lời thế nào. Hắn chỉ lắc đầu.

Bà nhìn hắn rất lâu. Rồi bà lại đặt lá ướt lên tay hắn.

— Thú bị thương, con nào khôn thì nằm yên. Con nào dại thì liếm vết thương mãi, cho đến khi nó thối ra.

Bà không nói thêm. Nhưng hắn hiểu bà không chỉ nói về bàn tay.

Đêm xuống, cơn sốt lên cao hơn. Hắn mơ thấy những thứ rời rạc. Một hành lang trắng, mùi thuốc sát trùng. Một bàn tay ai đó đặt lên vai, một giọng nói, không rõ của ai, không rõ nam hay nữ: “Từ từ thôi. Vội làm gì.” Hắn muốn quay lại nhìn mặt người đó, nhưng hành lang trắng đã tan vào tiếng lá xào xạc.

Hắn tỉnh dậy lúc gần sáng. Cơn sốt đã lui. Mồ hôi ướt đẫm lông.

Khỉ già vẫn ngồi đó, mắt nhắm, nhưng khi hắn cựa mình, bà mở mắt ngay.

— Còn sống.

— Còn.

Hắn thử cử động bàn tay phải. Các ngón tay mở ra được, chậm chạp, như không phải của hắn. Hắn thử nắm lại. Chỉ nắm hờ được. Cả cánh tay tê dại từ vai xuống, như đã nằm đè lên nó suốt một đêm.

Vết rách trong lòng bàn tay toác rộng hơn trước, đã được ép lá mới.

Hắn nằm nhìn tán lá, nghe tiếng đàn khỉ thức dậy quanh mình. Trong bụng, ở chỗ thấp hơn rốn, đốm ấm vẫn còn. Nhỏ hơn, mờ hơn, nhưng vẫn còn. Nó không trách hắn. Nó chỉ nằm đó, chờ.

Từ từ thôi. Vội làm gì.

Hắn bật cười khẽ, cười đến đau cả ngực.

---

Hai ngày sau, tay phải hắn vẫn chưa cầm nổi một hạt cho chặt.

Hắn không lên núi nữa. Không phải vì sợ, mà vì khỉ già nhìn hắn mỗi khi hắn liếc về phía đỉnh núi, và cái nhìn ấy đủ để hắn ngồi yên.

Nhưng hắn không bỏ.

Hắn nghĩ lại từng bước của buổi sáng hôm ấy. Hơi ấm không muốn lên tay. Hắn đã kéo nó lên. Nó nặng, nó không vừa đường đi. Hắn đã ép nó qua. Như ép nước lũ chảy qua một rãnh nhỏ. Rãnh vỡ.

Con gấu chắn dòng, nước rẽ sang khe khác. Hắn dỡ đống đá, nước tự tìm về lòng cũ. Hắn đâu có kéo nước. Hắn chỉ dọn đường.

Hắn đặt cho mình vài luật. Không ai dạy, nên hắn tự đặt, và tự biết chúng có thể sai.

Không đẩy. Chỉ nhìn.

Không đưa nó lên tay chân. Để nó ở bụng, muốn đi đâu thì tự đi.

Thở theo bước chân khi leo, theo nhịp tay khi đập hạt. Không ngồi lì một chỗ mà ép.

Ngày đầu tiên làm theo, hắn chẳng thấy gì khác. Ngày thứ hai, khi leo lên cây quả bằng tay trái và hai chân, hắn thở theo từng lần với tay, và cảm thấy đốm ấm dưới rốn lan ra rất khẽ, như hơi ấm của nắng sớm thấm qua lông. Nó không lên tay phải. Nó lan xuống hai chân. Chân hắn bám cành vững hơn một chút. Không nhiều. Một chút.

Không đau.

Khỉ già ngồi ở cành dưới, nhìn hắn leo. Bà không hỏi. Bà chưa bao giờ hỏi.

---

Rạng sáng ngày thứ tám, khỉ già cho hắn lên núi.

Bà không nói cho phép. Bà chỉ ngồi trên cành cao nhất khi hắn tụt xuống cây trong bóng tối, và không gọi hắn lại. Con tai sứt thì đi theo, chẳng buồn giấu nữa.

— Lần này ngươi mà nôn, ta không kéo đâu.

— Lần này ta không đấm đá.

Hắn ngồi vào hõm tiên thạch. Mảnh đá bị đấm nứt vẫn nằm ở mép hõm, vết nứt đen sẫm. Hắn nhìn nó một lúc rồi quay đi.

Hít vào. Thở ra. Không kéo, không đẩy.

Mặt trời lên. Đốm ấm sáng dần, chậm hơn lần trước, như than hồng sau một đêm bị dội nước. Hắn để nó sáng theo cách của nó. Hắn chỉ ngồi đó, thở, nghe.

Nghe.

Tiếng sóng dưới chân núi. Tiếng gió lùa qua những lỗ nhỏ trên khối đá. Tiếng con tai sứt gãi tai ở bên ngoài hõm. Tiếng chim xa. Rồi những tiếng hắn chưa từng nghe thấy từ chỗ này: tiếng lá xào xạc dưới sườn núi, tiếng một cành khô gãy rất xa.

Và giữa tất cả những tiếng ấy, ở hướng tây bắc, có một tiếng khác.

Một tiếng ầm đều đều, trầm, không ngớt. Rất xa, nhỏ đến mức nếu không chú ý sẽ tưởng là tiếng sóng. Nhưng sóng thì có nhịp, lúc to lúc nhỏ. Tiếng này không có nhịp. Nó chỉ đổ xuống, đổ xuống mãi.

Nước rơi.

Hắn mở mắt, nhìn về hướng tây bắc. Từ đây chỉ thấy rừng và mây. Nhưng đó đúng là hướng của dải trắng hắn đã thấy hôm đầu tiên, khi đứng bên khe cứu khỉ con.

Hắn ngồi im thêm một lúc, cho đến khi chắc chắn tai mình không lừa mình. Rồi hắn trèo ra khỏi hõm đá.

— Xong rồi à? — con tai sứt hỏi. — Lần này không ngã.

— Không ngã.

Hắn không nói thêm. Hắn không biết mình nghe được là nhờ đốm ấm dưới rốn, hay nhờ ba buổi sáng ngồi yên trên đỉnh núi. Có thể cả hai. Có thể không cái nào. Hắn chỉ biết tiếng ấy có thật.

---

Hắn về tới rừng quả, gặp khỉ già ở chân vách đá khóc. Bà đang nhìn lớp rêu.

Hơn nửa vách đã khô, rêu ngả nâu, giòn ra như lá úa. Hõm đá dưới chân vách chỉ còn ướt một vệt ở đáy. Đêm qua, hắn nghe nói, lũ nhỏ chỉ được mỗi đứa ba ngụm. Vũng cũ thì đã cạn hẳn, chỉ còn bùn nứt nẻ.

Hắn đứng cạnh bà, chưa biết mở lời thế nào.

— Từ trên đỉnh núi — cuối cùng hắn nói — ta nghe thấy tiếng nước rơi. Ở hướng dải trắng. Nước rơi nhiều lắm, đổ mãi không ngớt.

Khỉ già không quay sang. Bà nhìn lớp rêu khô thêm một lúc lâu, lâu đến mức hắn tưởng bà không nghe.

— Ngươi nghe được thật?

— Thật.

Bà quay lại, nhìn bàn tay phải hắn vẫn cầm hờ trước ngực.

— Nắm tay lại.

Hắn nắm. Các ngón tay cong vào, run run, không khép được hẳn.

Khỉ già nhìn bàn tay ấy, rồi nhìn về hướng tây bắc, nơi phải qua sườn cây cào mới tới.

— Khi tay ngươi nắm chặt được cành — bà nói — ta đưa ngươi tới rìa sườn cây cào. Chỉ tới rìa.

Bà quay đi, để lại hắn đứng bên vách đá khô, bàn tay phải run run cố nắm lại.


# Tái sinh Tề Thiên

## Chương 5 · Đường sau thác

Sáng ngày thứ mười một, hắn nắm được cành.

Không chặt như trước. Các ngón tay phải vẫn run, và khi hắn treo cả người lên, một cơn tê chạy từ cổ tay lên tận vai. Nhưng bàn tay khép lại được, giữ được, không tuột. Hắn treo như thế mười nhịp thở, rồi buông xuống, quay lại tìm khỉ già.

Bà đã ngồi đợi ở gốc cây. Con tai sứt ngồi cạnh, đang gặm một quả xanh.

Mấy hôm nay cả đàn sống nhờ quả. Những quả mọng ở rừng phía đông đã bị vặt gần hết, những quả còn lại thì chua và ít nước. Đá khóc mỗi đêm chỉ còn rỉ vài chục giọt. Lũ nhỏ không còn chạy nhảy nữa, chỉ nằm, và ngủ rất nhiều.

Khỉ già nhìn bàn tay phải của hắn, không bảo hắn nắm lại cho bà xem. Bà chỉ đứng dậy.

— Đi.

---

Sườn cây cào không xa như hắn tưởng. Đi qua tảng đá chẻ đôi, qua bụi quả đỏ, men theo một dải đất dốc thêm một đoạn, rừng bắt đầu thưa dần. Cây ở đây to hơn, cách nhau xa hơn, tán không đan vào nhau kín như ở rừng quả.

Và cây nào cũng có vết cào.

Có vết ở ngang tầm mắt hắn, có vết cao hơn cả đầu khỉ già khi bà đứng thẳng. Có vết cũ đã liền vỏ, thành sẹo xám. Có vết mới, vỏ cây còn bong ra từng mảng. Dưới gốc cây, đất bị bới thành những hố nông, rễ cây trồi lên bị gặm nham nhở.

Mùi ở đây dày đặc. Không cần sợi lông nào để nhận ra.

Khỉ già dừng lại ở một gốc cây lớn, ngay trước chỗ rừng thưa hẳn. Bà không nhìn về phía trước. Bà nhìn xuống đám lá khô dưới chân.

Hắn nhìn theo.

Giữa lá có một bộ xương nhỏ. Xương bạc trắng, đã rời ra từng đoạn. Hắn nhận ra một cái đuôi, một bàn tay chỉ còn những đốt mảnh như que, một cái sọ to cỡ nắm tay hắn, vỡ mất một bên.

Khỉ già đứng đó rất lâu. Bà không cúi xuống, không chạm vào. Con tai sứt cũng không gặm quả nữa.

Hắn không hỏi. Hai đứa đi, một đứa về. Bà đã kể thế, và thế là đủ.

— Chỉ tới đây — cuối cùng bà nói. — Ta hứa đưa ngươi tới rìa. Đây là rìa.

Hắn nhìn về phía trước. Sườn núi chạy dốc xuống rồi lại dốc lên, rừng thưa, nhiều chỗ chỉ có cỏ và đá. Phía bên kia, xa lắm, giữa những tán cây có một dải trắng mờ.

Hắn ngồi xuống cạnh gốc cây.

— Ngươi làm gì? — con tai sứt hỏi.

— Nghe.

Hắn nhắm mắt, thở chậm. Không kéo, không đẩy. Đốm ấm dưới rốn sáng lên dần, chậm chạp như mọi sáng. Hắn để nó sáng.

Tiếng gió. Tiếng lá. Tiếng một con chim gõ kiến ở đâu đó trên sườn núi. Rồi xa hơn, ở phía tay phải, phía lòng suối và cây gãy, có tiếng đá va vào đá. Lộc cộc. Im. Rồi lại lộc cộc. Như có thứ gì đang lăn từng hòn một.

Hắn mở mắt.

— Nó ở chỗ chắn. Đang xếp đá.

Khỉ già nhìn hắn. Đây là lần đầu tiên bà nhìn hắn như thế, như nhìn một thứ không hiểu được nhưng không thể không tin.

— Ngươi nghe được từ đây?

— Được.

Bà im lặng. Hắn biết bà đang nghĩ gì. Một con khỉ ngồi xếp bằng trên đỉnh núi mỗi sáng, người nóng như đá phơi nắng, giờ lại bảo nghe được con gấu xếp đá từ bên kia sườn núi.

— Ta với nó đi bằng tán cây — hắn nói, chỉ con tai sứt. — Không xuống đất trừ khi phải. Nhìn rồi về.

— Tay ngươi.

— Nắm được cành.

Khỉ già nhìn bộ xương dưới chân thêm một lần nữa. Rồi bà ngẩng lên nhìn mặt trời, lúc ấy mới lên khỏi ngọn cây.

— Khi bóng cây ngắn nhất — bà nói — ta phải thấy hai đứa ở đây.

— Bà không đi cùng?

— Ta già. — Bà ngồi xuống gốc cây, quấn đuôi quanh chân. — Ta chờ ở đây thì còn có đứa về kể.

---

Chuyền cây ở sườn cây cào khó hơn ở rừng quả nhiều. Cây cách xa nhau, nhiều chỗ hắn phải nhảy qua những khoảng trống dài gấp đôi thân mình. Lần nào đáp xuống, tay phải cũng nhói lên. Hắn học cách để tay trái và hai chân chịu lực trước, tay phải chỉ đỡ thêm.

Con tai sứt đi trước, như mọi lần. Nó nhảy xa hơn hắn, nhanh hơn hắn, và cứ một đoạn lại dừng chờ. Không cằn nhằn. Hắn để ý thấy nó không còn chê hắn chậm nữa, từ hôm kéo hắn xuống núi.

Giữa sườn có một khoảng trống không cây. Chỉ có cỏ cao và mấy tảng đá rải rác, dài chừng năm mươi bước chân khỉ. Hai đứa dừng ở cây cuối cùng, nhìn xuống.

Cỏ bị rạp thành một lối chạy xuyên qua khoảng trống. Giữa lối có một đống phân khô.

— Chạy — hắn nói. — Không dừng.

Họ tụt xuống, chạy. Cỏ cao quá đầu, cứa vào mặt. Hắn không nghe thấy gì ngoài tiếng thở của chính mình và tiếng chân con tai sứt phía trước. Năm mươi bước dài như năm trăm. Rồi một thân cây hiện ra, hắn nhảy lên, bám, leo, tim đập thình thịch trong lồng ngực.

Không có gì đuổi theo.

Hắn ngồi trên chạc cây, thở, cười một tiếng run run. Con tai sứt ở cành trên cũng đang cười.

---

Càng đi, tiếng nước càng lớn.

Không còn là tiếng ầm xa xa như hắn nghe từ đỉnh núi. Giờ nó rền lên, át cả tiếng gió, làm lá cây quanh hắn rung nhẹ. Không khí ẩm dần, mát dần. Rêu xanh bám đầy thân cây.

Rồi rừng mở ra, và hắn thấy nó.

Một vách đá dựng đứng, cao đến mức hắn phải ngửa cổ mới thấy đỉnh. Từ đỉnh vách, nước đổ xuống thành một tấm màn trắng xóa, rộng bằng cả chục cây cổ thụ đứng cạnh nhau. Nước rơi xuống một vũng sâu dưới chân vách, nước xanh thẫm, bọt trắng tung lên thành một lớp sương mỏng. Nắng xuyên qua lớp sương, vẽ thành một dải cầu vồng mờ nhạt.

Từ vũng sâu ấy, nước chảy thành một dòng suối rộng, băng qua những tảng đá, rồi đổ về một thung lũng phía tây. Không phải về phía lòng suối của đàn khỉ.

Hắn đứng nhìn, quên cả thở.

Con tai sứt không đứng nhìn. Nó lao xuống, nhảy qua mấy tảng đá, rồi phi thẳng xuống vũng nước. Một tiếng tõm. Lát sau cái đầu tai khuyết nhô lên, nhổ phì phì, cười như điên.

— Nước! Nước nhiều chưa từng thấy!

Hắn trèo xuống, quỳ bên mép vũng, vục cả mặt vào. Nước lạnh, trong, có vị đá và vị rêu. Hắn uống đến khi bụng căng lên, rồi ngẩng đầu nhìn tấm màn nước trước mặt.

Trong sách, khỉ đá nhắm mắt, nhún người, nhảy thẳng vào thác. Rồi phát hiện sau thác không có nước, chỉ có một cây cầu.

Hắn đứng dậy, đi dọc mép vũng, tới chỗ có những tảng đá nhô sát chân thác. Từ tảng đá cao nhất, màn nước cách hắn chỉ một cú nhảy.

— Ngươi làm gì đấy? — con tai sứt gọi từ giữa vũng.

Hắn không đáp. Hắn nhún người, giống như trong sách, và nhảy thẳng vào giữa màn nước.

---

Nước đè xuống như một tảng đá.

Không phải nước rơi, mà là cả một khối nặng trĩu đập vào đầu, vào vai, vào lưng hắn, quật hắn xuống. Hắn không thấy cây cầu nào. Hắn không thấy gì cả. Chỉ có trắng xóa, tiếng gầm rú trong tai, rồi mặt vũng đập vào người như một bàn tay khổng lồ.

Hắn chìm.

Nước dưới chân thác không đứng yên. Nó xoáy, kéo hắn xuống, quay hắn như quay một chiếc lá. Hắn quẫy chân, quẫy tay trái. Tay phải không nghe lời, chỉ quờ quạng. Không biết đâu là trên, đâu là dưới. Ngực thắt lại. Hắn mở miệng định kêu, nước tràn vào.

Thằng ngu, hắn nghĩ lần thứ hai trong mấy ngày. Lần này ngu thật rồi.

Có thứ gì túm lấy đuôi hắn.

Một lực kéo mạnh, giật hắn ngược về một hướng. Hắn để mặc nó kéo. Rồi đầu hắn nhô lên khỏi mặt nước, không khí ập vào, hắn ho sặc sụa, nước phụt ra từ mũi và miệng.

Con tai sứt kéo hắn về phía mép vũng, tay kia bám vào một tảng đá. Nó đẩy hắn lên đá, rồi tự leo lên, nằm vật ra bên cạnh.

Hắn nằm sấp, ho, nôn ra cả nước lẫn quả chưa tiêu. Đầu gối xước rướm máu. Vết rách trong lòng bàn tay phải lại rỉ máu dưới lớp lá đã bị nước cuốn mất.

Khi hắn ho xong, con tai sứt vẫn nằm đó, ngửa mặt lên trời.

— Lần thứ nhất của ta — nó nói.

Hắn quay sang nhìn nó.

— Ngươi kéo ta khỏi chỗ lở hai lần. — Nó vẫn không quay sang. — Ta kéo ngươi khỏi nước một lần. Còn nợ một.

Hắn bật cười, rồi lại ho.

— Ngươi đếm à?

— Đếm chứ.

---

Hắn ngồi trên tảng đá rất lâu, nhìn tấm màn nước.

Không nhảy nữa. Lần này hắn chỉ nhìn.

Trong sách, khỉ đá nhảy qua được. Có thể sách đúng, có thể con khỉ trong sách nhảy ở một chỗ khác, có thể mùa ấy nước ít hơn. Có thể sách chỉ viết một câu cho xong. Hắn không biết. Hắn chỉ biết cái thác trước mặt hắn không phải cái thác trong sách, mà là một khối nước thật, nặng thật, suýt giết hắn thật.

Hắn thở chậm, để đốm ấm dưới rốn lắng xuống. Rồi hắn nhìn.

Màn nước ở giữa dày nhất, trắng đặc. Về phía hai bên, nó mỏng dần. Ở mép phải, nơi vách đá lồi ra một chút, nước chỉ còn là một lớp mỏng, chảy sát mặt đá, có chỗ rách ra thành từng dải.

Một con chim én lao xuống từ trên cao.

Nó không bay vào giữa thác. Nó bay sát vách, ở mép phải, chỗ nước mỏng, rồi biến mất sau lớp nước. Lát sau một con nữa. Rồi con thứ ba bay ra từ cùng chỗ ấy, vỗ cánh rũ nước, lượn lên cao.

Chim én làm tổ ở chỗ khô. Không có chỗ khô, chúng không bay vào.

— Ở đó — hắn nói, chỉ mép phải.

Con tai sứt nhìn theo, nheo mắt.

— Lại nhảy à?

— Không nhảy. Đi.

Họ men theo mép vũng, leo lên những tảng đá dưới chân vách phải. Gần tới nơi, hắn thấy một gờ đá hẹp, rộng chừng một bàn chân, chạy dọc vách ra phía sau lớp nước mỏng. Rêu phủ trơn. Hắn áp người vào vách, bám bằng tay trái và hai chân, nhích từng chút. Nước mỏng chảy qua đầu, qua vai, lạnh buốt nhưng không quật. Phía sau, con tai sứt bám theo.

Mười nhịp thở. Hai mươi. Rồi gờ đá rộng ra, nước không còn chảy lên người nữa.

Hắn đứng thẳng dậy, quệt nước trên mặt, và mở mắt.

---

Ánh sáng ở đây màu xanh.

Nắng xuyên qua tấm màn nước, bị lọc thành một thứ ánh sáng xanh nhạt, rung rinh, nhảy múa trên vách đá như ánh sáng dưới đáy hồ. Tiếng thác gầm rú bên ngoài giờ chỉ còn là một tiếng rền trầm, như tiếng thở của cả ngọn núi.

Trước mặt hắn là một cây cầu.

Không phải cầu gỗ. Nó là một tấm phẳng, đen bóng, như sắt, bắc ngang qua một dòng nước chảy ra từ một kẽ đá trong vách. Dòng nước ấy chảy dưới cầu, đổ ra ngoài, hòa vào màn thác. Hắn đặt chân lên. Tấm cầu lạnh, cứng, không rung.

Bên kia cầu là một gian rộng.

Rộng hơn bất cứ chỗ trú nào hắn từng thấy từ khi ra đời. Nền đá phẳng và khô, khô đến lạ lùng khi ngay bên ngoài là cả một khối nước khổng lồ. Trần cao, có những khe nhỏ để ánh sáng lọt vào. Và khắp nơi trong gian là những khối đá có hình thù kỳ lạ.

Một khối tròn, lõm giữa, như cái nồi. Bên cạnh là một khối nhỏ hơn, như bếp. Những khối lõm như bát, như chậu. Ở góc trong, những phiến đá dài, phẳng, cao ngang đầu gối, như giường. Những khối thấp vuông vức như ghế. Không có dấu đục đẽo nào. Như thể chúng mọc lên từ nền đá.

Con tai sứt đứng ở đầu cầu, không dám qua. Nó nhìn quanh, đuôi quặp lại.

— Ai làm cái này?

Hắn không trả lời. Hắn đang nhìn thứ ở giữa gian.

Một tấm bia đá, cao hơn hắn, mặt phẳng nhẵn. Trên mặt bia có khắc chữ.

Hắn bước tới, chậm rãi, như sợ tấm bia biến mất.

Chữ Hán. Những nét khắc sâu, vuông vức, đẹp đến mức hắn không biết tả thế nào. Hắn không đọc được chữ Hán. Ở đời trước, hắn chỉ từng thấy chúng trên câu đối ngày Tết, trên phim, trên những tấm biển trong mấy ngôi chùa cũ. Hắn chỉ nhận ra được vài chữ, những chữ đơn giản nhất.

Chữ thứ nhất có bộ thảo trên đầu. Hoa.

Chữ thứ hai, hắn chắc chắn. Quả. Hắn từng thấy nó trên những hộp bánh trung thu.

Chữ thứ ba chỉ có ba nét dọc. Núi. Sơn.

Hoa. Quả. Sơn.

Những chữ còn lại hắn không đọc được. Nhưng hắn không cần đọc. Hắn đã nghe câu ấy không biết bao nhiêu lần, trong phim, trong truyện tranh, trong những lời kể của người lớn từ hồi còn bé. Ở vế sau, chữ đầu tiên hắn cũng nhận ra, vì nó giống hệt cái hình dòng nước người ta vẫn vẽ: Thủy. Vài chữ sau có hai chữ giống hệt nhau đứng liền, cùng mang ba chấm nước bên trái.

Hoa Quả Sơn phúc địa. Thủy Liêm Động động thiên.

Hắn đứng chết lặng trước tấm bia.

Mười một ngày. Mười một ngày hắn vẫn gọi nơi này là “ngọn núi này”, vẫn nói với mình “nếu đúng là Ngộ Không”, “nếu đây là Hoa Quả Sơn”. Mười một ngày hắn vẫn để lại một chỗ hở trong đầu, một khả năng rằng tất cả chỉ là trùng hợp, rằng hắn chỉ là một con khỉ đá ở một ngọn núi nào đó không có tên trong sách.

Chỗ hở ấy vừa đóng lại.

Đây là Hoa Quả Sơn. Đây là Thủy Liêm Động. Và hắn là con khỉ đá sinh ra để vào đây.

Cảm giác đầu tiên là mừng. Một thứ mừng run rẩy, như tìm được đường về nhà trong một thành phố lạ.

Cảm giác thứ hai đến ngay sau đó, lạnh như nước thác.

Nếu tấm bia này đúng, thì những thứ khác cũng có thể đúng. Cây gậy dưới đáy biển. Cuốn sổ sinh tử. Thiên Đình. Lò bát quái. Một bàn tay khổng lồ úp xuống, và năm trăm năm dưới một ngọn núi.

Hắn nắm chặt bàn tay trái, móng cắm vào lòng bàn tay.

— Này. — Con tai sứt đã qua cầu từ lúc nào, đứng sau lưng hắn. — Ngươi sao thế? Cái đá ấy có gì?

Hắn quay lại, nhìn con tai sứt. Nó đang sờ tay lên cái nồi đá, mắt tròn xoe.

— Chữ — hắn nói.

— Chữ là gì?

Hắn há miệng, rồi ngậm lại. Hắn nhìn quanh gian động: nền khô, rộng đủ cho cả đàn, có nước chảy ngay đầu cầu, có màn thác che kín lối vào. Không con gấu nào có thể bước thẳng vào đây.

Trong sách, khỉ đá nhảy qua thác, rồi quay ra gọi cả bầy. Cả bầy nhảy theo. Thế là xong. Không có dòng nào viết về lũ khỉ nhỏ chưa leo vững, về khỉ mẹ địu con trên bụng phải men theo một gờ đá rộng bằng bàn chân, về khoảng trống năm mươi bước giữa sườn cây cào. Không có dòng nào viết về một con gấu đứng trên đống đá, nhìn xuống lòng suối như đang chờ.

Sách không viết những thứ ấy. Hắn sẽ phải tự viết.

— Chữ là thứ để nhớ — hắn nói. — Đi thôi. Bà đang chờ.

---

Khi họ ra khỏi động, mặt trời đã qua đỉnh đầu.

Bóng cây đã bắt đầu dài ra. Họ đã trễ.

Họ chuyền cây về nhanh hơn lúc đi, không ai nói câu nào. Tới khoảng trống giữa sườn, hắn dừng lại ở cây cuối cùng, nghe. Không có tiếng đá lăn nữa. Không có gì cả. Sự im lặng ấy làm hắn sợ hơn mọi tiếng động.

Họ tụt xuống, chạy.

Giữa khoảng trống, hắn liếc xuống đất. Trên lối cỏ rạp, ngay chỗ lúc sáng hai đứa chạy qua, có những dấu chân lớn. Dấu móng với lỗ nhọn ở đầu ngón, in đè lên những dấu chân khỉ nhỏ xíu của hắn và con tai sứt. Bùn trong dấu còn ướt.

Nó đã đi qua đây. Sau họ.

Hắn không dừng lại nhìn. Hắn chạy nhanh hơn, nhanh như chưa bao giờ chạy, vào tới thân cây, leo lên, chuyền đi. Cả hai không dừng lại cho tới khi thấy gốc cây lớn ở rìa sườn.

Khỉ già đã đứng dậy.

Bà nhìn hai đứa leo xuống, ướt sũng, xước xát, thở như sắp đứt hơi. Bà nhìn mặt trời. Bà nhìn hắn.

— Trễ.

— Trễ — hắn thừa nhận. — Nó đi qua khoảng trống sau bọn ta. Dấu chân còn ướt.

Khỉ già im lặng một lúc. Hắn chờ bà mắng. Bà không mắng.

— Nói đi.

Hắn kể. Thác nước, cao bằng mấy chục cây. Vũng sâu, nước trong, nhiều đến mức con tai sứt bơi giữa vũng. Lối vào qua gờ đá ở mép phải, nơi chim én bay vào. Bên trong là một gian rộng, khô, có nước chảy ngay cạnh, đủ chỗ cho cả đàn ngủ. Hắn không kể về tấm bia. Hắn chỉ nói có những khối đá giống như nồi, như giường.

Hắn cũng kể chuyện mình nhảy sai.

Khỉ già nghe hết, không ngắt lời. Rồi bà hỏi đúng hai câu.

— Gờ đá ấy, một con mẹ địu con trên bụng có đi qua được không?

Hắn nghĩ đến gờ đá rộng bằng bàn chân, rêu trơn, nước lạnh chảy qua đầu. Hắn nghĩ đến khỉ mẹ lông nâu đỏ với khỉ con bám trên bụng.

— Không biết. Ta đi phải áp sát vách. Có con trên bụng thì không áp sát được.

— Khoảng trống dưới đất. Dài bao nhiêu?

— Năm mươi bước chân ta.

— Chân lũ nhỏ?

Hắn không trả lời. Bà cũng không cần hắn trả lời.

Khỉ già quay lại, nhìn về phía rừng quả, nơi cả đàn đang nằm dưới tán lá, khát và mệt.

— Ở lại thì chết khát — bà nói. — Đi thì phải qua chỗ nó.

— Thì đi nhanh — con tai sứt nói.

— Ngươi nhanh. — Khỉ già không quay lại. — Lũ nhỏ không nhanh.


# Tái sinh Tề Thiên

## Chương 6 · Ai đi trước

Tối hôm ấy, khỉ già gọi cả đàn lại dưới chân vách đá khóc.

Không phải để chia lượt uống. Hõm đá đã khô từ trước khi trăng lên, chỉ còn một vệt ẩm mỏng ở đáy mà lũ nhỏ liếm mãi không ra nước. Cả đàn ngồi quanh vách, lưng tựa vào nhau, im lặng chờ.

Khỉ già nói ngắn. Có nước. Rất nhiều nước, ở phía bên kia sườn cây cào, dưới một vách đá cao. Có một cái hang sau màn nước, khô, đủ chỗ cho tất cả. Muốn tới đó phải qua chỗ của con gấu.

Bà nói xong thì cả đàn nhốn nháo.

Khỉ đực to con đứng phắt dậy, đi qua đi lại trước vách, lông trên vai dựng lên. Nó muốn đi ngay, chẳng cần nói hắn cũng biết. Mấy con đực trẻ khác cũng kêu lên theo. Ở góc vách, một khỉ mẹ có lông nâu sẫm ôm chặt đứa con nhỏ, lùi sát vào đá, mắt nhìn khỉ già như nhìn một kẻ vừa bảo nó đem con đi cho gấu ăn.

Hắn ngồi ở cuối, như mọi lần. Hắn đã báo cáo với khỉ già rồi. Đây là việc của đàn.

— Đi ngay sáng mai. — Con tai sứt nói to, át cả tiếng nhốn nháo. — Cả đàn chạy một lượt. Nó chỉ có một, chúng ta có cả đàn. Nó không đuổi được hết.

— Chờ — khỉ già nói.

— Chờ cái gì?

— Trời sẽ mưa.

Con tai sứt nhìn lên. Trời đêm trong vắt, không một gợn mây. Đã mười một ngày rồi không có lấy một đám mây nào đủ dày để che trăng.

— Mùa trước bà cũng bảo chờ — nó nói.

Cả đàn im bặt.

Hắn thấy khỉ già khựng lại. Chỉ một thoáng, rất nhỏ, như con thú bị chạm vào chỗ đau cũ. Rồi bà quay đi, không nói thêm câu nào, leo lên cây lớn cạnh vách. Bà không gọi ai theo.

Đàn tản ra trong im lặng. Khỉ đực to con đứng thêm một lúc rồi cũng leo lên. Khỉ mẹ lông nâu sẫm vẫn ngồi nép vào vách, ôm con.

Con tai sứt đứng một mình giữa chân vách, hai tay nắm chặt. Hắn thấy nó nhìn lên cây, nơi khỉ già đã khuất sau tán lá, rồi nhìn xuống đất, rồi nhìn về phía sườn cây cào.

---

Đêm ấy hắn tìm con tai sứt.

Nó không ngủ trên cây cùng đàn. Nó ngồi trên một mỏm đá cách vách một quãng, nhìn về hướng rìa sườn. Hắn trèo lên, ngồi xuống cạnh nó. Một lúc lâu, cả hai không nói gì.

— Mùa trước — hắn nói. — Ai đi?

Con tai sứt không trả lời ngay. Nó gãi cái tai khuyết. Hắn đã thấy nó gãi tai như thế nhiều lần, những khi không biết nói gì.

— Ta với anh ta.

Giọng nó phẳng lặng, không như giọng con tai sứt hắn quen.

— Đàn khát như bây giờ. Bà bảo chờ mưa. Anh ta bảo không chờ được, lũ nhỏ chết mất. Anh ta nghe bọn khỉ già kể có nước ở phía dải trắng. Anh ta đi, ta theo. — Nó dừng lại. — Bà không biết. Bọn ta đi lúc trời chưa sáng.

Hắn không nói gì. Hắn để nó kể.

— Tới chỗ trống giữa sườn thì gặp nó. Nó đứng trong cỏ. Bọn ta không thấy. Tới lúc thấy thì nó đã đứng dậy. — Con tai sứt nhìn xuống bàn tay mình. — Anh ta đẩy ta ra sau. Bảo chạy. Ta chạy.

Một cơn gió lùa qua. Lá cây xào xạc.

— Ta không quay lại. Ta chạy tới tận rìa, leo lên cây, ở đó tới tối. Rồi mới dám quay lại. — Nó im lặng một lúc. — Ngươi thấy rồi đấy. Dưới gốc cây ở rìa.

Hắn nhớ bộ xương nhỏ bạc trắng giữa đám lá. Cái sọ vỡ mất một bên. Hắn nhớ con tai sứt đã ngừng gặm quả khi khỉ già đứng đó.

— Bà biết — con tai sứt nói. — Chỉ bà biết. Bà không bảo ai. Bà chỉ cấm ta tới sườn cây cào.

Hắn hiểu ra nhiều thứ cùng một lúc. Vì sao con tai sứt luôn đi trước. Vì sao nó luôn muốn lao xuống, lao lên, lao qua. Vì sao nó hỏi “Ngươi lên đó định đi luôn à?” khi kéo hắn xuống núi. Vì sao nó đếm từng lần cứu nhau.

— Ta không chạy nữa — con tai sứt nói.

Hắn có thể nói nhiều thứ. Rằng đó không phải lỗi của nó. Rằng anh nó muốn nó sống. Rằng chạy lúc ấy là đúng. Ở đời trước, người ta hay nói với nhau những câu như thế. Hắn không chắc câu nào trong đó giúp được ai.

— Chạy để bỏ lại thì khác — hắn nói chậm rãi. — Chạy để dẫn nó đi chỗ khác thì khác.

Con tai sứt quay sang nhìn hắn.

— Khác gì?

— Chưa biết. — Hắn nhìn về phía rìa sườn. — Cho ta hai ngày.

---

Hai ngày sau đó, hắn sống ở rìa sườn cây cào.

Sáng sớm, khi sương còn bám trên lá, hắn ngồi dưới gốc cây lớn, cách bộ xương nhỏ một quãng, nhắm mắt, thở, nghe. Giữa trưa, khi nắng gắt nhất, hắn quay lại ngồi tiếp. Chiều muộn, thêm một lần nữa. Đốm ấm dưới rốn đã quen với nhịp ấy. Nó sáng lên nhanh hơn trước một chút, không nhiều, nhưng đủ để hắn không phải ngồi quá lâu.

Hắn nghe con gấu.

Sáng sớm, nó ở chỗ chắn. Tiếng đá lăn, tiếng nước. Có lúc tiếng nó uống, ực ực, nghe rõ đến mức hắn phải mở mắt nhìn quanh xem có phải nó ở gần không. Khi nắng lên cao, nó rời chỗ chắn. Những bước chân nặng nề, tiếng cành gãy, tiếng thở phì phò, đi dọc sườn cây cào từ bên này sang bên kia, rồi vòng lại. Nó đi tuần. Chiều xuống, nó về cái khe có ổ lá, im hẳn.

Ngày thứ hai cũng thế. Gần như không khác.

Đêm giữa hai ngày ấy, khi cả đàn đang ngủ, hắn nghe thấy tiếng bước chân ấy ở gần đá khóc. Không gần lắm, nhưng gần. Nó đến, đứng ở chân vách một lúc, liếm hõm đá khô, rồi đi. Hắn nằm im trên chạc cây, tim đập dồn dập, cho tới khi tiếng chân xa hẳn.

Chiều ngày thứ mười ba, sau buổi nghe cuối cùng, hắn ngồi xổm trên nền đất khô cạnh vách đá khóc, cầm một cái que.

Lũ khỉ nhỏ là đứa đầu tiên tò mò. Chúng xúm lại, nhìn hắn vạch những đường kỳ lạ trên đất. Rồi mấy con mẹ. Rồi khỉ đực to con. Đến khi khỉ già tụt xuống cây, quanh hắn đã có cả nửa đàn.

Hắn vạch một đường cong dài: sườn cây cào. Đặt một hòn đá to ở đầu đường cong: thác. Một vòng tròn ở giữa: khoảng trống. Một cái que dài đặt chéo ở phía bên phải: cây gãy. Mấy hòn sỏi nhỏ ở đầu bên này: đàn khỉ.

Ở đời trước, mỗi lần phải giải thích việc gì cho ai, hắn đều vẽ ra giấy. Hắn chưa từng nghĩ có ngày mình vẽ cho một bầy khỉ xem.

— Đây là gì? — một khỉ nhỏ hỏi, chỉ vào hòn đá to.

— Thác.

Khỉ nhỏ nhìn hòn đá, rồi nhìn hắn, rồi nhìn hòn đá. Rõ ràng nó không hiểu sao một hòn đá lại là thác. Nhưng khỉ già ngồi xuống, nhìn rất lâu, và hắn thấy mắt bà di chuyển từ hòn đá sang vòng tròn, từ vòng tròn sang cái que.

— Nói đi — bà bảo.

---

Hắn nói chậm, chỉ vào từng chỗ.

— Sáng sớm, con gấu ở đây. — Hắn đặt một hòn sỏi đen cạnh cái que, phía bên kia. — Chỗ chắn. Trưa nó đi tuần cả sườn. Chiều nó về khe. Hai ngày đều thế.

Hắn nhặt mấy hòn sỏi trắng.

— Nhóm thứ nhất. Những đứa khỏe, nhảy xa, không mang con. Đi trước một ngày, lúc nó ở chỗ chắn. Sang thác, cắt dây leo, buộc dọc cái gờ đá ở mép thác. Để con mẹ địu con có chỗ bám mà đi.

Khỉ đực to con nghiêng đầu nhìn mấy hòn sỏi trắng. Nó có vẻ thích phần này.

— Ngày dời. — Hắn đặt hai hòn sỏi nâu cạnh hòn sỏi đen. — Hai đứa đi trước nữa. Tới chỗ chắn từ sớm. Phá một góc đống đá cho nó thấy. Để nó đuổi. — Hắn kéo hai hòn sỏi nâu dọc theo cái que, về phía đầu bên này. — Chạy về cây gãy. Khỉ chui dưới thân cây được, nó phải trèo qua. Mỗi lần trèo mất mấy nhịp thở. Dẫn nó chạy dọc lòng suối, càng xa sườn càng tốt.

Hắn chỉ vào đám sỏi còn lại.

— Lúc đó, những đứa còn lại qua sườn. Lũ nhỏ cõng trên lưng, không bám bụng, để khỉ lớn còn tay mà bám cây. Qua khoảng trống. Qua tới thác. Nhóm thứ nhất ở đó đón.

Hắn ngẩng lên. Cả đàn đang nhìn hắn. Không ai nói gì.

Khỉ già vẫn nhìn xuống những hòn sỏi.

— Nếu nó không đuổi?

Hắn đã nghĩ tới câu này.

— Thì những đứa ở rìa không xuống đất. Ngồi trên cây chờ. Hai đứa đi dụ sẽ tìm cách khác.

— Cách gì?

— Chưa biết.

Khỉ già gật nhẹ, như thể câu trả lời ấy đúng như bà đoán.

— Nếu nó đuổi kịp hai đứa dụ?

Hắn im lặng một lúc. Hắn đã nghĩ tới câu này nhiều hơn. Hắn đã nghĩ suốt hai đêm.

— Ta không có câu trả lời nào tốt — hắn nói.

Khỉ già ngẩng lên nhìn hắn. Hắn không quay đi.

— Hai đứa dụ là ai?

— Ta. — Hắn ngừng một chút. — Với một đứa nữa, nếu có đứa chịu.

— Ta. — Con tai sứt nói ngay, trước khi hắn kịp nói hết câu.

Khỉ già quay sang nhìn con tai sứt. Bà nhìn nó rất lâu, lâu đến mức cả đàn bắt đầu cựa quậy. Con tai sứt không cúi đầu. Nó nhìn lại bà.

Hắn biết bà đang thấy gì. Một con khỉ đực trẻ đứng ở đúng chỗ anh nó từng đứng mùa trước, xin được đi lại con đường ấy.

Khỉ già không gật, cũng không lắc.

— Thử cái gờ trước — bà nói. — Rồi tính.

---

Sáng ngày thứ mười bốn, nhóm thứ nhất sang thác.

Khỉ đực to con dẫn đầu, theo sau là bốn con đực trẻ và con tai sứt. Hắn đi cùng để chỉ chỗ. Họ đi lúc rạng sáng, khi hắn đã nghe thấy tiếng đá lăn ở chỗ chắn. Qua khoảng trống không gặp gì. Đến thác thì mặt trời vừa lên khỏi rừng.

Cả bọn uống nước như chưa bao giờ được uống. Khỉ đực to con đứng giữa vũng nước, nước ngập tới ngực, mắt nhắm, cứ đứng thế không chịu ra.

Rồi họ cắt dây leo.

Dây leo ở rừng ven thác mọc dày, có loại to bằng cổ tay, dai và dẻo. Lũ khỉ đực cắn đứt, kéo xuống. Hắn chỉ cho chúng chọn dây: dây xanh, không khô, không có gai. Rồi chỗ buộc. Hắn nhớ lời khỉ già ngày đầu tiên: cái lớn bên trái, đừng nắm cái vỏ trắng. Hắn chọn những rễ cây bám sâu vào vách, giật thử từng cái, cái nào không nhúc nhích mới dùng.

Thắt nút khó hơn hắn tưởng. Tay phải vẫn yếu, không giữ được dây cho chặt. Hắn dùng tay trái và răng, quấn dây quanh rễ, luồn đầu dây qua vòng, kéo căng. Một cái nút đơn giản nhất, cái nút người ta vẫn buộc dây giày. Hắn làm ba lần mới được.

Lũ khỉ đực ngồi nhìn. Con tai sứt nhìn kỹ nhất. Đến nút thứ tư, nó giật lấy đầu dây, tự làm. Nút của nó xấu hơn, lỏng hơn, nhưng giữ được.

Đến trưa, một sợi dây leo đã chạy dọc theo gờ đá, từ chỗ những tảng đá dưới chân vách tới tận chỗ gờ mở rộng ra sau màn nước. Cứ một quãng lại buộc vào một rễ cây hay một mỏm đá. Đủ để một con khỉ đi trên gờ có thể nắm chặt bằng một tay.

Họ quay về trước khi con gấu đi tuần.

---

Chiều hôm ấy, khi hắn kể với khỉ già về sợi dây, khỉ mẹ lông nâu đỏ đứng dậy.

Nó không nói gì nhiều. Nó chỉ đi tới trước mặt khỉ già, cúi đầu, rồi nhìn về phía sườn cây cào. Khỉ già nhìn nó một lúc, rồi gật.

Lúc con gấu đã về khe, khỉ mẹ lông nâu đỏ sang thác cùng hắn và con tai sứt. Không mang con. Khỉ con lông nâu nhạt ở lại với khỉ già, kêu ầm lên khi mẹ đi, khỉ già phải ôm chặt nó.

Ở mép thác, khỉ mẹ lông nâu đỏ nắm dây leo, áp người vào vách, bước lên gờ. Nước mỏng chảy qua đầu. Nó nhích từng bước, chậm, tay không rời dây. Hắn đứng dưới chân vách, nhìn, nín thở. Hai mươi nhịp. Ba mươi. Rồi nó biến mất sau lớp nước.

Một lúc sau nó trở ra, ướt sũng, đứng trên tảng đá, rũ nước. Rồi nó làm một việc hắn không ngờ: nó nhặt một hòn đá cỡ khỉ con lông nâu nhạt, đưa cho hắn, chỉ vào bụng mình.

Hắn hiểu. Hắn lấy một đoạn dây leo, buộc hòn đá vào trước bụng khỉ mẹ, đủ chặt để không rơi, đủ nặng để giống một đứa con bám bụng.

Lần này khỉ mẹ đi chậm hơn nhiều. Hòn đá trước bụng khiến nó không áp sát vách được. Nó phải nghiêng người ra ngoài một chút, chỉ dựa vào sợi dây. Có một lúc chân nó trượt trên rêu, cả người chao đi. Hắn chồm lên. Nhưng tay khỉ mẹ không buông dây. Nó đứng im một lúc, rồi bước tiếp.

Nó qua được.

Khi nó trở ra lần nữa, gỡ hòn đá khỏi bụng, ném xuống vũng, hắn nhận ra mình đang run.

---

Tối ngày thứ mười bốn, khỉ già gọi cả đàn lại lần nữa.

Lần này bà không để ai nhốn nháo. Bà nói rõ từng việc. Sáng mai, nhóm thứ nhất đi trước, sang thác giữ gờ, khỉ đực to con dẫn. Hai đứa đi dụ đi theo. Những đứa còn lại theo bà ra rìa sườn, chờ trên cây, khi nào bà bảo xuống mới xuống. Lũ nhỏ cõng trên lưng. Con nào không cõng được con mình thì khỉ đực trẻ cõng thay.

Bà nhìn khỉ mẹ lông nâu sẫm, đứa vẫn ôm con ngồi nép trong góc.

— Ngươi đi sau ta. Thấy ta làm gì thì làm theo.

Khỉ mẹ lông nâu sẫm nhìn bà một lúc, rồi gật.

Cuối cùng khỉ già quay sang hắn.

— Hai đứa dụ. Ngươi bảo gì thì nó làm. — Bà hất cằm về phía con tai sứt. — Còn đàn, ta dẫn.

Hắn gật đầu. Hắn hiểu bà đang chia gì: phần của bà và phần của hắn. Bà không trao đàn cho hắn. Bà trao cho hắn con tai sứt.

Có lẽ thế còn nặng hơn.

---

Đêm ấy đá khóc không khóc nữa.

Hắn tụt xuống cây lúc nửa đêm, sờ tay vào hõm đá. Khô khốc. Lớp rêu trên vách giòn ra dưới ngón tay, vụn thành bột. Không một giọt nào. Hắn đứng đó một lúc lâu, rồi leo lên lại.

Con tai sứt nằm ở chạc cây ngay cạnh hắn. Nó cũng không ngủ.

— Này — nó nói.

— Gì.

— Lần này nếu ta bảo chạy, ngươi chạy.

Hắn nhìn lên tán lá. Qua kẽ lá, sao vẫn dày đặc như mọi đêm. Không một đám mây.

— Lần này — hắn nói — ta chạy cùng ngươi.

Con tai sứt không nói gì nữa. Một lúc sau, hắn nghe nó thở đều.

---

Rạng sáng ngày thứ mười lăm, hắn ra rìa sườn như mọi sáng.

Sương dày hơn mọi hôm, phủ trắng cả khoảng rừng thưa phía trước. Bộ xương nhỏ dưới gốc cây ướt đẫm sương. Hắn ngồi xuống, nhắm mắt, thở, để đốm ấm sáng lên.

Hắn nghe.

Tiếng gió. Tiếng lá nhỏ giọt sương. Tiếng thác xa xa. Tiếng đàn khỉ thức dậy phía sau lưng.

Hắn nghe về phía chỗ chắn. Không có tiếng đá lăn.

Hắn nghe về phía cái khe có ổ lá. Không có gì.

Hắn nghe dọc sườn cây cào, từ bên này sang bên kia. Không có tiếng chân, không có tiếng cành gãy, không có tiếng thở phì phò.

Hắn mở mắt, nhìn vào màn sương trắng xóa.

Hai ngày qua, mỗi sáng, con gấu đều ở chỗ chắn.

Sáng nay, hắn không nghe thấy nó ở đâu cả.


# Tái sinh Tề Thiên

## Chương 7 · Trận đánh đầu

Hắn chạy về rìa vừa kịp lúc khỉ đực to con định tụt xuống đất.

— Khoan!

Khỉ đực to con dừng lại giữa thân cây, quay đầu, nhe răng. Sau nó, bốn con đực trẻ đã bám sẵn trên cành thấp, chỉ chờ nó xuống là theo. Nhóm khỏe. Theo kế hoạch, giờ này chúng phải đã qua khoảng trống.

— Ta không nghe thấy nó — hắn nói, thở dốc.

Khỉ đực to con nhìn hắn, rồi nhìn màn sương, như muốn nói: thì sao?

— Không nghe thấy không có nghĩa là nó không ở đó.

Khỉ già từ trên cây cao tụt xuống, đáp xuống cành ngay cạnh hắn. Phía sau bà, cả đàn đã bám kín mấy cây lớn ở rìa sườn, những đứa nhỏ ôm chặt lưng mẹ, lưng khỉ lớn. Không ai kêu. Khát quá rồi, chẳng còn sức kêu.

— Sương tan thì nghe được không? — bà hỏi.

— Có thể.

— Sương tan lúc nào?

Hắn nhìn màn trắng dày đặc phía trước. Hắn không biết. Có thể đến trưa. Có thể cả ngày.

Khỉ già quay lại nhìn đàn. Khỉ con lông nâu nhạt gục đầu trên lưng mẹ, mắt lim dim. Một khỉ nhỏ khác nằm vắt trên vai khỉ đực trẻ, tay buông thõng. Đêm qua đá khóc không còn một giọt.

Chờ thêm một ngày nữa, sẽ có đứa không tỉnh dậy.

Hắn biết. Bà biết. Không ai cần nói ra.

Một cơn gió thổi qua. Từ phía sườn cây cào, gió lùa về rìa, mang theo hơi sương lạnh, mùi lá ướt, mùi đất.

Và một mùi khác.

Hắn quay phắt đầu. Hắn hít một hơi thật sâu. Đặc, nồng, hôi như lông thú ướt. Không phải mùi cũ thấm vào vỏ cây. Mùi mới. Gần. Từ phía trước, hơi chếch xuống, chỗ sườn núi trũng xuống.

Chỗ khoảng trống.

Hắn quay sang con tai sứt. Nó đã ngửi thấy trước hắn. Nó đứng im trên cành, lông dựng ngược từ gáy xuống đuôi, mắt nhìn chằm chằm vào màn sương.

— Nó nằm trong cỏ — con tai sứt nói. Giọng nó nhỏ đến mức hắn suýt không nghe thấy.

Như mùa trước.

---

Họ bàn nhanh, trên cành cây, giữa sương.

— Nó không ở chỗ chắn — hắn nói. — Nó ở đúng chỗ đàn phải đi qua. Phải kéo nó ra.

— Kéo ra đâu? — khỉ già hỏi.

— Lòng suối. Rồi cây gãy. — Hắn chỉ tay về phía phải, nơi sườn dốc xuống lòng suối cạn. — Khe dưới thân cây vẫn còn. Rồi lên chỗ chắn.

— Lên chỗ chắn làm gì?

— Phá nó.

Khỉ già nhìn hắn. Hắn nói tiếp, nhanh, vì không có thời gian để nói chậm.

— Hôm phá chắn lần đầu, nó đuổi bọn ta tới tận gốc cây. Nhưng rồi nó bỏ đi. Không phải vì không bắt được. Vì nước đang chảy mất. Nó quay về sửa chắn trước. — Hắn nhìn khỉ già. — Nước quan trọng với nó hơn bọn ta. Ta phá chắn, nó sẽ phải ở lại đó.

Khỉ già im lặng một nhịp. Rồi bà gật.

— Nhóm khỏe?

— Khi nghe tiếng nó gầm đi xa về phía lòng suối, xuống. Qua khoảng trống. Sang thác, giữ gờ.

— Còn ta?

— Bà nghe. Bà quyết.

Khỉ già nhìn hắn thêm một lúc. Hắn không biết bà nghĩ gì. Có thể bà nghĩ tới mùa trước. Có thể bà nghĩ tới bộ xương nhỏ dưới gốc cây ngay cạnh họ.

— Đi đi — bà nói.

Con tai sứt đã tụt xuống đất, nhặt đá. Lần này nó nhặt bốn hòn, kẹp hai hòn dưới nách, cầm hai hòn trong tay. Nó ngẩng lên nhìn hắn. Hắn cũng nhặt một hòn, cỡ nắm tay, cầm bằng tay trái.

---

Họ chuyền cây vào trong sương.

Không nhìn thấy gì quá năm thân cây. Cây hiện ra từ màn trắng như những bóng ma, rồi lại chìm vào sau lưng. Hắn đi theo mùi. Mùi đậm dần, đậm dần, cho tới khi hai đứa tới cây cuối cùng, cây đứng ở mép khoảng trống.

Hắn ngồi xổm trên cành, nhắm mắt.

Không cần nghe xa nữa. Gần thế này, hắn chỉ cần thở chậm, để đốm ấm dưới rốn lắng xuống, để tai mình mở ra.

Tiếng thở.

Chậm, nặng, đều đều, ở đâu đó trong cỏ phía trước. Gần. Gần hơn hắn tưởng. Có lẽ chỉ hai mươi bước.

Hắn mở mắt, chỉ tay. Con tai sứt nhìn theo. Trong cỏ cao, giữa sương, không thấy gì cả. Chỉ có một chỗ cỏ hơi rạp xuống, tối hơn xung quanh một chút.

Con tai sứt giơ đá lên. Tay nó run. Hắn thấy rõ. Nó hít một hơi, rồi ném.

Hòn đá bay vào sương, rơi vào cỏ, cách chỗ tối ấy vài bước. Không có gì xảy ra.

Con tai sứt ném hòn thứ hai.

Bịch.

Tiếng thở ngừng lại.

Cỏ rẽ ra. Một khối đen đứng dậy từ giữa khoảng trống. Từ từ, không vội. Cái đầu to, đôi tai tròn, rồi bờ vai, rồi cái ngực có vệt lông trắng cong như vầng trăng non. Nó đứng trên hai chân sau, cao hơn cả ngọn cỏ một quãng dài, sương bám thành giọt trên lông.

Nó quay đầu. Nhìn lên cây.

Nhìn thẳng vào hắn.

Lần này hắn chắc chắn. Nó nhận ra hắn.

Con gấu gầm lên, rồi hạ bốn chân xuống, lao tới.

---

— Đi!

Họ nhảy sang cây bên cạnh, đúng lúc con gấu húc vào gốc cây vừa rời. Cả thân cây rung lên. Hắn không nhìn lại. Hắn nhảy tiếp, sang cây thứ ba, thứ tư, về phía bên phải, về phía sườn dốc xuống lòng suối.

Phía sau, tiếng cành gãy, tiếng chân nặng nề, tiếng thở phì phò. Nó bám theo dưới đất. Cây nào họ dừng lại quá lâu, cây ấy bị húc rung lên.

Hắn hét lên một tiếng thật to. Không phải với con gấu. Với khỉ già, ở phía sau. Đi xa rồi. Đi xa rồi.

Rừng thưa dần. Cây cách nhau xa hơn. Đến một chỗ, cây tiếp theo cách quá xa, không nhảy tới được.

— Xuống!

Họ tụt xuống, chạy. Đất dốc, trơn vì sương. Hắn trượt chân, lăn một vòng, bật dậy chạy tiếp. Con tai sứt chạy trước. Tiếng con gấu sau lưng mỗi lúc một gần.

Rồi lòng suối hiện ra. Đá cuội trắng, khô, sương mỏng hơn hẳn trên sườn. Hắn nhảy xuống lòng suối, quay đầu chạy ngược lên phía thượng nguồn.

Trước mặt, thân cây gãy nằm chéo ngang lòng suối.

---

Con tai sứt tới cây gãy trước. Nó rạp người xuống, lao vào khe hở dưới thân cây, chỗ thân cây gác lên tảng đá.

Rồi nó dừng lại.

Hắn tới sau một nhịp, thấy ngay. Nửa người con tai sứt đã qua khe, nhưng chân sau bị kẹt. Khe hẹp hơn hôm trước. Có mấy hòn đá mới nằm chèn dưới thân cây, đá lăn xuống từ những ngày con gấu xếp chắn. Chân con tai sứt mắc giữa đá và vỏ cây, nó quẫy, giật, không ra.

Sau lưng hắn, tiếng đá cuội bị giẫm lạo xạo. Con gấu đã xuống lòng suối.

Không có thời gian chui. Hắn nhìn thân cây. Cao hơn đầu hắn.

Hắn hít một hơi. Không kéo. Không đẩy. Chỉ để đốm ấm dưới rốn lan xuống, như mỗi lần hắn leo cây trong mấy ngày qua. Nó lan xuống hai chân. Hắn nhún người, bật lên.

Hắn đáp lên thân cây, hai chân bám chặt vỏ, tay trái vẫn nắm hòn đá.

Con gấu đã tới. Nó không trèo. Nó cúi xuống, thò cái đầu to vào khe dưới thân cây, nơi nửa sau của con tai sứt vẫn đang quẫy. Một chi trước thò vào theo, móng dài cào lên đá, cách chân con tai sứt chưa tới một đốt tay.

Con tai sứt hét lên.

Hắn không nghĩ. Hắn nhảy xuống, đúng chỗ con gấu đang cúi đầu, dồn cả sức nặng của mình vào cánh tay trái, đập hòn đá vào mũi nó.

Cạch.

Hắn cảm thấy thứ gì đó dưới hòn đá lún xuống. Con gấu rống lên, một tiếng rống chưa từng nghe, cao và chói, giật đầu ra khỏi khe. Cái đầu to đập vào người hắn, hất hắn văng lên.

Rồi một vuốt vung ngang.

Hắn thấy nó tới. Hắn không tránh kịp. Hắn chỉ kịp nghiêng người, và ba móng dài quét qua lưng hắn, từ giữa lưng chéo lên vai trái.

Không đau ngay. Chỉ nóng. Như ai đó kéo ba thanh sắt nung qua da.

Hắn ngã nhào qua thân cây, rơi xuống phía bên kia, lưng đập xuống đá cuội. Lúc ấy cơn đau mới tới. Trắng xóa. Hắn há miệng, không kêu được thành tiếng.

---

Có ai đó đang kéo hắn dậy.

Hắn mở mắt. Con tai sứt đang túm hai tay hắn, giật hắn ngồi lên. Chân sau của nó đã ra khỏi khe, nhưng cổ chân sưng phồng, nó đứng lệch sang một bên.

Sau lưng con tai sứt, lòng suối chạy dài xuống phía dưới, mở ra một con đường thoát. Nó có thể chạy. Nó có thể đã chạy rồi.

Nó không chạy. Nó quay lại.

Bên kia thân cây gãy, con gấu đang rống, máu chảy ròng ròng từ mũi, nó lắc đầu, hai chi trước bám lên thân cây. Nó đang trèo.

— Chỗ chắn — hắn nói qua kẽ răng.

Con tai sứt nhìn hắn một nhịp. Rồi nó hét lên, to đến mức át cả tiếng con gấu:

— Chạy!

Và nó không buông tay hắn. Nó chạy, kéo hắn theo. Hắn chạy cùng nó.

---

Lòng suối phía trên cây gãy hắn đã đi qua một lần. Lối mòn rộng, cành bẻ cao, rồi khúc uốn sang trái. Hắn chạy như trong mơ, mỗi bước chân là một cơn đau xé dọc lưng. Con tai sứt chạy khập khiễng, cổ chân trẹo làm nó chậm hẳn, nhưng nó vẫn chạy, vẫn kéo.

Phía sau, tiếng con gấu đã trèo qua được thân cây. Tiếng chân nặng nề lại vang lên.

Chỗ chắn hiện ra.

Nó cao hơn lần trước. Con gấu đã đắp thêm cả một lớp đá to ở trên, cành cây cài kín các kẽ. Nhưng ở dưới đáy, chỗ dòng cũ, vẫn là những hòn đá nhỏ, vẫn rỉ nước qua kẽ.

— Dưới đáy! — hắn hét.

Họ lao vào. Con tai sứt giật cành. Hắn tì vai vào một hòn đá. Vai trái không dùng được nữa, cứ chạm vào là trắng mắt. Hắn đổi sang vai phải. Tay phải nắm lấy một mỏm đá để làm điểm tựa. Mới mấy ngày trước, tay ấy còn không cầm nổi một hạt. Giờ nó nắm được. Không chặt, nhưng nắm được.

Hắn đẩy. Hòn đá nhích. Đẩy nữa. Nó bật ra.

Nước phụt lên, bắn vào mặt hắn. Con tai sứt giật thêm một cành, rồi cùng hắn đẩy hòn bên cạnh. Lỗ hổng rộng ra. Nước réo lên, cuồn cuộn chảy qua, kéo theo sỏi, kéo theo lá.

Và con gấu tới.

Nó dừng lại ở đầu lối mòn, cách họ chưa tới mười bước. Nó đứng dậy trên hai chân sau. Máu từ mũi chảy xuống, nhuộm đỏ vệt lông trắng trên ngực. Nó nhìn hai con khỉ.

Rồi nó nhìn dòng nước đang réo qua lỗ hổng.

Hòn đá to ở trên, chỗ ngay trên lỗ hổng, bắt đầu lún xuống. Một hòn khác chao đi. Cả lớp đá trên cùng rung rung, như sắp sụp.

Con gấu gầm. Một tiếng gầm dài, giận dữ, dội vào vách núi.

Rồi nó lao tới. Không phải vào hai con khỉ. Vào đống đá. Nó ôm lấy hòn đá to đang lún, ghì lại, rồi dùng chi kia cào những hòn đá xung quanh, chèn vào lỗ hổng.

Hắn đứng nhìn, cách nó chỉ vài bước, nước chảy qua chân.

Đúng như hắn đoán. Nước quan trọng hơn.

— Đi — con tai sứt kéo tay hắn.

Họ leo lên vách đá bờ trái, chỗ hôm trước khỉ già ngồi canh. Con gấu không ngẩng lên. Nó đang bận chèn đá.

---

Từ vách đá bờ trái, họ đi men theo sườn núi.

Hắn không biết đường. Không ai trong hai đứa biết đường từ chỗ chắn tới thác. Hắn chỉ biết hướng: tây bắc, phía có tiếng nước rơi. Hắn dừng lại, nhắm mắt, nghe, rồi đi tiếp. Mỗi lần dừng là một lần hắn suýt không đứng dậy được.

Lưng hắn ướt đẫm. Hắn không dám sờ ra sau. Máu chảy xuống chân, nhỏ giọt trên đá.

Con tai sứt đi bên cạnh, khập khiễng. Nó không nói gì. Có lúc nó đưa vai ra cho hắn tì.

Mặt trời lên cao. Sương tan dần. Tiếng thác mỗi lúc một to.

Rồi rừng mở ra, và hắn thấy vách đá cao, tấm màn nước trắng xóa, vũng nước xanh.

Và đàn khỉ.

Họ đang qua gờ. Một hàng dài những tấm lưng nâu, xám, áp sát vào vách, tay nắm chặt dây leo, từng bước nhích dần ra sau màn nước. Những đứa nhỏ bám trên lưng. Khỉ đực to con đứng giữa gờ, lưng tựa vào vách, một tay nắm dây, tay kia đỡ một khỉ mẹ lông nâu sẫm đang run rẩy, đứa con nhỏ bám cứng trên lưng nó. Khỉ mẹ lông nâu sẫm không bước được nữa. Khỉ đực to con nói gì đó với nó, hắn không nghe rõ. Khỉ mẹ lông nâu sẫm nhắm mắt, rồi bước tiếp.

Hắn nhìn thấy khỉ mẹ lông nâu đỏ đã ở gần cuối gờ. Trên lưng nó, khỉ con lông nâu nhạt ôm chặt cổ mẹ.

Ở chân vách, trên những tảng đá dưới gờ, khỉ già đứng một mình. Bà là con cuối cùng. Bà đang đếm.

Hắn và con tai sứt trèo xuống từ sườn núi. Khỉ già quay lại. Bà nhìn con tai sứt khập khiễng, nhìn hắn, nhìn lưng hắn.

Bà không nói gì. Bà chỉ quay lại, nắm lấy dây leo, bước lên gờ. Hắn theo sau bà. Con tai sứt theo sau hắn.

---

Ánh sáng trong động màu xanh.

Lũ nhỏ đã nằm la liệt trên nền đá. Có đứa vẫn đang uống ở dòng nước chảy dưới cầu sắt, uống rồi nằm vật ra ngay bên cạnh, ngủ luôn. Mấy con mẹ ngồi dựa vào những khối đá như giường, như ghế, mắt nhắm. Khỉ đực to con nằm ngửa giữa gian động, bụng phập phồng, cứ thế mà thở.

Khỉ già đi một vòng quanh gian động. Bà dừng lại ở từng đứa, chạm tay vào, rồi đi tiếp. Hắn biết bà đang làm gì.

Khi bà đi hết một vòng, bà đứng ở giữa gian, cạnh tấm bia đá có chữ, và đứng im rất lâu.

Rồi bà đi vòng thêm một lần nữa.

Đủ.

Không thiếu một đứa nào.

Hắn ngồi tựa vào một khối đá, không dám nằm ngửa. Khỉ già tới trước mặt hắn. Bà nhìn lưng hắn, nhìn ba đường rách dài từ giữa lưng lên tận vai trái, lông bết máu.

— Lá — bà nói, không quay đầu lại.

Khỉ mẹ lông nâu đỏ đứng dậy, đi ra phía cửa động.

Con tai sứt ngồi xuống cạnh hắn, duỗi cái chân sưng ra. Cổ chân nó to gấp đôi bình thường, tím bầm. Nó nhìn cái chân, rồi nhìn hắn.

— Ta kéo ngươi thêm một lần — nó nói. — Hết nợ.

Hắn nhìn nó. Hắn nghĩ tới lòng suối mở ra phía sau lưng nó lúc ở cây gãy, con đường mà nó có thể chạy.

— Ngươi quay lại — hắn nói.

Con tai sứt im lặng một lúc. Rồi nó gãi cái tai khuyết.

— Ừ.

Nó không nói thêm. Hắn cũng không hỏi.

---

Đêm đó, cả đàn ngủ trong động.

Tiếng thác rền vang bên ngoài, đều đều, không ngớt, như tiếng thở của cả ngọn núi. Ánh trăng xuyên qua màn nước, nhạt nhòa, rung rinh trên vách đá.

Hắn không ngủ được. Lưng đau như bị lửa đốt. Khỉ mẹ lông nâu đỏ đã đắp lá lên, lá mát, nhưng mỗi lần cựa mình là những vết rách lại kéo căng.

Hắn nằm sấp, nhìn tấm bia đá trong bóng tối.

Hôm nay không có phép thuật. Không có gậy Như Ý. Không có một cái búng tay nào đánh bay con gấu. Chỉ có một hòn đá cầm bằng tay trái. Một khe hở dưới thân cây gãy. Một đống đá chắn dòng. Và hiểu biết rằng con gấu yêu nước hơn ghét khỉ.

Những thứ ấy, hắn không học từ sách. Hắn học từ một bà khỉ già biết rễ nào chắc, từ một con khỉ tai sứt biết đọc dấu cành, từ chính con gấu, qua mười lăm ngày đuổi bắt nhau quanh một dòng nước.

Hắn nhắm mắt.

Ngoài màn nước, rất xa, từ phía sườn cây cào, vọng tới một tiếng gầm.

Nó vẫn ở đó.


# Tái sinh Tề Thiên

## Chương 8 · Một nơi gọi là nhà

Mấy ngày đầu trong động, hắn sốt.

Không cao như lần ép khí. Chỉ là cái nóng âm ỉ, bám dai dẳng, đến chiều thì nặng hơn, sáng ra lại dịu đi. Ba đường rách trên lưng sưng tấy, rỉ nước vàng. Khỉ mẹ lông nâu đỏ ngày nào cũng ra rừng ven thác hái lá về, nhai nát, đắp lên. Lá đắng, chạm vào vết thương thì rát, nhưng một lúc sau lại mát.

Hắn nằm sấp trên một phiến đá như cái giường, nghe tiếng thác, nghe tiếng lũ nhỏ.

Lũ nhỏ không còn nằm im nữa. Mới qua một đêm có nước, chúng đã chạy nhảy khắp động như chưa từng khát. Chúng leo lên cây cầu sắt, chạy qua chạy lại, rồi phát hiện tấm cầu lạnh và trơn, liền nằm xoài ra trên đó cho mát. Chúng chui vào những cái hõm như nồi, như chậu, thò đầu ra dọa nhau. Có đứa lấy bát đá đựng nước, bưng đi được ba bước thì đổ hết lên người.

Khỉ già ngồi ở góc động, nhìn chúng, không quát.

Mỗi rạng sáng, hắn bò ra cửa động.

Chỗ gờ đá mở rộng sau màn nước có một khoảng đủ cho một con khỉ ngồi. Từ đó nhìn ra, màn nước như một tấm vải trắng treo trước mặt, rung rinh, lấp lánh. Khi mặt trời lên, ánh sáng đầu tiên xuyên qua lớp nước, rơi vào gờ đá thành những vệt sáng nhảy múa. Sương thác bám trên lông, mát lạnh.

Hắn ngồi đó, thở. Không kéo, không đẩy.

Khí ở đây khác ở bãi tiên thạch. Không mạnh bằng, không dồn dập như lúc nắng đầu tiên chiếu thẳng vào hõm đá. Nó đến đều đều, dịu dàng, như tiếng thác không ngớt. Đốm ấm dưới rốn sáng lên, lan ra một chút, rồi lắng xuống. Lưng hắn vẫn đau. Khí không làm vết thương lành nhanh hơn. Nhưng những sáng ngồi đó, hắn ngủ được.

Ngay sáng đầu tiên, trước khi bò vào động, hắn nhặt một mảnh đá trắng, vạch một đường lên vách đá cạnh cửa.

Một vạch. Ngày đầu tiên ở nhà.

---

Đến khi cơn sốt lui hẳn, trên vách đã có năm vạch.

Hắn tập đi lại. Vai trái cứng đơ, nhấc tay lên quá đầu là kéo căng cả mảng da non trên lưng. Hắn phải dùng tay phải nhiều hơn. Lòng bàn tay phải giờ đã liền, chỉ còn một vệt sẹo trắng chạy chéo, cầm nắm gần như bình thường.

Đàn đã quen với nhà mới nhanh hơn hắn tưởng.

Khỉ đực to con dẫn mấy con đực trẻ đi theo dòng suối chảy ra từ vũng thác, xuôi về phía tây. Chúng về kể có một thung lũng, nước chảy suốt, hai bên bờ toàn cây quả. Có loại quả vàng to bằng nắm tay, ngọt lịm. Có cây hạt giống cây hạt bên rừng cũ. Không có vết cào nào trên thân cây.

Ngày hôm sau, cả đàn kéo nhau ra thung lũng. Hắn đi cùng, chậm, con tai sứt khập khiễng bên cạnh. Cổ chân nó đã bớt sưng, nhưng vẫn chưa chạy được.

Thung lũng đúng như lời kể. Ánh nắng dịu, nước trong, lá xanh mướt. Lũ nhỏ trèo lên cây quả vàng, ăn đến nỗi nước quả chảy ròng ròng xuống cằm. Khỉ con lông nâu nhạt tụt xuống bờ suối, thò tay xuống nước, rồi thò chân, rồi cả người. Nó vùng vẫy một hồi, rồi phát hiện ra mình nổi được. Nó bơi. Vụng về, bắn nước tung tóe, nhưng nó bơi. Khỉ mẹ lông nâu đỏ đứng trên bờ, kêu ầm lên, nhưng không kéo nó lên.

Hắn ngồi trên một tảng đá, nhìn khỉ con bơi, và chợt nhận ra mình đang cười.

Tối về, hắn với con tai sứt ngồi trên nền động, dùng đá trắng vạch lên mặt đá xám. Dòng suối thoát của thác. Thung lũng. Cây quả vàng. Bãi cây hạt. Một vạch dài ở phía đông, nơi sườn cây cào bắt đầu, hắn vạch chéo lên một dấu nhân thật to.

— Cái gì đây? — con tai sứt hỏi.

— Chỗ không đi.

Con tai sứt nhìn dấu nhân một lúc. Rồi nó cầm lấy mảnh đá trắng, tự vạch thêm một vòng tròn nhỏ cạnh bãi cây hạt.

— Tổ ong — nó nói. — Ta thấy hôm nay. Đừng để lũ nhỏ tới gần.

Hắn nhìn vòng tròn nhỏ, nhìn con tai sứt. Con tai sứt không nhìn hắn. Nó đang vạch thêm một đường nữa, đường đi vòng qua tổ ong.

---

Khỉ già không đi thung lũng nhiều.

Lúc đầu hắn tưởng bà mệt sau chuyến dời. Đến ngày thứ tám trong động, hắn mới để ý: bà ho. Không nhiều, chỉ vài tiếng khan khi trời trở lạnh lúc nửa đêm. Bà ngủ nhiều hơn. Buổi sáng bà dậy muộn, có hôm đàn đã ra thung lũng mà bà vẫn nằm trên phiến đá trong góc.

Một hôm bà đi theo đàn ra thung lũng. Đến trưa, khi đàn chuẩn bị về, không ai thấy bà đâu.

Con tai sứt là đứa tìm thấy bà. Bà đứng ở một khúc suối rẽ nhánh, nhìn quanh, như không biết mình đang ở đâu. Khi con tai sứt tới, bà nhìn nó một lúc lâu rồi mới đi theo.

Bà không nói gì về chuyện đó. Hắn cũng không hỏi. Nhưng từ hôm ấy, bà ngồi ở cửa động nhiều hơn, nhìn đàn đi rồi nhìn đàn về.

Đất cũ, bà biết từng gốc cây, từng hòn đá. Đất mới, bà không biết gì.

---

Ngày thứ mười trong động, khỉ đực to con về báo có dấu chân.

Ở phía đông thung lũng, nơi đất dốc lên về phía sườn cây cào, có một con đường mòn chạy vòng quanh chân núi. Đó là đường hắn với con tai sứt đã đi hôm phá chắn, từ vách đá bờ trái vòng về thác. Trên đường ấy có dấu chân gấu. Dấu cũ, mấy ngày rồi. Nó đi tới một chỗ cao nhìn xuống thung lũng, đứng ở đó một lúc, rồi quay về.

Nó không đi tiếp. Không tới gần thác.

Hắn ra xem. Dấu chân dừng ở mép một bãi đá, nơi tiếng thác đã nghe rất rõ. Từ đó nhìn xuống được vũng nước xanh dưới chân vách. Đất bị cào thành mấy rãnh. Rồi dấu chân quay lại, đi về phía sườn cây cào.

Có thể nó không thích nước sâu. Có thể nó không ưa tiếng thác ầm ầm. Có thể nó chỉ chưa muốn. Hắn không biết. Hắn chỉ biết nó đã tới đây, đã nhìn, và đã quay về.

Tối đó, hắn đứng giữa động, nói với cả đàn. Không ai qua sườn cây cào nữa. Không ai đi đường vòng phía đông quá bãi đá ấy. Đàn có nước ở đây, có quả ở thung lũng. Không cần qua chỗ của nó.

Hắn nói xong mới nhận ra cả đàn đã im lặng nghe. Không ai nhìn khỉ già để chờ bà gật. Họ nhìn hắn.

Khỉ già ngồi ở góc, cũng nhìn hắn.

---

Ngày thứ mười một trong động, khỉ già gọi cả đàn lại trước tấm bia.

Bà ngồi trên một khối đá thấp như cái ghế, ngay dưới chân bia. Cả đàn ngồi quanh. Lũ nhỏ cũng bị gọi về, ngồi trong lòng mẹ, ướt sũng vì vừa chơi dưới vũng.

— Đất cũ — bà nói — ta biết. Đường nước, quả nào ăn được, chỗ nào có gấu. Ta biết hết.

Bà ho một tiếng.

— Đất này ta không biết. — Bà nhìn quanh đàn. — Đứa nào đi trước thì phải biết. Ta không biết thì ta không đi trước được.

Cả đàn im lặng. Hắn ngồi ở cuối, như mọi lần. Hắn đã biết bà định nói gì từ lúc bà gọi đàn lại.

Khỉ già quay đầu, nhìn thẳng vào hắn.

— Từ nay nó đi trước.

Không ai lên tiếng. Lũ nhỏ nhìn mẹ, rồi nhìn hắn.

— Đi trước — khỉ già nói chậm rãi — thì uống sau cùng. Có gấu thì đi đầu. — Bà dừng lại, nhìn khắp đàn. — Nó sai, đứa nào thấy thì nói. Không được im.

— Ta nói trước — con tai sứt nói ngay.

Có vài tiếng kêu khẽ trong đàn, như cười.

Rồi khỉ đực to con đứng dậy.

Nó không nói gì. Nó chỉ đứng thẳng, lông trên vai và lưng dựng ngược lên, to gấp rưỡi bình thường. Nó nhìn hắn. Nó nhe răng. Răng nanh dài, vàng.

Hắn biết cái nhìn ấy. Hai ngày đầu theo đàn, hắn đã thấy mấy con đực trẻ nhìn nhau như thế, trước khi lao vào cắn nhau giành chỗ ngồi. Đây là cách đàn khỉ quyết định ai đứng trên ai. Không phải bằng lời bà khỉ già. Bằng răng.

Cả đàn im phăng phắc.

Hắn đứng dậy. Lưng kéo căng, đau nhói. Hắn không dựng lông. Hắn không nhe răng. Hắn đứng đó, nhìn khỉ đực to con.

Hắn có thể đánh. Hắn khỏe hơn nó, hắn biết. Nhưng lưng hắn còn chưa lành, vai trái còn chưa nhấc được. Và quan trọng hơn: nếu đánh, dù thắng, sáng mai hắn sẽ phải đi trước một đàn có một con khỉ đực to nhất vừa bị cắn trước mặt cả bầy.

— Hôm dời — hắn nói — ngươi đứng giữa gờ. Ngươi đỡ từng con mẹ qua. Không đứa nào rơi.

Khỉ đực to con vẫn nhìn hắn. Lông vẫn dựng.

— Gờ ấy là của ngươi giữ. Có gì tới từ ngoài thác, ngươi đứng ở đó. Ta không giữ gờ được giỏi bằng ngươi.

Khỉ đực to con nhìn hắn rất lâu. Rồi nó quay sang nhìn khỉ già.

Khỉ già không nói gì. Bà không can. Bà chỉ ngồi đó, nhìn.

Lông trên vai khỉ đực to con xẹp xuống dần. Nó ngồi xuống. Nó không nhìn hắn nữa, mà quay đầu nhìn về phía cửa động, nơi gờ đá chạy ra sau màn nước.

Cả đàn thở ra.

Hắn ngồi xuống lại, lưng ướt đẫm mồ hôi.

Không ai gọi hắn là vua. Lũ khỉ không có chữ ấy. Chúng chỉ gọi hắn là “đứa đi trước”, giống như trước đây gọi khỉ già. Đầu đàn.

Hắn nghĩ tới tấm bia sau lưng mình, tới những chữ hắn không đọc được hết. Trong sách, sau khi vào động, khỉ đá tự xưng là Mỹ Hầu Vương. Vua khỉ đẹp. Hắn từng thấy cái tên ấy oai lắm.

Giờ nghĩ lại, hắn chỉ thấy nó xa lạ. Hắn không phải vua của ai. Hắn chỉ là con khỉ phải uống nước sau cùng.

---

Đêm ấy, khỉ già ra cửa động ngồi với hắn.

Bà đi chậm, men theo vách, ngồi xuống cạnh hắn trên gờ đá. Màn nước trước mặt nhạt nhòa ánh trăng. Bà ho vài tiếng, rồi im.

Hai người ngồi như thế một lúc lâu.

— Ngươi từ đâu tới? — bà hỏi.

Đã hai mươi sáu ngày rồi, đây là lần đầu tiên bà hỏi câu ấy.

Hắn nghĩ một lúc. Hắn có thể nói dối. Bà sẽ không biết. Nhưng hắn không muốn nói dối bà.

— Từ đá — hắn nói. — Trên đỉnh núi.

— Trước đó?

Hắn nhìn màn nước.

— Trước đó, ta ở một nơi khác. Rất xa. Không về được nữa.

Khỉ già không hỏi thêm. Bà chỉ gật đầu, như thể câu trả lời ấy đã đủ.

— Ngươi định làm gì?

— Học — hắn nói. — Học để mạnh hơn. Để không chết.

Khỉ già quay sang nhìn hắn. Ánh trăng qua màn nước rơi trên mặt bà, những nếp nhăn sâu, đôi mắt mờ đục.

— Không chết?

— Có người biết cách. Ở rất xa. Bên kia biển.

Khỉ già nhìn hắn rất lâu. Rồi bà bật cười. Một tiếng cười khàn, ngắn, như tiếng ho.

— Ai cũng chết — bà nói. — Ta già. Mùa khô này qua được. Mùa khô sau, chưa biết. Mùa khô sau nữa… — Bà lắc đầu. — Ai cũng chết.

— Bà có sợ không?

Khỉ già im lặng một lúc lâu.

— Ta sợ — bà nói. — Sợ chết trước khi lũ nhỏ biết đường nước ở đây. Đất cũ, ta dạy được. Đất này, ta không dạy được gì.

— Ta dạy chúng.

Khỉ già nhìn hắn.

— Ngươi hứa nhiều quá.

Bà đứng dậy, men theo vách đi vào trong động. Hắn ngồi lại một mình.

---

Trong sách, Mỹ Hầu Vương vui chơi ở Thủy Liêm Động ba đến năm trăm năm. Ăn quả, uống nước, ngủ trong động đá. Rồi một ngày giữa bữa tiệc, ông ta bỗng khóc, vì nghĩ tới chuyện một ngày nào đó mình sẽ già, sẽ chết. Một con vượn già đứng dậy, chỉ cho ông ta biết trên đời có những người không chết. Thế là ông ta lên đường.

Ba đến năm trăm năm.

Hắn ngồi trên gờ đá, nhìn màn nước, nghĩ tới con số ấy.

Hắn mới ở đây hai mươi sáu ngày. Hai mươi sáu ngày mà đã thấy một bộ xương nhỏ dưới gốc cây ở rìa sườn. Đã thấy con gấu đứng trong cỏ, máu chảy từ mũi. Đã nghe bà khỉ già ho mỗi đêm. Hắn không cần chờ tới một bữa tiệc nào để nghĩ tới cái chết. Nó đi lại quanh đây, ngay ngoài màn nước.

Hắn không chờ được ba trăm năm.

Nhưng hắn cũng biết, nếu hắn đi sớm, hắn đang làm lệch một điều sách đã viết. Không phải một chi tiết nhỏ như cái gờ đá hay con gấu. Mà là thời điểm. Nếu hắn tới chỗ Bồ Đề sớm hơn mấy trăm năm, liệu ông ta có còn ở đó không? Liệu ông ta có nhận hắn không? Những gì xảy ra sau đó, gậy Như Ý, Long Cung, Thiên Đình, có còn xảy ra đúng như thế không, đúng lúc ấy không?

Hắn không biết. Từ lúc quyết định này, hắn sẽ càng ngày càng không biết.

Nhưng chờ cũng là một lựa chọn. Chờ ba trăm năm, để rồi cũng tới đúng những chỗ ấy, gặp đúng những người ấy, và cuối cùng là một bàn tay khổng lồ úp xuống.

Ít nhất, nếu đi sớm, hắn đi theo đường của mình.

---

Rạng sáng ngày thứ mười lăm trong động, hắn vạch thêm một đường lên vách.

Mười lăm vạch. Hắn đếm lại, rồi đứng nhìn chúng một lúc.

Hắn ra gờ đá, đứng dậy. Lưng vẫn còn cứng, nhưng không đau nữa. Ba vệt sẹo dài kéo từ giữa lưng lên vai trái, lông mọc lại lởm chởm quanh đó. Khỉ mẹ lông nâu đỏ bảo trông như ai lấy móng vẽ lên.

Qua khe giữa màn nước và vách đá, nhìn ra xa, có thể thấy được một vệt xanh thẫm phía sau những ngọn núi thấp. Biển.

Bên kia biển là nơi hắn cần tới.

Không phải ngày mai. Không phải tháng sau.

Trước hết, lũ nhỏ phải biết đường nước ở đây. Phải biết thung lũng nào có quả, chỗ nào có tổ ong, chỗ nào không được đi. Con tai sứt phải đọc được sơ đồ không cần hắn. Khỉ đực to con phải giữ được gờ không cần ai bảo. Đàn phải có luật với con gấu, một ranh giới mà khi hắn vắng, không ai vượt qua.

Và khỉ già phải thấy được điều đó, trước khi mùa khô sau tới.

Sau lưng hắn, đàn khỉ đang thức dậy. Tiếng lũ nhỏ chạy trên cầu sắt. Tiếng con tai sứt cằn nhằn vì bị giẫm vào chân. Tiếng khỉ già ho khan, rồi gọi ai đó dậy.

Hắn đứng thêm một lúc trên gờ, nhìn về phía biển.

Đây là nhà. Muốn giữ nó, hắn sẽ phải rời nó.


# Tái sinh Tề Thiên

## Chương 9 · Mùa mưa

Khỉ già muốn tự biết đất mới.

Bà không nói thế. Bà chỉ đứng ở cửa động một buổi sáng, khi đàn chuẩn bị ra thung lũng, nhìn theo rất lâu, rồi quay sang khỉ đực to con. Khỉ đực to con nhìn bà, nhìn hắn, rồi ngồi xuống trước mặt bà, quay lưng lại.

Từ hôm ấy, mỗi sáng, khỉ già ra thung lũng trên lưng khỉ đực to con.

Bà nhẹ, chẳng nặng hơn một khỉ nhỏ là mấy. Bà bám vào lông vai nó, ngồi im, mắt nhìn khắp nơi. Bà nhìn những cây quả vàng, những bãi đá, những khúc suối rẽ nhánh. Chiều về, bà nằm trên phiến đá trong góc động, mắt nhắm. Nhưng hắn biết bà không ngủ. Bà đang nhớ.

Đến ngày thứ năm, bà bắt đầu sửa lũ nhỏ.

— Không phải cây ấy. — Bà chỉ khi một khỉ nhỏ định trèo lên cây quả vàng đầu tiên bên suối. — Cây thứ ba. Cây đầu thì quả chua. Cây thứ hai có kiến lửa.

Lũ nhỏ đi qua cây thứ hai, nhìn lên. Kiến lửa bò thành hàng dài trên thân. Chúng nhìn bà như nhìn một thứ phép thuật.

Bà đặt tên cho mọi thứ. Không phải tên như người đặt, mà như đàn khỉ vẫn gọi: tảng đá giống đầu chim, khúc suối có cá, cây gãy ngọn, bãi cỏ trơn. Hắn ngồi nghe, rồi về vạch lên nền động. Con tai sứt nhìn những vạch ấy, rồi dẫn một nhóm nhỏ đi theo. Đi đúng thì về. Đi sai, khỉ già sửa.

Hắn đứng nhìn những buổi chiều ấy, nhìn bà khỉ già ngồi trên lưng khỉ đực to con chỉ trỏ, lũ nhỏ chạy theo, con tai sứt cằn nhằn mấy đứa đi lệch đường. Hắn nghĩ: thế này là đúng. Không phải hắn dạy chúng. Là cả đàn dạy nhau.

---

Mỗi rạng sáng, hắn vẫn ngồi trên gờ sau màn nước.

Khí đến đều. Đốm ấm dưới rốn sáng lên, lan xuống chân, đều đặn như nước chảy theo rãnh quen. Hắn đã nhảy được xa hơn. Không nhiều. Một quãng bằng nửa thân mình. Từ một cành cây này sang một cành cây xa hơn chút. Khi chạy trên đá ven suối, chân hắn bám chắc hơn, ít trượt hơn.

Nhưng đến khoảng ngày thứ mười của tháng thứ hai, hắn bắt đầu thấy nó.

Đốm ấm không lớn thêm nữa. Sáng nào nó cũng sáng lên chừng ấy, lan ra chừng ấy, rồi dừng. Hắn thở chậm hơn, ngồi lâu hơn, nó vẫn chừng ấy. Có một sáng, hắn để ý thấy khi nó sáng nhất, có một cảm giác chực tràn ra, như nước đầy bát sắp trào. Hắn không đẩy. Nhưng chỉ để ý đến nó thôi, cảm giác ấy đã chao đi, rồi tan, để lại một chút nóng rát mơ hồ ở vai phải.

Như lần ép khí.

Hắn mở mắt, ngồi im rất lâu.

Hắn hiểu. Không có ai dạy, hắn chỉ biết đặt ra những luật để khỏi tự làm hại mình. Không đẩy, chỉ nhìn. Những luật ấy giữ cho hắn khỏi ngã. Nhưng chúng không chỉ cho hắn đi tiếp. Cái bát đã đầy. Muốn chứa thêm, phải có người biết làm bát to hơn.

Hắn nhìn ra phía biển, qua khe giữa màn nước và vách đá. Vệt xanh thẫm vẫn ở đó.

---

Ngày thứ mười bốn của tháng thứ hai, khỉ già dừng lại giữa đường ra thung lũng.

Bà ngồi trên lưng khỉ đực to con, ngẩng đầu, mũi phập phồng. Gió đổi hướng. Không còn thổi từ thung lũng lên nữa, mà từ phía đông, phía biển. Gió mát hơn, ẩm hơn, có một mùi hắn chưa từng ngửi thấy từ khi ra đời. Mùi đất trước khi ướt.

Phía đông, trên đường chân trời, có một dải mây xám chì.

— Về — khỉ già nói.

— Bà?

— Mưa. — Bà không nhìn hắn. Bà vẫn nhìn dải mây. — Mưa đầu mùa. To.

Hắn nhìn dải mây. Nó còn xa lắm, chỉ là một vệt mờ. Ở đời trước, hắn sẽ mở điện thoại ra xem dự báo. Ở đây, chỉ có một bà khỉ già và cái mũi của bà.

Khỉ già quay về phía đàn.

— Hạt. Hái hết hạt mang về. Bỏ vào cái bát đá, cái nồi đá. Quả chín cũng hái. Lũ nhỏ không ra gờ nữa.

Không ai hỏi vì sao. Cả đàn tản ra, hái. Hắn hái cùng. Hắn không biết mùa mưa ở ngọn núi này thế nào. Hắn chỉ biết bà biết.

Đến chiều, những cái hõm đá như nồi, như chậu trong động đã đầy hạt. Lũ khỉ đực trẻ còn đi thêm một chuyến nữa, khi về thì gió đã thổi mạnh, cây ngoài thung lũng nghiêng ngả.

Đêm ấy, mưa đến.

---

Hắn chưa từng thấy mưa như thế.

Không phải mưa rơi. Là nước đổ. Cả bầu trời như bị lật ngược. Tiếng mưa trên vách núi ầm ầm hòa với tiếng thác, át hết mọi thứ. Đến sáng, màn thác trước cửa động đã khác hẳn. Không còn là tấm vải trắng mỏng lấp lánh nữa mà là một bức tường nước đục ngầu, dày gấp đôi, gầm rú như sấm không ngớt.

Hắn bò ra cửa động. Gờ đá đã biến mất. Nước tràn qua chỗ gờ, cuồn cuộn. Sợi dây leo đàn đã buộc dọc vách bị giật đứt, một đầu còn quấn trên một mỏm đá, đầu kia bay phần phật trong nước như cái đuôi.

Không ai ra được. Không gì vào được.

Hắn quay vào. Dòng nước chảy dưới cầu sắt đã dâng lên, đục ngầu, réo ầm ầm. Mặt nước chỉ còn cách mặt cầu chừng một gang tay. Nhưng nền động vẫn khô. Những phiến đá như giường, những khối đá như ghế vẫn khô. Cả gian động nằm cao hơn dòng nước một quãng, như thể có ai tính trước.

Khỉ già ngồi ở góc, mắt nhắm.

— Mùa nào cũng thế — bà nói, như biết hắn đang nhìn. — Nước lên rồi nước xuống.

Ba ngày ba đêm, mưa không ngớt.

Đàn ăn hạt trong bát đá. Hắn và con tai sứt ngồi giữa động đập hạt trên nền đá, lũ nhỏ xúm lại nhặt nhân. Khi hạt vỏ cứng nhặt về từ rừng cũ và thung lũng được đập ra từng nắm, hắn chợt nghĩ tới buổi sáng đầu tiên ở gốc cây hạt, tới ngón chân cái bị đá đập trúng. Nếu không có buổi sáng ấy, đống hạt này chẳng ăn được.

Lũ nhỏ bứt rứt. Chúng không được ra ngoài, không được nhảy xuống vũng, không được chạy trên cầu. Khỉ già cấm. Cầu ướt, trơn, nước bên dưới chảy như điên. Chúng chạy vòng quanh gian động, leo lên leo xuống những khối đá, kêu chí chóe. Mấy con mẹ quát mãi không được.

Ngày thứ ba, đứa con nhỏ của khỉ mẹ lông nâu sẫm chạy lên cầu.

---

Hắn thấy nó trước khi ai kịp kêu.

Khỉ nhỏ chạy theo một đứa khác, lao lên tấm cầu sắt. Chân nó chạm mặt cầu ướt. Trượt. Nó chới với, tay quờ quạng, rồi rơi xuống mép cầu, vào dòng nước đục ngầu bên dưới.

Dòng nước cuốn nó đi ngay. Về phía cửa động. Về phía bức tường thác đang gầm.

Khỉ mẹ lông nâu sẫm thét lên.

Hắn đã chạy. Không nghĩ. Hắn chạy dọc mép dòng nước, về phía cửa động, nhanh hơn dòng nước một chút. Phía trước, chỗ dòng nước đổ ra ngoài hòa vào thác, có một mỏm đá nhô ra. Khỉ nhỏ đang bị cuốn qua ngay dưới mỏm đá ấy.

Hắn để khí lan xuống chân. Không kéo, không đẩy. Như mọi sáng. Rồi bật.

Hắn bay qua dòng nước, đáp xuống mỏm đá, cúi người, thò tay xuống. Tay phải. Bàn tay có vết sẹo chạy chéo. Nó túm được cổ tay khỉ nhỏ.

Rồi dòng nước kéo cả hắn.

Nặng hơn hắn tưởng. Dòng nước không chỉ cuốn khỉ nhỏ, nó cuốn luôn cánh tay hắn, kéo hắn chúi xuống. Chân hắn trượt trên mỏm đá ướt. Hắn bám bằng tay trái, móng cào trên đá. Không đủ. Hắn đang trượt dần về phía màn thác.

Có ai đó túm đuôi hắn.

Hắn không cần nhìn cũng biết ai. Cái tay túm đuôi hắn đã túm đuôi hắn một lần trong vũng thác, đã túm vai hắn lôi xuống núi.

Nhưng một mình con tai sứt không đủ. Hắn cảm thấy cả con tai sứt cũng đang bị kéo trượt theo.

Rồi lực kéo dừng lại.

Hắn ngoái lại. Sau con tai sứt, khỉ đực to con đang ôm chặt ngang lưng nó, hai chân bám vào nền động. Sau khỉ đực to con, khỉ mẹ lông nâu đỏ đang túm lông lưng nó, một tay kia ôm lấy một khối đá như cái ghế. Sau nữa, mấy khỉ đực trẻ đã lao tới, bám vào bất cứ chỗ nào chúng nắm được.

Một chuỗi. Từ khối đá tới mỏm đá. Từ mỏm đá tới tay hắn. Từ tay hắn tới khỉ nhỏ.

— Kéo! — hắn hét.

Họ kéo. Từng chút một. Hắn lùi về phía mỏm đá, cánh tay phải căng ra như sắp đứt. Khỉ nhỏ được kéo lên khỏi mặt nước, ho sặc sụa, rồi bám chặt lấy cánh tay hắn. Hắn ôm nó vào ngực.

Cả chuỗi ngã nhào ra sau, đổ đè lên nhau trên nền động khô.

Khỉ mẹ lông nâu sẫm lao tới, giật lấy con, ôm chặt, run rẩy. Nó nhìn hắn. Nó không nói gì. Nó chỉ nhìn.

Hắn nằm ngửa trên nền đá, thở. Con tai sứt nằm cạnh, cũng đang thở.

— Lần này… — hắn nói.

— Ta không đếm nữa — con tai sứt nói.

Hắn quay sang nhìn nó. Nó vẫn nhìn lên trần động.

— Đếm mãi mệt lắm — nó nói thêm.

Khỉ già ngồi ở góc. Bà không đứng dậy. Bà chỉ nhìn chuỗi khỉ đang lổm ngổm bò dậy, nhìn khỉ mẹ lông nâu sẫm ôm con, nhìn hắn. Rồi bà nhắm mắt lại.

---

Sáng ngày thứ tư, mưa tạnh.

Thác vẫn còn đục, vẫn còn gầm, nhưng đã mỏng đi. Đến trưa, gờ đá lộ ra. Hắn và khỉ đực to con ra trước, buộc lại sợi dây leo bị đứt. Rồi cả đàn ra.

Thế giới bên ngoài đã khác.

Rừng ven thác xanh mướt, xanh đến chói mắt. Những chiếc lá bụi bặm suốt mùa khô giờ bóng loáng. Khắp sườn núi có những dòng suối nhỏ chảy xuống, những dòng mà trước đây hắn chưa từng thấy. Không khí mát, sạch, thơm mùi đất ướt. Lũ nhỏ lao ra, nhảy xuống những vũng nước mới, té nước, kêu la như phát điên.

Chiều hôm ấy, hắn đi lên bãi tiên thạch.

Đường từ thác tới đỉnh núi vòng xa, phải qua một sườn dốc phía bắc, không qua sườn cây cào. Hắn đi gần hết buổi chiều. Lên tới nơi, hắn ngồi vào hõm đá, nhắm mắt, nghe.

Phía đông nam, nơi lòng suối cũ, có tiếng nước réo. Không phải tiếng rỉ rả. Tiếng nước chảy mạnh, đầy, như một dòng suối thật. Hắn nghe dọc lên thượng nguồn, qua cây gãy, tới khúc uốn sang trái.

Không có tiếng đá va vào đá. Không có tiếng nước bị chặn rồi tràn. Chỉ có tiếng nước chảy thẳng một mạch.

Chỗ chắn đã không còn. Lũ đã cuốn đi tất cả.

Sáng hôm sau, hắn đi xuống phía rừng cũ, tới một chỗ cao nhìn được vũng nước cũ của đàn. Hắn không xuống. Hắn đứng trên cây, nhìn.

Vũng nước đầy. Nước trong, tràn cả bờ. Lòng suối cũ chảy róc rách dẫn nước tới.

Và con gấu đang uống ở đó.

Nó đứng ở mép vũng, cúi đầu, uống. Vệt lông trắng trên ngực dính bùn. Cái mũi có một vết sẹo mới, chỗ hòn đá của hắn đập trúng. Nó uống một hồi lâu, rồi ngẩng lên, nhìn quanh, rồi lại cúi xuống.

Không có đống đá nào. Không có dòng nước nào bị chặn. Nó chỉ uống, như một con thú khát.

Hắn đứng nhìn nó rất lâu.

Mười lăm ngày, hắn và con gấu giành nhau từng giọt nước. Hắn phá chắn, nó đắp lại. Hắn dụ nó chạy, nó cào rách lưng hắn. Cả đàn phải bỏ nhà, vượt sườn cây cào trong sương. Rồi trời mưa ba ngày, và tất cả những điều ấy trôi đi theo dòng lũ.

Hắn không thắng. Con gấu cũng không thắng. Mưa thắng.

Hắn nghĩ tới mùa khô sau. Nước sẽ lại cạn. Con gấu sẽ lại đắp chắn, hoặc làm một việc gì khác mà hắn không đoán được. Lần sau, có thể không có mưa đúng lúc.

Cần một thứ khác. Một luật, một cách chia nước, một điều gì đó mà cả đàn khỉ lẫn con gấu đều phải tôn trọng. Hắn không biết thứ ấy là gì. Hắn chỉ biết, nếu không có nó, mùa khô nào cũng sẽ là một trận đánh.

Hắn tụt xuống cây, quay về thác.

---

Những ngày sau mưa, lũ nhỏ bắt đầu tự đi.

Không ai bảo chúng. Một sáng, khi đàn còn đang ăn trong động, khỉ con lông nâu nhạt gọi mấy đứa nhỏ khác, dẫn chúng ra gờ, qua dây leo, xuống thung lũng. Khỉ mẹ lông nâu đỏ định theo, rồi dừng lại ở cửa động, nhìn.

Hắn đi theo từ xa, không để chúng thấy.

Khỉ con lông nâu nhạt dẫn đầu. Nó qua cây quả vàng thứ nhất, cây thứ hai, trèo lên cây thứ ba. Mấy đứa nhỏ trèo theo. Ăn xong, nó dẫn chúng đi dọc suối, tới bãi cây hạt. Gần tới nơi, nó dừng lại, nhìn về phía một bụi cây rậm, rồi rẽ sang trái, đi vòng một đường xa hơn.

Tổ ong ở trong bụi cây ấy. Con tai sứt đã vạch một vòng tròn nhỏ trên nền động.

Hắn đứng sau một thân cây, nhìn khỉ con dẫn lũ nhỏ đi vòng qua tổ ong, và chợt thấy cổ họng nghẹn lại.

Lúc hắn về tới thác, khỉ già đang ngồi ở cửa động, trên gờ đá, chỗ hắn vẫn ngồi mỗi sáng. Bà nhìn ra phía thung lũng.

Hắn ngồi xuống cạnh bà.

— Chúng đi vòng tổ ong — hắn nói.

— Ta thấy.

Bà đã thấy. Từ đây, qua khe giữa màn nước và vách đá, nhìn được một góc thung lũng. Bà đã ngồi đó nhìn suốt buổi sáng.

— Chúng biết rồi — bà nói.

Hắn không đáp. Hai người ngồi đó một lúc lâu, nghe tiếng thác.

Rồi khỉ già quay sang hắn. Mắt bà mờ đục, nhưng nhìn thẳng.

— Ngươi đi được rồi.

Hắn mở miệng, rồi lại ngậm.

Khỉ già không chờ hắn trả lời. Bà quay lại nhìn ra thung lũng, nơi tiếng lũ nhỏ kêu chí chóe vọng về, xa xa, lẫn trong tiếng thác.


# Tái sinh Tề Thiên

## Chương 10 · Lá rụng

Mưa không còn trút như ngày đầu mùa nữa. Có ngày mưa, có ngày tạnh, có những buổi chiều mây kéo đến rồi lại tan mà không rơi một giọt. Thác lúc đục lúc trong. Gờ đá lúc chìm lúc nổi. Đàn quen dần với nhịp ấy, như đã quen với tiếng thác.

Hắn quen với một việc khác: đi ra mép sườn cây cào.

Không phải qua sườn. Chỉ tới mép, từ phía thung lũng, nơi rừng quả vàng thưa dần và những thân cây đầu tiên mang vết cào bắt đầu. Hắn chọn ba thân cây đứng gần nhau ở đó, cây nào cũng to, cũng đứng ở chỗ dễ thấy. Rồi hắn nhặt một hòn đá sắc cạnh.

Hắn đứng thẳng trên hai chân, vươn tay lên cao hết mức có thể, rồi kéo hòn đá xuống, cào lên vỏ cây. Ba vệt. Không đều như vết móng, không sâu bằng, nhưng rõ. Vỏ cây bong ra, lộ lớp gỗ trắng. Hắn làm như thế với cả ba cây.

Con tai sứt đi theo, ngồi trên cành nhìn.

— Ngươi làm gì thế?

— Nói với nó.

— Nói gì?

Hắn nhìn ba vệt cào trên thân cây.

— Bên này là của bọn ta.

Con tai sứt nhìn vết cào, rồi nhìn hắn như nhìn một kẻ dở hơi. Nhưng nó không cười.

Bốn ngày sau, hắn quay lại.

Trên thân cây đầu tiên, ngay trên ba vệt cào của hắn, có ba vết móng mới. Cao hơn hẳn, sâu hơn hẳn, vỏ cây bị xé toạc thành từng mảng. Dưới gốc, đất bị cào lên, có dấu chân lớn. Dấu chân đến tới gốc cây, đứng đó một lúc lâu, in sâu xuống đất. Rồi quay lại. Đi về phía sườn cây cào.

Không đi tiếp vào thung lũng.

Hắn đứng nhìn vết móng chồng lên vết cào của mình rất lâu. Nó đã nghe. Nó trả lời: ta lớn hơn ngươi. Nhưng nó cũng đã quay về.

Không phải một thỏa thuận. Hắn biết. Con gấu không hứa gì, hắn cũng không hứa gì. Mùa khô sau, khi nước cạn, có thể nó sẽ chẳng thèm để ý tới mấy vết cào nữa. Nhưng ít nhất bây giờ, giữa hai bên có một thứ gì đó, một đường ranh mà cả hai đều đã chạm tay vào.

Tối đó, hắn vạch thêm một dấu lên sơ đồ trên nền động, ở chỗ ba thân cây ấy.

---

Những ngày ấy, hắn bắt đầu giao việc.

Không phải ra lệnh. Đàn khỉ không nghe lệnh như người. Hắn chỉ đứng ra làm một việc gì đó cùng ai đó, nhiều lần, rồi một hôm không làm nữa mà để họ làm.

Khỉ đực to con giữ gờ. Mỗi sáng nó ra trước, kiểm tra dây leo, giật thử từng chỗ buộc. Có hôm một con rắn bò lên gờ, nó đuổi đi trước khi lũ nhỏ kịp thấy. Có hôm mấy con khỉ lạ từ đâu đó tới gần vũng thác, nó đứng trên tảng đá cao nhất dựng lông lên, chúng bỏ đi. Hắn không phải nhắc lần nào.

Con tai sứt giữ sơ đồ. Mỗi lần đàn tìm thấy chỗ mới, cây quả mới, nguồn nước mới, nó là đứa vạch lên nền động. Nó dẫn lũ nhỏ đi, sửa khi chúng sai. Và nó nói. Có hôm khỉ đực to con định dẫn mấy con đực trẻ đi qua một bãi đá trơn sau mưa, con tai sứt chặn lại, chỉ lên sơ đồ, cãi nhau một hồi. Khỉ đực to con dựng lông. Con tai sứt không lùi. Cuối cùng khỉ đực to con đi đường vòng.

Hắn đứng xem từ xa, không xen vào.

---

Khỉ già không ra thung lũng nữa.

Bà ngồi trên gờ cửa động mỗi sáng, cạnh hắn. Hắn ngồi luyện, bà ngồi nhìn. Có hôm bà ngủ gật, đầu gục vào vai hắn. Hắn ngồi im cho tới khi bà tự tỉnh.

Một sáng, khi trên vách đã có gần bảy mươi vạch, bà nói:

— Chỗ đá khóc.

Hắn mở mắt, quay sang.

— Mẹ ta chỉ cho ta. — Bà nhìn ra màn nước. — Hồi ta còn nhỏ hơn con bé lông nâu nhạt kia. Mùa khô. Mẹ ta dẫn ta tới, bảo đá này đêm nào cũng khóc. Ta không tin. Mẹ ta bắt ta ngồi đó cả đêm, nghe.

Bà im lặng một lúc.

— Đêm ấy ta nghe thấy nó khóc.

Bà không kể thêm. Hắn cũng không hỏi. Hai người ngồi đó cho tới khi nắng lên cao, rồi bà men theo vách đi vào trong.

Sáng hôm sau, bà không dậy.

---

Hắn không phải là người phát hiện.

Khi hắn bò ra gờ lúc trời còn tối, bà đã ở đó. Bà nằm nghiêng trên gờ đá, chỗ bà vẫn ngồi, đầu gối lên tay, mắt nhắm. Như ngồi đợi nắng rồi ngủ quên. Hắn ngồi xuống cạnh bà như mọi sáng, nhắm mắt, thở.

Mặt trời lên. Ánh sáng đầu tiên xuyên qua màn nước, rơi lên gờ đá, rơi lên người bà.

Bà không cựa mình.

Khỉ mẹ lông nâu đỏ là đứa ra tiếp theo. Nó đứng ở cửa động, nhìn khỉ già, rồi bước tới, chạm tay vào vai bà. Rồi nó rụt tay lại. Nó kêu lên một tiếng khẽ, một tiếng hắn chưa từng nghe đàn khỉ phát ra.

Hắn mở mắt.

Hắn đã biết, từ lúc ngồi xuống. Bà không ho. Đêm nào bà cũng ho, sáng nào bà cũng ho mấy tiếng khi ra gờ. Sáng nay không có tiếng ho nào. Hắn đã biết, nhưng hắn vẫn ngồi đó, nhắm mắt, thở, như thể nếu hắn không mở mắt thì bà vẫn chỉ đang ngủ.

Đàn ra dần. Từng con một. Không ai kêu to. Chúng ngồi xuống quanh bà, trên gờ, trên những tảng đá dưới chân vách, trong cửa động. Lũ nhỏ cũng ngồi, im lặng, không hiểu nhưng biết là phải im lặng. Khỉ con lông nâu nhạt bò tới, chạm vào tay bà, rồi ngồi sát bên cạnh, không đi.

Con tai sứt ra sau cùng. Nó đứng ở cửa động rất lâu, rồi ngồi xuống ngay đó, quay lưng vào vách, nhìn bà.

Sáng hôm ấy, không ai ra thung lũng ăn.

---

Đến trưa, hắn bế bà lên.

Bà nhẹ hơn hắn tưởng. Nhẹ như một bó cành khô. Hắn ôm bà trước ngực, men theo dây leo qua gờ, xuống chân vách, đi dọc dòng suối thoát ra thung lũng. Đàn đi theo sau, im lặng.

Hắn dừng lại dưới cây quả vàng thứ ba bên suối. Cây bà chỉ cho lũ nhỏ là ngọt nhất.

Hắn đặt bà xuống bãi đất dưới gốc cây. Rồi hắn đi nhặt đá.

Ở đời trước, người ta chôn người chết, hoặc thiêu. Hắn không có gì để đào, cũng không có lửa. Nhưng hắn nhớ có những nơi người ta xếp đá lên, thành một đống, để thú không đào lên được, để người sau biết chỗ đó có người nằm.

Hắn đặt hòn đá đầu tiên cạnh bà. Rồi hòn thứ hai.

Đàn khỉ nhìn. Chúng không hiểu hắn làm gì. Khỉ không chôn ai. Khi một con chết, đàn ngồi quanh một lúc, rồi đi. Có con mẹ ôm xác con nhỏ mấy ngày liền mới chịu buông. Nhưng không ai xếp đá.

Hắn đặt hòn thứ ba, thứ tư.

Rồi khỉ đực to con bước tới. Nó cúi xuống, nhặt một hòn đá to bằng đầu nó, mang tới, đặt cạnh những hòn của hắn. Nó không nhìn hắn. Nó quay đi nhặt hòn khác.

Con tai sứt là đứa thứ ba. Rồi khỉ mẹ lông nâu đỏ. Rồi mấy con đực trẻ. Rồi cả lũ nhỏ, mỗi đứa ôm một hòn sỏi, đặt vào chỗ hở giữa những hòn đá to.

Đến khi mặt trời ngả về tây, dưới gốc cây quả vàng thứ ba đã có một đống đá cao ngang đầu hắn.

Khỉ con lông nâu nhạt là đứa cuối cùng. Nó cầm trong tay một nhân hạt đã đập sẵn, trắng ngà. Nó trèo lên đống đá, đặt nhân hạt ấy lên hòn đá trên cùng. Rồi nó tụt xuống, chạy về chỗ mẹ.

Hắn đứng nhìn nhân hạt trắng trên đỉnh đống đá, và lần đầu tiên từ khi ra khỏi tiên thạch, hắn khóc mà không phải vì đau.

---

Đêm ấy, hắn ngồi trên gờ một mình.

Chỗ bà nằm sáng nay giờ trống trơn. Ánh trăng qua màn nước rơi xuống, nhạt nhòa.

Ngươi hứa nhiều quá.

Hắn đã hứa dạy lũ nhỏ đường nước ở đất mới. Bà đã tự học, tự dạy, rồi nhìn chúng đi đúng đường. Hắn chẳng giữ được lời hứa nào cả. Bà giữ hộ hắn.

Ngươi đi được rồi.

Bà nói câu ấy từ hơn một tháng trước. Hắn đã không trả lời. Hắn đã ở lại, giao việc, cào vết lên thân cây, tự nói với mình rằng còn phải chuẩn bị thêm. Có lẽ một phần trong hắn đã chờ. Chờ cái sáng mà bà không ho nữa.

Giờ không còn gì để chờ.

Khi mưa dứt, hắn sẽ đi.

---

Hắn nói với đàn vào một buổi sáng, ở giữa gian động, trước tấm bia.

Hắn không biết nói thế nào cho đàn hiểu “biển”, “thầy”, “học phép không chết”. Đàn khỉ không có chữ cho những thứ ấy. Hắn chỉ nói: ta đi qua nước lớn kia, xa lắm, tìm một người biết những thứ ta không biết. Ta không biết bao giờ về.

Đàn im lặng. Rồi có mấy tiếng kêu khẽ, lo lắng.

— Khi có gấu — hắn nói — các ngươi nhìn ai?

Đàn khỉ nhìn nhau. Rồi từng con một, chúng quay đầu về phía khỉ đực to con. Khỉ đực to con đứng ở cửa động như mọi khi, chặn giữa đàn và gờ đá.

— Khi lạc đường, nhìn ai?

Lần này đàn quay sang con tai sứt. Con tai sứt đang ngồi cạnh sơ đồ trên nền động, mảnh đá trắng trong tay.

Hắn gật đầu. Không cần nói thêm. Đàn đã chọn.

Nhưng khi hắn quay lại tìm con tai sứt, nó đã không còn ở đó.

---

Đến đêm hắn mới tìm thấy nó.

Nó ngồi trên một mỏm đá ngoài thác, phía dưới vũng, nơi nước tung bọt trắng. Hắn trèo xuống, ngồi cạnh. Nước bắn lên ướt lông cả hai.

— Ngươi cũng đi — con tai sứt nói. Nó không quay sang. — Như anh ta.

Hắn đã biết nó sẽ nói câu ấy. Hắn đã nghĩ suốt buổi chiều xem phải trả lời thế nào.

— Anh ngươi không về được — hắn nói. — Ta về.

— Sao ngươi biết?

Hắn có thể nói: ta biết. Ta đã đọc chuyện này rồi. Con khỉ đá đi học phép, rồi về, rồi đánh tan con quỷ chiếm núi, rồi cả bầy lấy họ của nó. Nhưng hắn đã quyết định đi sớm hàng trăm năm. Hắn đã làm lệch câu chuyện ấy. Hắn không biết nữa.

— Ta không biết — hắn nói.

Con tai sứt quay sang nhìn hắn.

— Ta không biết — hắn nói lại. — Có thể ta chết ngoài biển. Có thể ta tới nơi mà người ta không nhận. Có thể lâu lắm. — Hắn nhìn ra màn thác trắng xóa trong đêm. — Nên ta cần ngươi ở đây. Ta về mà núi không còn, đàn không còn, thì ta về làm gì.

Con tai sứt im lặng rất lâu. Tiếng thác gầm rú át cả tiếng gió.

— Ta muốn đi theo — cuối cùng nó nói, rất nhỏ.

— Ta biết.

— Ta không muốn đứng ở rìa nhìn ngươi đi.

— Ta biết.

Con tai sứt cúi đầu, nhìn bàn tay mình. Hắn chờ.

— Mỗi sáng ngươi vạch một đường lên vách — con tai sứt nói. — Ai vạch khi ngươi đi?

Hắn nhìn nó. Rồi hắn mò trong đám lông ở ngực, lấy ra mảnh đá trắng hắn vẫn dùng để vạch mỗi sáng. Hắn đặt nó vào lòng bàn tay con tai sứt.

Con tai sứt nhìn mảnh đá trắng rất lâu. Rồi nó nắm chặt lại.

— Mỗi sáng — nó nói. — Ta vạch. Ngươi về thì đếm.

— Ta đếm.

---

Mưa dứt hẳn khi trên vách đã có hơn một trăm vạch.

Hắn làm bè ở sườn bắc, nơi có rừng thông và một bụi tre già. Hắn bẻ những cành thông to, thẳng, dài gấp đôi thân mình. Hắn chọn một cây tre, cắn đứt gốc, tước hết cành, làm sào. Rồi hắn buộc.

Nút đơn, như dạy đàn buộc dây leo dọc gờ. Tay phải giờ đã cầm chắc như tay trái. Nhưng con tai sứt và mấy con đực trẻ buộc nhanh hơn hắn, chặt hơn hắn. Chúng đã buộc dây leo trên gờ thác suốt cả mùa mưa, sau mỗi trận lũ. Hắn để chúng buộc.

Cái bè nhỏ, chỉ đủ cho một con khỉ ngồi, thêm một bó quả vàng và một ống tre đựng nước, bịt bằng lá.

Đàn khiêng bè xuống bờ biển. Không phải bờ biển gần thác. Bờ biển ở chân núi phía đông, dưới bãi tiên thạch, nơi hôm đầu tiên hắn nhìn thấy sóng đập vào những cột đá đỏ. Đường xuống dốc và xa. Đến nơi thì trời đã gần trưa.

Gió thổi từ núi ra biển.

Hắn đẩy bè xuống nước. Sóng đánh vào, bè chao đi, rồi nổi. Hắn trèo lên, cầm sào.

Hắn quay lại.

Đàn khỉ đứng trên những vách đá đỏ sát bờ. Khỉ đực to con đứng cao nhất. Khỉ mẹ lông nâu đỏ với khỉ con lông nâu nhạt trên lưng. Khỉ mẹ lông nâu sẫm ôm con. Lũ nhỏ bám kín những mỏm đá, nhìn cái bè bằng đôi mắt tròn xoe.

Con tai sứt đứng trên cột đá thấp nhất, sát mép nước. Sóng đập vào chân cột đá, tung bọt trắng lên tới tận người nó. Nó không lùi.

Khỉ không vẫy tay. Không ai trong đàn vẫy. Chúng chỉ đứng đó, nhìn.

Hắn chống sào. Bè rời bờ. Gió đẩy nó ra xa, từng chút, từng chút. Hắn không quay lại nữa cho tới khi tiếng sóng đập vào cột đá đã nhỏ hẳn.

Rồi hắn quay lại.

Lần đầu tiên, hắn nhìn thấy ngọn núi từ bên ngoài.

Rừng xanh phủ kín sườn núi. Những vách đá đỏ đứng sát biển. Trên cao, những chóp núi lẫn trong mây. Và ở lưng chừng, nhỏ xíu, có một vệt trắng. Thác.

Hắn chưa bao giờ thấy nó từ bên ngoài. Nó nhỏ hơn hắn tưởng.

Và hắn chưa bao giờ muốn quay về một nơi đến thế.


# Tái sinh Tề Thiên

## Chương 11 · Biển

Ngày đầu tiên trên biển, hắn hát.

Không phải bài nào cụ thể. Chỉ là mấy câu nhớ mang máng từ đời trước, lời lộn xộn, giai điệu sai bét. Tiếng khỉ không hợp để hát. Nhưng gió đẩy bè đi băng băng, mặt trời rải vàng trên sóng, ngọn núi sau lưng mỗi lúc một nhỏ, và hắn thấy cần phải phát ra một tiếng gì đó cho cái im lặng bớt to.

Đến chiều, ngọn núi chỉ còn là một chấm mờ ở chân trời. Rồi chấm mờ ấy cũng chìm.

Hắn ngừng hát.

Xung quanh chỉ có nước. Nước xanh thẫm, nước sủi bọt trắng, nước lấp lánh, nước tới tận chân trời ở cả bốn phía. Không một cái cây. Không một tảng đá. Không ai để nói.

Hắn chợt nhận ra từ lúc ra khỏi tiên thạch tới giờ, chưa có ngày nào hắn ở một mình. Ngày đầu tiên, chưa xuống tới chân núi đã gặp con tai sứt. Rồi đàn. Rồi khỉ già. Rồi cả trăm ngày sống giữa tiếng kêu chí chóe của lũ nhỏ, tiếng ho của bà, tiếng con tai sứt cằn nhằn.

Giờ chỉ có tiếng sóng vỗ vào thân bè.

Hắn ngồi ôm sào, nhìn mặt trời lặn xuống biển. Mặt trời lặn ở phía tay phải hắn. Vậy bè đang trôi về phía nam, hơi chếch tây. Ở đời trước, hắn học được cái đó từ đâu đó, chẳng nhớ nổi nữa. Mặt trời mọc đằng đông, lặn đằng tây. Ở đây, nó vẫn thế.

Trong sách, gió đưa bè của khỉ đá tới một châu ở phía nam. Gió đang đưa bè của hắn về phía nam.

Ít nhất có một thứ vẫn đúng.

---

Rạng sáng ngày thứ hai, hắn ngồi xếp bằng giữa bè.

Không có hõm đá, không có màn nước. Chỉ có những cành thông ướt dưới mông và gió biển lạnh buốt lùa qua lớp lông. Hắn nhắm mắt, thở, không trông đợi gì nhiều.

Rồi mặt trời nhô lên khỏi mặt biển.

Khí đến. Không dịu dàng như ở gờ sau màn nước. Nó ập tới như hôm đầu tiên trong hõm tiên thạch, khi gió biển và nắng đầu ngày cùng chạm vào người hắn. Đốm ấm dưới rốn bừng sáng. Hơi ấm lan ra, không chỉ xuống chân mà khắp người, như tắm nắng từ bên trong.

Hắn mở mắt, nhìn quanh.

Gió biển. Nắng đầu ngày. Tiên thạch đã đứng trên đỉnh núi sát biển bao nhiêu năm, mỗi sáng đều đón gió biển và nắng đầu ngày như thế này. Có lẽ đó là lý do khí ở hõm đá mạnh hơn mọi nơi. Không phải vì đá có phép. Chỉ là đá đã ngồi ở đó, đúng chỗ, đủ lâu.

Đốm ấm vẫn không lớn hơn. Cái bát vẫn chỉ đầy chừng ấy. Nhưng khi nắng lên cao và khí dịu xuống, hắn thấy đầu óc tỉnh táo hơn hẳn, người bớt mỏi.

Hắn tự nhủ: mỗi sáng phải ngồi thế này. Biển không cho hắn nước ngọt. Nhưng ít nhất nó cho hắn thứ này.

---

Ngày thứ ba, nước trong ống tre còn hơn một nửa. Ngày thứ tư, còn một phần ba.

Hắn chia từng ngụm. Sáng một ngụm, trưa một ngụm, tối một ngụm. Ngậm thật lâu trong miệng rồi mới nuốt. Bó quả vàng mang theo đã bắt đầu mềm nhũn, bốc mùi chua lè như rượu. Hắn ăn những quả còn ăn được, ném những quả đã thối xuống biển.

Nắng gắt. Không có bóng râm. Muối đọng thành lớp trắng trên lông, trên mặt, trên môi. Môi hắn nứt ra, rớm máu. Mỗi lần liếm môi lại mặn chát.

Dưới bè có cá. Một đàn cá nhỏ, ánh bạc, bơi theo cái bóng của bè như bơi theo một khúc gỗ trôi. Hắn nằm sấp, thò tay xuống, chờ. Một con bơi qua sát tay. Hắn chộp. Nước bắn tung tóe. Tay rỗng.

Hắn thử lại. Lại rỗng.

Lần thứ mười, hắn nằm ngửa ra trên bè, nhìn trời, bật cười.

Tề Thiên Đại Thánh tương lai, kẻ sẽ đại náo Thiên Cung, kẻ sẽ khiến cả Tam Giới chấn động. Chết khát giữa biển vì không bắt nổi một con cá nhỏ.

Nếu con tai sứt ở đây, nó sẽ cười tới mức rơi xuống biển.

---

Đêm thứ năm, giông tới.

Hắn không thấy nó tới. Trời tối, mây che kín sao. Chỉ có gió, mỗi lúc một mạnh, mỗi lúc một lạnh. Rồi sóng. Sóng không còn vỗ vào thân bè nữa mà nhấc cả bè lên cao, rồi thả xuống. Lên. Xuống. Lên cao hơn. Xuống sâu hơn.

Rồi sét.

Một tia sáng trắng xé ngang trời, soi rõ cả mặt biển. Hắn thấy một bức tường nước đen sì đang dựng lên ngay trước mặt, cao gấp mấy lần cái bè.

Hắn ôm chặt sào, cúi đầu.

Bức tường nước đổ xuống. Cả thế giới chìm vào nước. Bè bị quật nghiêng, vặn xoắn như một cái lá. Hắn nghe tiếng dây leo căng ra, kêu cót két. Rồi một tiếng phựt.

Một nút buộc tuột.

Hắn cảm thấy hai cành thông dưới chân mình tách ra, trượt đi, trôi mất vào bóng tối. Bè chao hẳn sang một bên. Hắn bò về phía những cành còn lại, móng cào vào vỏ thông.

Những cành còn lại vẫn dính vào nhau.

Hắn sờ vào chỗ buộc. Nút thắt chặt, gọn, quấn hai vòng thay vì một. Không phải nút của hắn. Nút của con tai sứt. Hắn nhớ con tai sứt đã giật lấy dây leo từ tay hắn, cằn nhằn rằng hắn buộc lỏng quá.

Nút của hắn tuột. Nút của nó giữ.

Hắn ôm chặt những cành thông ấy, ôm cả sào, cả ống tre, nằm áp người xuống bè.

Rồi mưa đổ xuống.

Mưa lạnh, mưa nặng hạt, mưa quất vào lưng như roi. Hắn nằm trong mưa một lúc lâu mới chợt hiểu ra. Hắn ngồi bật dậy, giật lá bịt miệng ống tre ra, giơ ống tre lên trời.

Nước mưa rơi vào. Lẫn cả nước biển do sóng tạt. Nhưng phần lớn là nước mưa.

Hắn ngửa cổ, há miệng, uống nước mưa từ trời. Uống, rồi lại uống. Nước lạnh, ngọt, có vị muối. Hắn cười như điên giữa cơn giông, giữa sét, giữa sóng.

---

Đến sáng, bè chỉ còn một nửa.

Bó quả vàng không còn. Một nửa số cành thông không còn. Cây sào vẫn còn, ống tre vẫn còn, đầy nước. Nước hơi mặn, nhưng uống được.

Giông đã qua. Biển lặng như chưa từng có chuyện gì. Gió cũng lặng. Bè không trôi nữa, cứ nằm đó, dập dềnh giữa mặt nước phẳng lì.

Ngày thứ sáu. Ngày thứ bảy.

Hắn đói. Cái đói không còn là cảm giác cồn cào nữa, mà là một khoảng trống, một sự yếu ớt lan khắp người. Ngồi lâu là chóng mặt. Đứng dậy là hoa mắt.

Hắn tìm thấy một đoạn dây leo thừa quấn ở góc bè. Mỗi sáng sau khi ngồi luyện, hắn thắt một nút lên đó. Bảy nút. Ở Hoa Quả Sơn, con tai sứt chắc đã vạch thêm bảy đường lên vách động.

Hắn tự hỏi giờ này lũ nhỏ đang làm gì. Có đứa nào lại chạy lên cầu sắt lúc trơn không. Khỉ đực to con có còn ra kiểm tra dây leo mỗi sáng không. Đống đá dưới cây quả vàng thứ ba có còn nguyên không, hay đã có con thú nào tới bới.

Hắn không biết. Hắn sẽ không biết, cho tới khi về.

Nếu về được.

---

Sáng ngày thứ tám, hắn thấy chim.

Không phải một con. Rất nhiều. Chim biển lông trắng, cánh dài, bay vòng trên đầu hắn, kêu quang quác. Chúng sà xuống mặt nước, bắt cá, rồi bay đi. Tất cả đều bay về cùng một hướng.

Rồi có rong trôi qua. Những dải rong xanh, dài, còn bám cả vỏ ốc.

Gần trưa, một cành cây trôi qua bè. Không phải cành khô, mục, như những thứ hắn thấy ngoài khơi mấy ngày trước. Cành cây còn lá. Lá xanh, tươi.

Hắn nhìn theo hướng chim bay, hướng cành cây trôi tới.

Đất.

Hắn chống sào xuống nước. Không chạm đáy. Hắn vẫn chống, vẫn đẩy, chèo bằng sào như chèo bằng mái chèo, về hướng ấy. Vụng về, chậm chạp. Nhưng bè nhích đi.

---

Ngày thứ chín, khi mặt trời vừa lên, hắn thấy bờ.

Một dải cát vàng dài, chạy ngút tầm mắt. Sau bãi cát là một rừng thông thấp, thân xù xì, mọc nghiêng cả về một phía như bị gió biển đẩy suốt bao năm, lá kim rì rào.

Xa hơn, có mấy làn khói bốc lên.

Khói bếp.

Hắn đứng dậy trên bè, chân run run, nhìn chằm chằm vào những làn khói ấy. Rồi hắn thấy những thứ khác. Mấy chiếc thuyền gỗ nhỏ kéo lên bãi cát. Những tấm lưới phơi trên cọc. Những cái lều mái lá thấp lè tè dưới tán thông.

Và người.

Một nhóm người đang đứng dưới nước ngang đùi, kéo một tấm lưới lớn vào bờ. Đàn ông cởi trần, đàn bà mặc áo vải thô, tóc búi. Mấy đứa trẻ chạy lăng xăng trên bãi cát, nhặt những con cá nhảy ra khỏi lưới.

Hắn đứng chết lặng trên bè.

Người. Người thật. Hai chân, hai tay, không lông, không đuôi. Một trăm hai mươi ngày, hắn chưa nhìn thấy một khuôn mặt người nào. Hắn đã gần quên mất người trông như thế nào.

Bè trôi vào gần hơn. Gió đưa tiếng họ tới.

Họ đang gọi nhau, hò nhau kéo lưới. Một người đàn ông hô lên, những người khác đáp lại. Một đứa trẻ hét. Một người đàn bà cười.

Hắn không hiểu một chữ nào.

Hắn nghe rõ từng tiếng. Âm thanh lên xuống, có nhịp điệu, có trầm có bổng. Hắn biết đó là tiếng người, ngôn ngữ của người. Nhưng nó trượt qua tai hắn như tiếng mưa, như tiếng sóng. Không một âm tiết nào có nghĩa.

Tiếng khỉ, hắn hiểu từ lúc vừa ra khỏi đá. Không ai dạy, hắn cứ thế mà hiểu. Còn tiếng người, thứ tiếng của đời trước, thứ tiếng hắn từng nói suốt mấy chục năm, giờ lại xa lạ như tiếng chim.

Có lẽ họ nói một thứ tiếng khác. Có lẽ đây là đất của người xưa, nói thứ tiếng của người xưa. Có lẽ cả hai.

Hắn đứng trên bè, nhìn những con người đang kéo lưới, và thấy mình cô độc hơn cả lúc giữa biển.

---

Hắn không cập bè vào chỗ xóm chài. Hắn chống sào men theo bờ, tới một mỏm đá cách đó một quãng xa, khuất sau một doi cát. Hắn kéo bè lên đá, rồi ngồi phịch xuống, thở.

Đất. Đất cứng dưới chân. Không chao, không dập dềnh.

Hắn nằm ngửa trên đá một lúc lâu.

Rồi cơn khát kéo hắn dậy. Ống tre đã gần cạn, và nước trong đó mặn chát. Hắn đi dọc bờ, chân lảo đảo, mắt tìm kiếm. Cách mỏm đá không xa, có một con lạch nhỏ chảy từ trong rừng thông ra, đổ xuống biển. Hắn quỳ xuống bờ lạch, vục mặt vào.

Nước ngọt.

Hắn uống tới khi bụng căng lên, rồi nằm vật ra bên bờ lạch.

Khi đã đỡ hơn, hắn bắt đầu nghĩ tới chuyện ăn. Và chuyện người.

Hắn đi men theo rìa rừng thông, về phía xóm chài. Đi chậm, nép sau những thân cây. Hắn không định làm gì cả. Hắn chỉ muốn nhìn họ gần hơn. Muốn nghe họ nói. Muốn biết mình đã tới đâu.

Đến rìa xóm, hắn dừng lại sau một gốc thông, nhìn.

Mấy cái lều mái lá. Một đống lửa đang cháy, trên có một cái nồi đất. Mùi cá nướng. Mùi khói. Mùi người. Những người kéo lưới đã lên bờ, đang ngồi quanh đống lửa, chia cá.

Hắn bước thêm một bước. Một cành thông khô gãy dưới chân.

Một đứa trẻ quay lại.

Nó nhìn thấy hắn. Một con khỉ, lông vàng nâu bết muối, gầy trơ xương, đứng thẳng trên hai chân sau gốc cây. Đứng thẳng, như người.

Đứa trẻ há miệng. Rồi nó hét.

Những người lớn quay lại. Một người đàn ông đứng phắt dậy, nhìn hắn. Mắt ông ta mở to, miệng há ra. Rồi ông ta hét lên một tiếng. Một tiếng rất ngắn, chỉ hai âm.

Sau này, rất lâu sau này, khi đã hiểu được tiếng người ở đây, hắn mới biết hai âm ấy nghĩa là gì.

Yêu quái.

Người đàn ông vớ lấy một hòn đá, ném. Hòn đá bay sượt qua vai hắn. Những người khác cũng vớ lấy đá, lấy gậy, lấy bất cứ thứ gì trong tầm tay. Rồi không ai ném nữa. Đàn bà túm lấy trẻ con, đàn ông lùi lại, và cả xóm chài bỏ chạy. Chạy vào rừng thông, chạy về phía bên kia, vừa chạy vừa hét.

Chỉ trong mấy nhịp thở, bãi cát đã trống trơn.

Hắn đứng giữa xóm chài, bên cạnh đống lửa đang cháy, cái nồi đất đang sôi. Hắn không đuổi theo. Hắn chỉ đứng đó, nhìn về phía rừng thông, nơi những tiếng hét nhỏ dần.

Hắn không làm gì cả. Hắn chỉ đứng thẳng.

---

Hắn ăn một con cá nướng bên đống lửa. Con cá đầu tiên trong đời này. Nó ngon tới mức hắn suýt khóc.

Rồi hắn nhìn quanh.

Trên một tảng đá phẳng cạnh lều, có một bộ áo đang phơi. Vải thô, màu nâu xám, đã khô cong vì nắng. Một cái áo dài tay, một cái quần ống rộng, một sợi dây vải để buộc.

Hắn cầm lên. Vải ráp, nặng, có mùi khói và mùi cá.

Trong sách, khỉ đá lấy quần áo của người đánh cá, mặc vào, rồi đi giữa loài người học lễ nghi, học tiếng nói.

Hắn nhìn về phía rừng thông. Hắn nghĩ tới người đàn ông đã ném đá, tới đứa trẻ đã hét. Bộ áo này là của một người trong số họ. Có thể là của người đàn ông kia. Có thể đó là bộ áo duy nhất ông ta có.

Hắn đứng cầm bộ áo rất lâu.

Rồi hắn đặt con cá còn lại, con cá to nhất trong nồi, lên tảng đá chỗ bộ áo vừa phơi. Hắn biết thế chẳng bù được gì. Nhưng hắn không có gì khác để để lại.

Hắn mặc bộ áo vào.

Khó hơn hắn tưởng. Tay áo dài quá, che kín cả bàn tay. Ống quần rộng thùng thình, cứ tuột xuống. Hắn không biết buộc sợi dây vải thế nào, buộc lộn mấy lần mới giữ được quần. Và cái đuôi. Cái đuôi không có chỗ nào để đi. Hắn thử để nó thò ra ngoài, trông như một con khỉ mặc áo. Hắn cuộn nó lại, giấu trong vạt áo, áp sát vào lưng. Khó chịu, vướng víu, nhưng không ai nhìn thấy.

Hắn đi xuống mép nước, tới một vũng nước triều đọng giữa những tảng đá.

Hắn cúi xuống, nhìn.

Một con khỉ mặc áo người nhìn lại hắn. Lông vàng nâu, mặt hẹp, mõm hồng nhạt, đôi mắt hổ phách. Một bộ áo vải thô rộng thùng thình, tay áo xắn lên vụng về. Trông nó vừa buồn cười, vừa thảm hại.

Hắn nhìn con khỉ ấy rất lâu.

Trong sách, chuyện này chỉ có vài dòng. Khỉ đá đi khắp các châu, học lễ nghi, học tiếng người, tám chín năm. Tám chín năm, gói trong một câu.

Hắn đứng trên bãi đá, gió biển thổi phần phật vạt áo, và nghĩ tới tám chín năm ấy.

Muốn tìm người không chết, trước hết hắn phải học làm người.


# Tái sinh Tề Thiên

## Chương 12 · Tiếng người

Mấy tuần đầu, hắn sống như một con thú.

Ban ngày hắn nấp trong rừng thông sau xóm chài, nằm trên những cành cao, nghe. Ban đêm hắn xuống bãi cát, tìm những con cá người ta phơi trên giàn tre, lấy một hai con, rồi lẩn vào bóng tối. Hắn ngủ trong một hốc đá gần con lạch nước ngọt, cuộn tròn trong bộ áo vải thô, đuôi quấn quanh chân.

Hắn không tới gần người nữa. Hắn đã thấy đôi mắt người đàn ông hôm ấy. Hắn đã thấy những hòn đá bay về phía mình.

Nhưng hắn nghe.

Dân chài nói nhiều. Họ gọi nhau lúc kéo lưới, cãi nhau lúc chia cá, mắng con lúc tối về. Hắn nằm trên cành thông, lắng tai, cố bắt lấy từng âm. Lúc đầu, tất cả chỉ là một dòng tiếng lẫn lộn. Rồi dần dần, hắn bắt đầu nhận ra những âm lặp lại.

Có một âm ngắn, đàn ông hay hô lên mỗi lần lưới nặng tay. Có một âm hơi dài hơn, đàn bà hay gọi khi lửa đã cháy. Có một âm trẻ con hét mỗi lần chạy xuống nước.

Hắn đoán. Âm thứ nhất có lẽ là “kéo”. Âm thứ hai có lẽ là “ăn”. Âm thứ ba có lẽ là “nước”, hoặc “biển”, hoặc chỉ là tiếng hét của trẻ con.

Ở đời trước, hắn từng học một ngoại ngữ. Hắn nhớ mang máng thầy dạy rằng trẻ con học tiếng mẹ đẻ bằng cách nghe hàng nghìn lần, rồi bắt chước. Không ai dạy ngữ pháp cho trẻ con.

Vậy thì hắn làm trẻ con.

Đêm đêm, ngồi trong hốc đá, hắn tập phát ra những âm ấy. Khó hơn hắn tưởng nhiều. Miệng khỉ không giống miệng người. Môi mỏng, mõm dài, lưỡi nằm khác chỗ. Âm nào phát ra cũng méo mó, khàn khàn, như tiếng một con quạ bị nghẹn. Hắn tập mãi. Tập đến mỏi cả quai hàm.

Có một đêm, sau khi lấy hai con cá trên giàn tre, hắn đứng lại nhìn chỗ trống trên giàn. Hắn nghĩ tới bộ áo đang mặc, tới con cá to hắn đã để lại hôm đầu. Hắn nghĩ tới đứa trẻ nhà ấy sẽ ăn ít đi hai con cá.

Đêm hôm sau, trước khi lấy cá, hắn để lại dưới giàn tre một bó củi khô hắn nhặt trong rừng thông. Đêm sau nữa, một nắm vỏ sò đẹp. Hắn không biết vỏ sò có đáng gì với người ở đây không. Nhưng hắn không lấy không được nữa.

---

Ông lão sống ở cái lều cuối xóm, tách xa những lều khác.

Hắn để ý tới ông vì ông không bao giờ ra biển. Sáng nào ông cũng ngồi trước lều, tay vá lưới. Tay ông nhanh lạ thường, những ngón tay gầy guộc luồn sợi, thắt nút, kéo căng, không cần nhìn. Mà ông cũng không nhìn được. Hai mắt ông trắng đục như vỏ trứng.

Ông sống một mình. Không ai mang cá tới cho ông, trừ những hôm có người trả lưới vá xong. Tối nào ông cũng phải lần mò ra con lạch, kéo nước về, đi chậm, tay quờ quạng.

Một tối, hắn đặt một bó củi khô trước cửa lều ông lão.

Ông lão đang ngồi trong lều. Ông nghiêng đầu, nghe. Rồi ông nói một câu. Hắn không hiểu hết. Hắn chỉ nhận ra một âm hắn đã nghe rất nhiều lần, âm mà dân chài hay dùng để gọi nhau. Có lẽ là “ai”.

Hắn đứng im, không biết làm gì.

Ông lão lại nói, chậm hơn. Rồi ông giơ tay ra, quờ về phía hắn đứng.

Hắn lùi lại một bước. Rồi, không hiểu vì sao, hắn bước tới. Hắn đặt bàn tay mình vào bàn tay ông lão.

Ông lão nắm lấy. Những ngón tay gầy guộc, chai sạn vì sợi lưới, siết nhẹ quanh bàn tay hắn. Ông lão im lặng một lúc. Rồi ông buông ra, cười. Ông nói một câu dài, giọng không có chút sợ hãi nào.

Hắn không hiểu. Hắn mở miệng, cố phát ra một âm. Một tiếng khàn khàn, méo mó, bập bẹ.

Ông lão lại cười. Rồi ông chỉ tay vào bó củi.

— Củi — ông nói. Chậm, rõ.

Hắn nhìn bó củi. Hắn nhìn ông lão.

— C… cui.

Ông lão gật đầu. Ông chỉ vào ngọn lửa nhỏ trong lều.

— Lửa.

— Lư… lửa.

Ông lão vỗ đùi, cười to, nói một câu gì đó với giọng hài lòng. Rồi ông chỉ vào cái lưới đang vá dở.

Đêm ấy, hắn học được mười hai từ.

---

Từ hôm đó, tối nào hắn cũng tới lều cuối xóm.

Hắn mang củi. Hắn kéo nước từ lạch về, đổ đầy cái chum sành sứt miệng trong lều. Hắn ngồi cạnh ông lão, học vá lưới. Tay khỉ khéo hơn tay người ở nhiều chỗ, nhưng hắn vụng về với sợi. Ông lão sờ những mắt lưới hắn vá, chê, tháo ra, bắt vá lại.

Và ông dạy.

Ông dạy như dạy trẻ con. Chỉ vào một vật, nói tên nó. Bắt hắn nói lại. Sai thì sửa. Đúng thì gật. Khi hắn đã biết tên đủ thứ trong lều, ông bắt đầu dạy những câu ngắn. “Đưa ta cái kia.” “Nước đầy chưa.” “Trời sắp mưa.”

Ông gọi hắn bằng một từ. Hắn mất mấy tuần mới hiểu nghĩa từ ấy.

“Thằng câm.”

Ông nghĩ hắn là một đứa trẻ lang thang, câm điếc từ bé, mới học nói. Hắn không cải chính. Hắn cũng chẳng biết cải chính thế nào.

Những đêm ở hốc đá, hắn tập nói những câu ông dạy, tập đi tập lại tới khi khản cổ. Rạng sáng, hắn ra ghềnh đá ven biển, ngồi luyện khí như mọi khi. Gió biển, nắng đầu ngày. Khí vẫn đến mạnh, vẫn đầy chừng ấy, không hơn. Hắn đã thôi mong nó lớn thêm. Hắn chỉ ngồi để giữ thói quen, để nhớ mình đang đi đâu.

---

Mùa đổi. Gió chuyển hướng. Rồi lại đổi.

Đến khi hắn nói được những câu dài hơn, ông lão bảo hắn theo ra chợ.

— Bán lưới — ông nói. — Ta mù, đi một mình bị lừa.

Hắn đội cái nón lá cũ treo trong lều, kéo vành sụp xuống che mặt. Áo vải thô, quần ống rộng, đuôi cuộn chặt trong vạt áo. Hắn dắt ông lão đi, tay kia vác bó lưới.

Thị trấn chợ cách xóm chài nửa buổi đi bộ, nằm ở cửa một con sông đổ ra biển. Hắn chưa bao giờ thấy nhiều người như thế từ khi tới đây. Người đi, người đứng, người ngồi, người gánh, người kéo xe. Tiếng rao, tiếng cãi, tiếng cười, tiếng chửi. Mùi cá, mùi thịt, mùi khói, mùi phân trâu.

Hắn bám chặt tay ông lão, kéo vành nón sụp thêm.

Ở chợ, hắn thấy tiền. Những đồng tròn có lỗ vuông ở giữa, xâu thành chuỗi bằng dây. Người ta đổi cá lấy tiền, đổi tiền lấy gạo, lấy vải, lấy muối. Người ta cân, người ta đo, người ta mặc cả, giọng to dần, mặt đỏ dần, vì một hai đồng.

Hắn thấy một người mặc áo dài màu sẫm, đội mũ, có mấy người cầm gậy đi theo. Ông ta đi dọc hàng cá, chỉ chỗ này, chỉ chỗ kia. Những người cầm gậy lấy cá của người bán, bỏ vào giỏ. Người bán không dám nói gì. Một bà lão níu tay một người cầm gậy, nói gì đó, bị hất ra, ngã xuống đất.

— Quan thu thuế — ông lão nói khẽ, không cần hắn hỏi. Ông nghe thấy.

Hắn đứng nhìn bà lão lồm cồm bò dậy, nhặt mấy con cá còn sót lại.

Trong sách, chuyện này chỉ có một câu. Khỉ đá đi giữa loài người, thấy người đời chỉ chạy theo danh lợi, không ai lo cho tính mạng mình. Một câu.

Ở đây, câu ấy là một bà lão ngã dưới đất vì mấy con cá.

---

Ở góc chợ, có một người trải chiếu, trên chiếu bày những cái lọ sành nhỏ.

Người ấy mặc áo đạo sĩ, tóc búi cao, râu dài, tay phe phẩy cái phất trần. Ông ta nói to, giọng sang sảng. Hắn giờ đã hiểu được kha khá. Ông ta nói trong lọ là tiên đan. Uống một viên sống thêm mười năm. Uống mười viên sống trăm tuổi. Ông ta đã sống ba trăm năm nhờ nó.

Đám đông chen chúc quanh chiếu. Người ta móc tiền, giành nhau mua.

Hắn đứng ở rìa, nhìn. Tim hắn đập nhanh một nhịp. Tiên đan. Trường sinh.

Rồi hắn nhìn khuôn mặt ông đạo sĩ. Nếp nhăn, đồi mồi, răng vàng khè. Một khuôn mặt sống chừng năm mươi năm, không hơn.

Một người mua xong, mở lọ ra xem, làm rơi một viên. Viên thuốc lăn tới gần chân hắn. Hắn cúi xuống nhặt, đưa lên mũi.

Bột gạo. Mật ong. Và tro bếp.

Hắn đứng cầm viên thuốc, nhìn đám đông vẫn đang giành nhau mua. Hắn có thể nói. Hắn có thể bóp vụn viên thuốc trước mặt mọi người, chỉ cho họ thấy bên trong chỉ là gạo và tro.

Nhưng nếu hắn đứng ra, người ta sẽ nhìn hắn. Sẽ nhìn dưới vành nón. Sẽ thấy cái mõm khỉ.

Hắn đặt viên thuốc xuống đất, quay đi.

Trên đường về, hắn kể với ông lão. Ông lão nghe xong, cười khùng khục.

— Thế mà vẫn có người mua.

— Sao… họ mua? — hắn hỏi. Câu hỏi còn vấp, nhưng ông lão hiểu.

— Ai mà chẳng muốn không chết — ông lão nói.

Hắn im lặng. Hắn nghĩ tới mình. Hắn cũng đang đi tìm thứ ấy. Hắn cũng bỏ nhà, bỏ đàn, vượt biển, chỉ vì thứ ấy.

Trong sách, tiên không ở chợ. Tiên ở trong động sâu, trên núi xa, bên kia biển tây. Hắn biết thế. Những người ở chợ kia không biết. Họ chỉ có ông đạo sĩ với cái chiếu và mấy lọ sành.

---

Đến mùa thứ ba ở xóm chài, tin đồn về yêu khỉ lan tới thị trấn.

Hắn nghe được ở chợ. Người ta kể có một con yêu khỉ sống ở rừng thông ven biển. Nó trộm cá, mặc áo người, đi đứng như người. Có người còn kể nó biết nói. Có người kể nó bắt trẻ con. Có người kể đêm đêm nghe nó hú dưới trăng.

Hắn không bắt trẻ con. Cũng chưa từng hú dưới trăng. Nhưng tin đồn chẳng cần đúng.

Mấy hôm sau, xóm chài mời một thầy pháp.

Ông ta tới vào lúc chạng vạng, mặc áo vàng, tay cầm một xấp bùa giấy vàng vẽ chữ đỏ, theo sau là hai con chó săn to, lông xám, mõm dài. Dân chài đốt đuốc, đi theo ông ta vào rừng thông.

Hắn nghe tiếng chó sủa từ hốc đá.

Hắn chạy. Không phải vào sâu trong rừng, nơi đuốc đang tràn tới. Hắn chạy về phía xóm, về phía lều cuối xóm.

Ông lão đang ngồi trong lều. Ông nghe tiếng chân hắn, nghe tiếng thở dốc của hắn. Ông không hỏi gì.

— Xuống dưới — ông lão nói, chỉ vào đống lưới cũ chất ở góc lều.

Hắn chui xuống dưới đống lưới, nằm im. Lưới cũ nặng mùi tanh, mùi muối. Ông lão kéo thêm mấy tấm lưới phủ lên, rồi ngồi xuống ngay trên đống lưới, cầm một tấm lên vá tiếp.

Tiếng chó sủa tới gần. Tiếng đuốc nổ lách tách. Tiếng người.

Hai con chó dừng lại trước cửa lều, sủa dữ dội. Một giọng đàn ông, giọng thầy pháp, nói to:

— Nó ở đây. Chó đánh hơi được.

Ông lão không ngẩng đầu, tay vẫn vá lưới.

— Ở đây có ông già mù với mấy đống lưới thối — ông nói. — Chó của ông đánh hơi được cá ươn thì có.

— Lão già, tránh ra.

— Tránh đi đâu? — Ông lão ngẩng lên, đôi mắt trắng đục nhìn thẳng vào chỗ có tiếng nói. — Ông vào lều ta, đạp lên lưới của người ta gửi vá, mai ông đền à? Ông đền được không? Mỗi tấm hai mươi đồng.

Có tiếng xì xào ngoài cửa. Có tiếng ai đó nói gì đó với thầy pháp, giọng nhỏ. Rồi tiếng thầy pháp lầm bầm. Rồi tiếng chân, tiếng chó, tiếng đuốc, xa dần.

Hắn nằm dưới đống lưới rất lâu, cho tới khi ông lão gõ gõ lên lưới.

— Ra đi. Đi rồi.

---

Hắn chui ra, ngồi xuống đất, không dám nhìn ông lão.

Ông lão vẫn vá lưới. Tay ông vẫn nhanh như mọi khi. Một lúc lâu sau, ông mới nói:

— Hôm đầu tiên ngươi mang củi tới. Ngươi đặt tay vào tay ta.

Hắn ngẩng lên.

— Tay ngươi có lông — ông lão nói. — Cả mu bàn tay. Người ta làm gì có lông như thế.

Hắn không nói được gì.

— Ta mù — ông lão nói. — Không ngu.

Ông đặt tấm lưới xuống, quay mặt về phía hắn. Đôi mắt trắng đục không nhìn thấy gì, nhưng hắn cảm thấy như ông đang nhìn xuyên qua mình.

— Ngươi là cái gì?

Hắn im lặng rất lâu. Rồi hắn mở miệng. Lần đầu tiên, hắn nói một câu dài bằng tiếng người, chậm, khàn, vấp váp, nhưng trọn vẹn.

— Ta là khỉ. Sinh ra từ đá, ở một ngọn núi bên kia biển đông. Ta đi tìm người dạy cách không chết.

Ông lão ngồi im. Ngọn lửa nhỏ trong lều nổ lách tách.

— Khỉ sinh ra từ đá — ông lão lặp lại, chậm rãi. — Đi tìm cách không chết.

Ông bật cười. Không phải tiếng cười chế nhạo. Một tiếng cười khàn, dài, như người vừa nghe một câu chuyện hay.

— Bọn ngoài kia bảo ngươi là yêu. — Ông lão lắc đầu. — Người với yêu khác nhau chỗ nào? Ta mù rồi. Ta chẳng thấy mặt ai. Ta chỉ biết đứa nào kéo nước cho ta.

Ông cầm tấm lưới lên, vá tiếp.

— Mai nhớ kéo nước. Chum cạn rồi.

---

Hắn ở lại xóm chài thêm gần nửa năm.

Không ai lùng yêu khỉ nữa. Thầy pháp không bắt được gì, lấy tiền rồi đi. Tin đồn nhạt dần, rồi thành chuyện kể cho trẻ con sợ.

Hắn vẫn tới lều ông lão mỗi tối. Vẫn kéo nước, vá lưới, học nói. Giờ hắn nói được nhiều hơn, nhanh hơn. Giọng vẫn khàn, vẫn lạ, ông lão bảo nghe như người miền núi xa nào đó nói tiếng ở đây. Nhưng người ở chợ đã hiểu hắn. Hắn đã tự đi chợ bán lưới cho ông lão, mặc cả, đếm tiền, không ai nhìn dưới vành nón.

Một buổi chiều, ở bến sông thị trấn, có một con thuyền lớn cập bến.

Không phải thuyền chài. Thuyền buôn. Hai cột buồm, thân gỗ sẫm màu, mạn thuyền chất đầy hàng hóa bọc vải. Thủy thủ nhảy lên bờ, da đen nhẻm, giọng nói hơi khác người ở đây.

Hắn ngồi ở một góc bến, nghe họ nói chuyện với người buôn trong chợ.

Họ từ phía tây tới. Bên kia biển tây, có một châu đất rất rộng. Người ở đó ít đánh nhau, ít tranh giành. Nhiều người đi tu. Nhiều núi cao, núi nào cũng nghe nói có tiên ở.

Một thủy thủ nói tên châu ấy.

Tây Ngưu Hạ Châu.

Hắn ngồi im, tay nắm chặt vành nón. Đây là lần đầu tiên, từ khi tới đây, hắn nghe thấy một cái tên trong sách từ miệng một người sống. Không phải hắn tự đoán. Không phải hắn suy theo trí nhớ. Một người lạ, không biết gì về hắn, nói ra cái tên ấy.

Hắn biết đường rồi.

---

Đêm cuối cùng, hắn kéo nước tới khi chum đầy tràn, rồi kéo thêm, đổ đầy mấy cái vò sành ông lão để ở góc lều. Đủ cho nửa tháng. Hắn vá xong ba tấm lưới người ta gửi. Hắn chất củi cao ngang vai cạnh cửa lều.

Ông lão ngồi nghe hắn làm, không nói gì. Đến khi hắn làm xong, ông mới lên tiếng.

— Đi à?

— Đi.

— Bên kia biển tây?

— Ừ.

Ông lão gật đầu. Ông lần tay vào góc lều, lôi ra một cái nón lá. Không phải cái nón cũ thủng lỗ chỗ hắn vẫn đội. Một cái nón mới hơn, vành rộng, quai vải.

— Của thằng con ta — ông lão nói. — Nó đi biển, không về. Nón để đó mười năm rồi.

Ông lần tay thêm lần nữa, lôi ra một đôi dép cỏ.

— Đi đường xa phải có dép. Chân khỉ cũng thế.

Hắn cầm cái nón và đôi dép, không nói được gì. Hắn quỳ xuống trước ông lão, cúi đầu. Ông lão không thấy. Nhưng ông có lẽ cảm thấy, vì ông đưa tay ra, đặt lên đầu hắn, xoa một cái, như xoa đầu một đứa trẻ.

Hắn đứng dậy, đội nón mới, đi dép cỏ, bước ra cửa.

Hắn dừng lại ở ngưỡng cửa, quay lại.

— Cảm ơn — hắn nói. Bằng tiếng người. Rõ ràng, không vấp.

Ông lão ngồi trong lều, tay đã cầm tấm lưới lên vá tiếp. Ông không ngẩng đầu. Nhưng khóe miệng ông nhếch lên.

— Nói được rồi đấy — ông nói. — Thằng câm.


# Tái sinh Tề Thiên

## Chương 13 · Biển tây

Chủ thuyền nhìn hắn từ đầu đến chân, dừng lại lâu ở cái nón lá sụp tận mũi.

— Biết làm gì?

— Kéo dây. Vác hàng. Leo.

— Leo?

Hắn chỉ lên cột buồm. Chủ thuyền nhìn theo, rồi nhìn lại hắn, nhổ một bãi nước bọt xuống bến.

— Không lấy tiền công?

— Cơm. Chỗ ngồi. Tới bên kia biển.

Chủ thuyền là một người đàn ông trung niên, da sạm, mắt híp, bụng hơi phệ. Ông ta nhìn hắn thêm một lúc, như đang tính xem một kẻ lạ không lấy tiền công thì lợi hay hại. Rồi ông ta hất hàm về phía mấy kiện hàng chất trên bến.

— Vác hết lên thuyền trước khi trời tối. Vác không hết thì cút.

Hắn vác hết trước khi mặt trời chạm mặt nước.

---

Thuyền rời bến vào sáng hôm sau.

Trên thuyền có mười một người. Chủ thuyền, một lái thuyền già, và chín thủy thủ. Họ nói nhiều, chửi nhiều, cười nhiều. Hắn ít nói. Hắn làm việc. Kéo dây, vác hàng, cọ boong, tát nước ở đáy thuyền. Và leo.

Ngày thứ hai, dây buồm trên đỉnh cột bị rối. Mấy thủy thủ ngước lên, không ai muốn trèo. Hắn trèo. Không cần thang dây, không cần bám. Tay, chân, thân cột. Lên tới đỉnh, gỡ dây, tụt xuống. Chỉ trong mấy nhịp thở.

Đám thủy thủ đứng nhìn, há hốc mồm.

— Mẹ kiếp — một người nói. — Leo như khỉ.

Cả bọn cười rộ lên. Hắn cũng cười. Tiếng cười khan khan, không ai để ý.

Rạng sáng, khi cả thuyền còn ngủ, hắn ra ngồi ở mũi thuyền. Gió biển, nắng đầu ngày. Khí vẫn đến như hôm trên bè, vẫn đầy chừng ấy. Lái thuyền già thức sớm nhất, thấy hắn ngồi xếp bằng ở mũi thuyền, lẩm bẩm gì đó về bọn tu hành dở hơi, rồi mặc kệ.

Thủy thủ trẻ nhất thuyền thì không mặc kệ.

Cậu ta trạc mười sáu, mười bảy tuổi, gầy nhom, mặt đầy tàn nhang. Cậu ta tò mò về hắn từ ngày đầu. Bữa nào cũng ngồi cạnh hắn, chia cho hắn một nửa cái bánh ngô của mình, hỏi han đủ thứ. Hắn ở đâu tới. Hắn đi đâu. Sao hắn không bao giờ bỏ nón ra.

Hắn trả lời qua loa. Cậu thủy thủ trẻ không phiền. Cậu ta tự nói thay.

Cậu ta kể về quê mình, một làng chài nghèo ở cửa sông. Bố chết trên biển khi cậu lên năm. Mẹ bán cá. Cậu nợ chủ thuyền một khoản tiền, phải đi biển ba năm mới trả hết. Cậu mơ có một con thuyền nhỏ của riêng mình, không cần to, đủ cho cậu với mẹ.

Hắn nghe. Hắn nghĩ tới ông lão mù vá lưới, tới đứa con trai đi biển không về. Nợ, thuyền, mẹ già, biển. Người ở đây sống trong một vòng tròn như thế, đời này qua đời khác.

Trong sách, chẳng có dòng nào về những người này.

---

Đêm thứ bảy, giông tới.

Lần này hắn nghe thấy nó từ trước. Chiều hôm ấy, khi ngồi ở mũi thuyền, hắn nghe xa về phía tây nam có tiếng gầm trầm trầm, như tiếng thác. Hắn nói với lái thuyền già. Ông ta nhìn trời, nhìn hắn, rồi gọi mọi người hạ bớt buồm.

Nhưng hạ bớt buồm cũng không đủ.

Giữa đêm, gió rít như tiếng hét. Sóng tràn qua mạn, đổ ầm ầm lên boong. Thuyền lắc như một cái lá. Đèn bão treo ở cột buồm lắc lư, ánh sáng vàng nhảy múa trên những khuôn mặt tái mét. Buồm phụ rách toạc, bay phần phật. Mọi người bám vào bất cứ thứ gì có thể bám.

Một con sóng lớn đánh ngang mạn.

Hắn thấy cậu thủy thủ trẻ đang bám vào mạn thuyền phía bên kia. Rồi con sóng phủ lên cậu ta. Khi nó rút đi, chỗ ấy trống trơn.

— Rơi người! — ai đó hét.

Mọi người lao về phía mạn. Họ nhìn xuống làn nước đen ngòm, sủi bọt trắng. Thấp thoáng giữa sóng, có một cái đầu nhô lên, rồi chìm xuống, rồi nhô lên, mỗi lần một xa hơn.

Không ai nhảy. Nhảy xuống đó là chết.

Hắn không nghĩ. Hắn chạy tới cột buồm, leo lên. Ba nhịp thở, hắn đã ở trên xà buồm, cao hơn cả mạn thuyền. Từ đó hắn thấy rõ cái đầu nhỏ đang trôi ra xa.

Hắn để khí lan xuống chân. Như ở cây gãy. Như ở mỏm đá trong động. Rồi hắn bật.

Hắn bay qua mạn thuyền, qua một quãng sóng, rơi xuống nước gần chỗ cái đầu vừa chìm. Lạnh buốt. Hắn lặn xuống, mở mắt trong làn nước đen, quờ tay. Một mảnh vải. Một cánh tay. Hắn túm lấy, đạp nước, ngoi lên.

Trên thuyền, có người đã quăng xuống một sợi dây thừng. Hắn thấy nó trong ánh đèn bão, đầu dây quấn quanh một khúc gỗ, trôi dập dềnh cách đó không xa. Hắn kéo cậu thủy thủ trẻ bơi tới, túm lấy dây.

Người trên thuyền kéo. Hắn một tay ôm cậu thủy thủ, một tay quấn dây, chân đạp vào mạn thuyền, leo lên. Có những bàn tay thò xuống, túm lấy cậu thủy thủ, lôi lên trước. Rồi túm lấy hắn.

Hắn ngã sõng soài trên boong, nước chảy ròng ròng.

Cái nón không còn trên đầu hắn nữa. Không biết bay mất từ lúc nào.

Và cái đuôi đã tuột ra khỏi vạt áo, nằm duỗi dài trên boong, ướt sũng.

Ánh đèn bão chiếu thẳng vào mặt hắn.

---

Cả thuyền im lặng.

Giông vẫn gào, sóng vẫn đánh, nhưng trên boong không ai nói một lời. Mười khuôn mặt nhìn chằm chằm vào hắn. Vào cái mõm khỉ, đôi mắt hổ phách, lớp lông vàng nâu ướt bết, cái đuôi.

Rồi một người rút dao ra.

— Yêu quái!

Tiếng hét ấy như mở toang mọi thứ. Có người lùi lại. Có người vớ lấy một mái chèo. Có người hô: ném nó xuống biển.

Hắn ngồi dậy. Hắn không chạy. Không có chỗ nào để chạy. Xung quanh là biển, là giông.

Rồi cậu thủy thủ trẻ đứng dậy.

Cậu ta vẫn còn ho sặc sụa, nước chảy ra từ mũi, từ miệng. Cậu ta loạng choạng, suýt ngã. Nhưng cậu ta đứng chắn trước mặt hắn, giơ hai tay ra.

— Nó vừa kéo tôi lên — cậu ta nói, giọng khàn đặc. — Các người đứng nhìn. Nó nhảy xuống.

Người cầm dao khựng lại.

— Nó là yêu…

— Nó kéo tôi lên!

Chủ thuyền bước tới. Ông ta nhìn hắn rất lâu, mắt híp lại. Hắn không biết ông ta đang nghĩ gì. Có lẽ đang tính, như hôm ở bến. Một con yêu không lấy tiền công thì lợi hay hại.

— Ta thuê nó làm việc — cuối cùng chủ thuyền nói. — Nó làm. Nó leo cột, nó vác hàng, nó vừa báo giông trước cả lão Lái. — Ông ta quay sang người cầm dao. — Ngươi muốn ném nó xuống biển? Được. Ra mà kéo buồm thay nó. Leo cột thay nó.

Người cầm dao nhìn lên cột buồm, nơi cánh buồm rách đang bay phần phật trong gió. Hắn ta cất dao đi.

Không ai nói gì nữa. Mọi người quay lại với dây, với buồm, với nước tràn trên boong. Giông vẫn còn đó. Không ai có thời gian cho một con yêu.

---

Giông qua. Thuyền còn đi thêm năm ngày nữa mới tới bờ.

Năm ngày ấy, không ai lại gần hắn. Không ai chia bánh, không ai trêu. Họ làm việc của họ, tránh xa chỗ hắn ngồi. Khi hắn leo cột buồm, có người lầm rầm khấn vái. Lái thuyền già nhìn hắn bằng ánh mắt khó đoán.

Chỉ có cậu thủy thủ trẻ vẫn ngồi cạnh hắn mỗi bữa. Cậu ta không chia bánh nữa vì phải nằm mấy ngày, sốt. Nhưng khi đã ngồi dậy được, cậu ta lại ngồi cạnh hắn, im lặng, không hỏi gì.

Hôm thuyền cập cảng, chủ thuyền gọi hắn xuống khoang. Ông ta ném cho hắn một xâu tiền.

— Công của ngươi.

— Ta không lấy công.

— Ta trả. — Chủ thuyền nhìn hắn. — Đi đi. Đi ngay. Trước khi bọn nó lên bờ kể với người ở cảng.

Hắn cầm xâu tiền, cúi đầu, rồi đi lên boong.

Cậu thủy thủ trẻ đứng chờ ở cầu tàu. Cậu ta cầm trong tay một cái nón lá. Không phải nón của hắn, cái ấy đã mất ngoài biển. Nón của cậu ta, cũ và thủng một lỗ ở chóp.

— Đội vào — cậu ta nói. — Mặt ông dễ thấy lắm.

Hắn nhận cái nón. Hắn muốn nói gì đó, nhưng không biết nói gì.

— Ông nhảy xuống — cậu thủy thủ trẻ nói. — Không ai nhảy. Ông nhảy.

Cậu ta quay đi, chạy về phía thuyền.

Hắn đội nón, kéo vành sụp xuống, bước lên bến đá. Tây Ngưu Hạ Châu.

---

Người ở đây có vẻ hiền hơn.

Hắn hỏi đường ở cảng, ở chợ, ở những làng ven đường. Hỏi về tiên, về người tu hành, về núi có người không chết. Không ai ngạc nhiên khi nghe câu hỏi ấy. Ai cũng có một câu chuyện. Núi này có ông tiên cưỡi hạc. Núi kia có bà tiên hái thuốc. Khe nọ có một ông đạo sĩ sống hai trăm năm. Người ta chỉ cho hắn hướng này hướng kia, mỗi người một kiểu.

Hắn không đi theo ai cả.

Trong sách, khỉ đá không tìm được tiên bằng cách hỏi đường. Khỉ đá vào rừng, nghe thấy tiếng hát. Một người đốn củi.

Hắn đi về phía những dãy núi cao nhất, rừng rậm nhất. Đi nhiều ngày. Ngủ trên cây. Sáng nào cũng ngồi trên một mỏm đá cao, nhắm mắt, thở, nghe. Nghe tiếng suối, tiếng chim, tiếng gió trong rừng. Nghe xem có tiếng người hát không.

Đến ngày thứ tám trong núi, hắn nghe thấy.

---

Tiếng hát vang lên từ một sườn núi rậm rạp, lẫn trong tiếng rìu chặt củi. Giọng đàn ông, trầm, không hay lắm, nhưng vui. Hắn không nghe rõ hết lời. Hắn chỉ nghe được ý: hát về chuyện lên núi đốn củi, xuống chợ đổi gạo, về nhà nấu cơm, không lo nghĩ chuyện được mất, không tranh giành với ai, sống ngày nào biết ngày ấy.

Hắn đứng chết lặng dưới một gốc cây.

Rồi hắn chạy.

Hắn lao qua bụi rậm, nhảy qua những thân cây đổ, chạy theo tiếng hát. Tới một khoảng trống, hắn thấy một người đàn ông đang đứng chặt một thân cây khô. Áo vải thô, quần xắn tới gối, đầu quấn khăn. Một bó củi to buộc sẵn bên cạnh.

Hắn lao tới, quỳ sụp xuống trước mặt người đàn ông.

— Lão thần tiên! Lão thần tiên!

Người đàn ông giật mình, suýt buông rìu. Ông ta nhìn xuống. Cái nón lá đã lệch đi khi hắn quỳ, lộ ra cái mõm khỉ, đôi mắt hổ phách.

Ông ta lùi lại một bước. Rồi, không hiểu sao, ông ta bật cười.

— Thần tiên gì! — ông ta nói. — Ta đốn củi. Tiều phu.

Hắn ngẩng lên.

— Nhưng bài hát…

— Bài hát? — Người tiều phu lại cười, lần này to hơn. — Một ông tiên ở gần đây dạy ta đấy. Ông ấy thấy ta hay lo nghĩ, dạy cho ta mấy câu, bảo khi nào mệt thì hát, cho nhẹ người. Ta hát mãi thành quen.

Hắn nhìn người tiều phu. Một người đàn ông bình thường, tay chai, mặt sạm nắng. Đúng như trong sách.

— Ông ở gần tiên — hắn nói. — Sao không đi tu?

Người tiều phu không cười nữa. Ông ta cúi xuống, buộc lại bó củi.

— Bố ta mất sớm. — Ông ta nói, giọng bình thản. — Còn mẹ ta. Già rồi. Anh em không có. Ta đi tu thì ai đốn củi, ai đổi gạo, ai nấu cơm cho bà ăn.

Hắn không nói gì.

Hắn nghĩ tới khỉ già. Tới những sáng bà ngồi trên gờ cạnh hắn. Tới cái đêm hắn ngồi một mình nghĩ rằng một phần trong mình đã chờ cái sáng bà không ho nữa.

Người tiều phu này không chờ. Ông ta ở lại.

— Còn ngươi — người tiều phu nhìn hắn, tò mò. — Ngươi là… cái gì?

— Ta là khỉ — hắn nói. — Đi tìm người dạy cách không chết.

Người tiều phu nhìn hắn một lúc lâu. Rồi ông ta gật đầu, như thể chuyện một con khỉ biết nói đi tìm tiên là chuyện bình thường.

— Thế thì đi về phía nam. — Ông ta chỉ tay. — Bảy tám dặm. Có một ngọn núi gọi là Linh Đài Phương Thốn. Trong núi có cái động gọi là Tà Nguyệt Tam Tinh. Có một vị tổ sư ở đó. Học trò nhiều lắm. Ông tiên dạy ta bài hát cũng là người ở đó.

Hắn đứng dậy. Chân run run.

— Cảm ơn ông.

Người tiều phu vác bó củi lên vai, phẩy tay.

— Đi đi. Ta còn phải về nấu cơm.

---

Bảy tám dặm về phía nam, rừng đổi khác.

Không còn rậm rạp, um tùm. Cây tùng, cây trúc mọc thưa, xanh mướt. Đường mòn sạch sẽ, như có người quét. Một con suối nhỏ chảy róc rách bên đường, nước trong vắt tới đáy. Trên một cành tùng cao, có một con hạc trắng đứng một chân, cổ cong, nhìn hắn đi qua mà không bay.

Hắn đi chậm lại. Không phải vì mệt.

Rồi con đường mòn dẫn hắn tới một vách núi. Trên vách có một cánh cổng đá. Đóng kín.

Bên cạnh cổng có một tấm bia đá.

Hắn bước tới, nhìn. Lại là chữ Hán. Hắn vẫn không đọc được. Hơn một năm học tiếng người, hắn chỉ học nói, không học viết. Ông lão mù không biết chữ, mà có biết cũng không thấy để dạy.

Nhưng có vài chữ hắn nhận ra.

Một chữ có ba nét dọc, giống hệt chữ trên tấm bia ở Thủy Liêm Động. Sơn. Núi.

Một chữ hình như vầng trăng khuyết, hai nét ngang ở giữa. Nguyệt. Trăng.

Một chữ chỉ có ba nét ngang. Tam. Ba.

Núi. Trăng. Ba.

Linh Đài Phương Thốn Sơn. Tà Nguyệt Tam Tinh Động.

Hắn đứng trước tấm bia, và cảm thấy giống hệt cái ngày đứng trước tấm bia trong Thủy Liêm Động. Chỉ khác là lần này không có cái lạnh chạy dọc sống lưng. Lần này chỉ có tim đập thình thịch, như sắp nổ tung.

Hắn giơ tay định gõ cổng. Rồi dừng lại.

Trong sách, khỉ đá không dám gõ cửa. Khỉ đá ngồi chờ, trèo lên cây tùng hái quả ăn. Rồi cửa tự mở. Một tiên đồng bước ra, nói thầy biết có người tới cầu đạo, sai ra đón.

Hắn biết điều đó. Nếu hắn ngồi chờ, cửa sẽ mở.

Hắn hạ tay xuống. Hắn đứng trước cánh cổng đá, nghĩ.

Hắn biết trước. Đó là thứ duy nhất hắn có mà con khỉ đá trong sách không có. Hắn đã dùng nó để vượt biển, để tìm tiều phu, để tới đây nhanh hơn mấy trăm năm. Nhưng người ở sau cánh cổng này không phải người đánh cá, không phải thủy thủ. Người ở sau cánh cổng này biết có người tới trước khi người ấy gõ cửa.

Một người như thế, liệu có nhìn ra một con khỉ đã biết trước cả những điều mình sắp nói?

Hắn không biết.

Hắn tháo nón ra, đặt xuống bên cạnh. Không giấu mặt nữa. Ở đây, giấu cũng chẳng để làm gì. Rồi hắn ngồi xuống trước cổng, xếp bằng, hai tay đặt lên gối.

Không gõ. Không trèo cây. Chỉ ngồi.

Ngồi chờ cũng là một cách lịch sự, hắn tự nhủ. Không phải vì hắn biết cửa sẽ mở. Mà vì hắn là kẻ tới xin học. Kẻ tới xin học thì phải chờ.

Hắn không chắc mình tin điều đó được bao nhiêu phần.

Lần này hắn biết cánh cửa sẽ mở. Hắn không biết người sau cánh cửa có muốn nhận một kẻ đã biết trước điều đó hay không.


# Tái sinh Tề Thiên

## Chương 14 · Tà Nguyệt Tam Tinh

Hắn ngồi trước cổng đá rất lâu.

Nắng dịch chuyển từ vai trái sang vai phải. Bóng cây tùng bên đường ngắn dần, rồi dài ra. Con hạc trắng trên cành cao xòe cánh bay đi, một lúc sau lại bay về, đứng đúng chỗ cũ, một chân, cổ cong. Con suối bên đường vẫn róc rách.

Cánh cổng vẫn đóng.

Hắn bắt đầu nghi.

Trong sách, khỉ đá đợi chẳng bao lâu thì tiên đồng ra. Nhưng khỉ đá trong sách tới đây sau hơn mười năm lang thang. Hắn tới sau hơn một năm. Có khi nào vị tổ sư sau cánh cổng này chưa biết có người tới? Có khi nào ông ta chưa tới đây? Có khi nào hắn đã tới sớm quá, sớm tới mức câu chuyện còn chưa kịp bắt đầu?

Hắn nhìn cánh cổng đá. Nó im lìm, lạnh lẽo, không một khe hở.

Hắn tự nhủ ngồi thêm. Chờ đến tối. Đến tối mà cửa vẫn không mở thì hắn sẽ gõ.

Mặt trời ngả về tây.

Rồi có tiếng then cửa kéo ra.

---

Cánh cổng đá mở hé, rồi mở rộng.

Một đứa trẻ bước ra. Trạc mười hai, mười ba tuổi, mặt mũi thanh tú, tóc búi hai bên, mặc áo trắng thắt dây xanh. Nó đứng ở ngưỡng cửa, nhìn quanh.

— Ai ở ngoài này?

Hắn đứng dậy, chắp tay, cúi đầu. Như hắn đã thấy người ở chợ làm khi gặp người có vai vế.

— Ta là kẻ tới cầu đạo.

Đứa trẻ nhìn hắn. Cái mõm khỉ, đôi mắt hổ phách, lớp lông vàng nâu, bộ áo vải thô bạc màu. Hắn chờ nó lùi lại, chờ nó hét lên, như đứa trẻ ở xóm chài ngày nào.

Nó không lùi. Không hét. Mặt nó không thay đổi chút nào.

— Thầy đang giảng — nó nói. — Thầy bảo có người tu hành tới ngoài cửa, sai ta ra đón. Là ngươi phải không?

Hắn mở miệng, rồi ngậm lại. Rồi gật đầu.

— Theo ta.

Đứa trẻ quay vào. Hắn nhặt cái nón lá dưới đất, cầm trong tay, bước theo.

---

Bên trong cổng đá không phải một cái hang tối tăm.

Là một con đường lát đá trắng, hai bên trồng tùng trúc, chạy sâu vào lòng núi. Ánh sáng không biết từ đâu tới, dịu dàng, như ánh nắng chiều lọc qua lá. Đi một đoạn, con đường mở ra thành những sân rộng, những lầu gác mái cong, những hành lang có cột đá chạm hoa. Có tiếng chuông ở đâu đó, ngân dài. Có mùi hương trầm, mùi hoa, mùi đất ẩm.

Hắn đi theo tiên đồng, mắt nhìn khắp nơi, chân bước chậm dần.

Thủy Liêm Động là một cái động khô, rộng, có đồ đá như mọc lên từ nền. Nơi này không giống. Nơi này có người ở, có người chăm sóc, có người quét lá trên đường mỗi sáng.

Họ đi qua một sân có mấy người đang quét. Rồi một hành lang có mấy người đang ngồi đọc sách. Người nào cũng mặc áo đạo, búi tóc, trẻ có già có. Họ ngẩng lên nhìn hắn đi qua. Có người tròn mắt. Có người nhíu mày. Có người khẽ huých vai người bên cạnh, nói thầm. Nhưng không ai hét. Không ai bỏ chạy.

Tiên đồng dẫn hắn tới trước một tòa nhà lớn, cửa mở rộng.

Bên trong là một gian giảng đường. Hai bên có hơn ba chục người ngồi xếp hàng, quay mặt vào giữa. Ở cuối gian, trên một cái đài cao, có một người ngồi.

Hắn dừng lại ở ngưỡng cửa.

---

Hắn không biết người trên đài bao nhiêu tuổi.

Nhìn tóc thì già. Tóc bạc trắng, búi gọn trên đỉnh đầu. Nhìn da mặt thì không già. Không một nếp nhăn sâu, không một vết đồi mồi. Nhìn đôi mắt thì không biết. Đôi mắt ấy bình thản như mặt nước giếng sâu, không nhìn ai đặc biệt, mà như nhìn tất cả cùng một lúc.

Ông mặc một bộ áo đạo màu nhạt, giản dị, không thêu thùa gì. Không có hào quang, không có mây lành. Chỉ là một người ngồi trên đài.

Nhưng hắn biết ngay. Không cần ai nói.

Hắn bước vào, đi giữa hai hàng đệ tử, tới trước đài, quỳ xuống. Hắn dập đầu xuống nền đá. Một lần. Hai lần. Ba lần. Ở châu phía nam, hắn đã thấy người ta lạy ở đền như thế. Hắn không chắc mình làm đúng. Hắn chỉ biết mình phải làm.

— Đệ tử xin bái kiến sư phụ.

Im lặng một lúc. Rồi giọng người trên đài vang lên, không to, nhưng rõ đến từng chữ.

— Ngươi từ đâu tới?

Hắn ngẩng lên.

— Đệ tử từ Thủy Liêm Động, Hoa Quả Sơn, Đông Thắng Thần Châu.

Đôi mắt bình thản trên đài khẽ động. Lần đầu tiên, nó dừng lại trên mặt hắn.

— Đuổi ra.

Hắn sững người.

— Kẻ này nói dối — người trên đài nói, giọng vẫn bình thản như cũ. — Đông Thắng Thần Châu cách đây hai lớp biển lớn, ở giữa còn cả một Nam Thiệm Bộ Châu. Nó tới đây bằng cách nào?

Hai đệ tử ở hàng đầu đã đứng dậy.

— Đệ tử không nói dối! — hắn nói, nhanh hơn ý định. — Đệ tử làm bè, vượt biển đông, trôi chín ngày tới bờ châu phía nam. Ở đó hơn một năm, học tiếng người. Rồi làm thuê trên thuyền buôn, vượt biển tây sang đây. Gặp một người tiều phu trong núi, người ấy chỉ đường.

Hai đệ tử dừng lại, nhìn lên đài.

Người trên đài nhìn hắn. Lâu.

— Hơn một năm — ông nói.

— Vâng.

— Từ Đông Thắng tới đây. Hơn một năm.

— Vâng.

— Nhanh. — Người trên đài ra hiệu, hai đệ tử ngồi xuống. — Có kẻ đi mười năm chưa tới. Có kẻ đi cả đời, chết trên đường. Ngươi đi hơn một năm. Ngươi biết đường?

Hắn im lặng một nhịp.

— Đệ tử hỏi người. Nghe thủy thủ kể. Gặp tiều phu.

— Và ngồi chờ ngoài cổng — người trên đài nói. — Từ trưa tới chiều. Không gõ.

Tim hắn thắt lại.

— Kẻ tới xin học thì phải chờ.

— Hay vì ngươi biết cửa sẽ mở?

Cả gian giảng đường im phăng phắc. Hắn cảm thấy hơn ba chục đôi mắt đổ dồn vào lưng mình.

Hắn có thể nói không. Hắn có thể nói đó chỉ là phép lịch sự, là may mắn, là trùng hợp. Người trên đài sẽ không có cách nào chứng minh hắn nói dối.

Nhưng hắn nhìn đôi mắt ấy, và biết là có.

— Đệ tử biết — hắn nói.

---

Im lặng kéo dài. Hắn quỳ trên nền đá, không dám cựa.

Người trên đài nhìn hắn rất lâu. Không phải cái nhìn của con gấu, dừng lại để ghi nhớ một khuôn mặt. Không phải cái nhìn của khỉ già, dò xét xem kẻ lạ có đáng tin không. Cái nhìn này như nhìn vào một cái chum nước trong, nhìn tận xuống đáy.

— Trong ngươi có một thứ không thuộc về đá — cuối cùng ông nói.

Hắn không thở.

— Như nước biển đổ vào một cái chum nước suối. — Người trên đài nói chậm rãi. — Cùng là nước. Nhưng không cùng một vị.

Ông không hỏi đó là gì. Hắn chờ câu hỏi ấy, chờ rất lâu. Nó không tới.

— Mỗi kẻ tới đây đều mang theo một thứ — người trên đài nói. — Có kẻ mang danh. Có kẻ mang tiền. Có kẻ mang tuổi già, mang nỗi sợ chết. Ngươi mang theo cái biết trước.

Ông dừng lại một chút.

— Ở đây, điều ngươi biết không thay được điều ngươi phải làm. Có những thứ ngươi biết. Đừng dùng chúng ở đây trước khi ngươi hiểu chúng.

Hắn cúi đầu, trán chạm nền đá.

— Đệ tử xin ghi nhớ.

— Đứng dậy.

Hắn đứng dậy.

— Đi mấy bước ta xem.

Hắn không hiểu, nhưng làm theo. Hắn đi mấy bước dọc giảng đường, rồi quay lại. Đi đứng như người, lưng thẳng, đuôi giấu trong vạt áo. Nhưng hắn biết, nhìn kỹ, dáng đi vẫn còn lom khom, vẫn còn nhún nhảy, vẫn là dáng một con khỉ.

Người trên đài nhìn, khẽ gật đầu.

— Ngươi họ gì?

— Đệ tử không có họ — hắn nói. — Không cha, không mẹ. Đệ tử từ đá ra. Trên đỉnh núi có một khối đá, đá nứt, đệ tử ra.

— Từ đá ra. — Người trên đài lặp lại, không có vẻ ngạc nhiên. — Thế thì cha mẹ ngươi là trời đất.

Ông nhìn hắn thêm một lúc, rồi nói:

— Ngươi đi đứng giống loài hồ tôn. Chữ hồ, bỏ bộ khuyển đi, còn lại chữ cổ và chữ nguyệt. Cổ là già. Nguyệt là âm. Già mà âm, không sinh hóa được. Không lấy chữ ấy.

Ông giơ tay, ngón tay vẽ một nét trong không khí.

— Chữ tôn, bỏ bộ khuyển đi, còn lại chữ tử và chữ hệ. Tử là con trai. Hệ là non nhỏ, mới sinh. Hợp với cái gốc của trẻ thơ. Cho ngươi họ Tôn.

Hắn đứng im. Hắn biết điều này. Hắn đã đọc nó, xem nó, nghe nó kể không biết bao nhiêu lần. Nhưng chưa bao giờ hắn nghĩ sẽ có ngày đứng ở đây, nghe chính người ấy nói ra.

— Môn ta đặt pháp danh theo mười hai chữ — người trên đài nói tiếp. — Quảng, đại, trí, tuệ, chân, như, tính, hải, dĩnh, ngộ, viên, giác. Đời của ngươi tới chữ ngộ.

Ông nhìn hắn.

— Đặt cho ngươi pháp danh là Ngộ Không. Tôn Ngộ Không.

---

Cái tên rơi xuống như một tảng đá.

Hắn không biết mình đã quỳ xuống từ lúc nào. Hắn chỉ biết đầu gối mình chạm nền đá lạnh, hai tay chống xuống, đầu cúi gằm.

Tôn Ngộ Không.

Hơn một năm qua, hắn đã nghĩ tới cái tên này không biết bao nhiêu lần. Ngày đầu tiên ngồi trên bãi tiên thạch, nhìn bàn tay đầy lông, hắn đã nghĩ tới nó. Đêm nằm trên chạc cây, sợ hãi nghĩ tới năm trăm năm dưới núi, hắn đã nghĩ tới nó. Đứng trước tấm bia ở Thủy Liêm Động, hắn đã nghĩ tới nó.

Nhưng hắn chưa bao giờ nói nó ra thành tiếng. Chưa bao giờ ai gọi hắn bằng cái tên ấy.

Giờ có người gọi rồi.

Và cùng với cái tên, tất cả những gì sách viết gắn với nó cũng rơi xuống theo. Cây gậy dưới đáy biển. Mười vạn thiên binh. Đào tiên, rượu ngự, kim đan. Lò bát quái. Một bàn tay khổng lồ úp xuống. Năm trăm năm.

— Ngươi có thích cái tên ấy không? — giọng người trên đài vang lên.

Hắn không trả lời ngay.

Hắn nghĩ tới khỉ già. Bà chưa từng gọi tên hắn. Trong tiếng khỉ không có tên. Bà chỉ gọi hắn là “ngươi”. Ngươi đi trước. Ngươi hứa nhiều quá. Ngươi đi được rồi.

Con tai sứt cũng thế. Ông lão mù gọi hắn là “thằng câm”. Cậu thủy thủ trẻ gọi hắn là “ông”.

Cái tên này là của con khỉ trong sách. Con khỉ đại náo Thiên Cung, con khỉ bị đè dưới núi.

Nhưng con khỉ trong sách chưa từng xếp đá lên mộ một bà khỉ già. Chưa từng để lại một con cá cho người đánh cá. Chưa từng kéo nước cho một ông lão mù. Con khỉ trong sách chưa từng làm những việc hắn đã làm.

Tên giống nhau. Người không nhất thiết phải giống.

Hắn ngẩng đầu lên.

— Đệ tử thích — hắn nói.

Người trên đài gật đầu.

— Ngộ là tỉnh ra. Không là cái không. — Ông nói ngắn, như không muốn giảng thêm. — Tỉnh ra thì mới thấy cái không. Ngươi còn xa lắm.

Ông quay sang một đệ tử ngồi ở hàng đầu bên trái, một người đàn ông trung niên, mặt vuông, râu ngắn.

— Dẫn nó đi. Chỉ chỗ ngủ, chỉ việc.

Rồi ông nhắm mắt lại, như thể chuyện vừa rồi chưa từng xảy ra. Buổi giảng tiếp tục.

---

Người đệ tử mặt vuông dẫn hắn ra khỏi giảng đường, đi qua mấy hành lang, tới một dãy nhà thấp phía sau.

— Ta là sư huynh của ngươi — người ấy nói, giọng không lạnh không nóng. — Từ mai, sáng sớm dậy quét sân. Quét xong thì gánh nước. Gánh xong thì nhổ cỏ vườn sau. Chiều có giảng thì nghe. Tối thì ngủ.

— Bao giờ thì học phép?

Người sư huynh dừng lại, nhìn hắn. Lần đầu tiên, có một tia gì đó như buồn cười trong mắt ông ta.

— Ta ở đây mười hai năm rồi — ông ta nói. — Vẫn quét sân.

Ông ta mở cửa một gian phòng dài, kê hai dãy chiếu, mỗi chiếu một cái gối gỗ và một tấm chăn mỏng. Mấy đệ tử khác đang nằm sẵn, ngẩng đầu lên nhìn.

— Chỗ của ngươi. — Người sư huynh chỉ vào cái chiếu cuối cùng, sát tường. — Ngủ đi. Mai dậy sớm.

---

Đêm ấy, hắn nằm trên chiếu, nhìn lên trần nhà tối om.

Xung quanh, các đệ tử đã ngủ. Có tiếng ngáy, tiếng trở mình, tiếng ai đó nói mơ. Ngoài cửa sổ, trăng lưỡi liềm treo trên ngọn tùng.

Tà nguyệt. Trăng nghiêng.

Hắn thì thầm cái tên của mình. Rất khẽ, như sợ ai nghe thấy.

— Tôn Ngộ Không.

Nghe lạ. Như tên một người khác.

Hắn nghĩ tới Hoa Quả Sơn. Giờ này con tai sứt đang ngủ trong động, mảnh đá trắng chắc vẫn kẹp trong tay. Trên vách động đã có hơn năm trăm vạch. Khỉ đực to con nằm ở cửa động, chặn giữa đàn và gờ đá. Khỉ con lông nâu nhạt đã lớn, có lẽ đã dẫn lũ nhỏ hơn nó ra thung lũng.

Không ai ở đó biết cái tên này.

Khi hắn về, con tai sứt sẽ gọi hắn là gì? Có lẽ vẫn là “ngươi”. Ngươi về rồi đấy à. Ngươi đi lâu thế.

Hắn nằm trong bóng tối, và thấy mình mong như thế.


# Tái sinh Tề Thiên

## Chương 15 · Bảy lần đào chín

Sáng đầu tiên, hắn quét sân sai.

Hắn quét như người ta quét nhà ở đời trước: gom rác vào một chỗ, hốt đi, xong. Sư huynh mặt vuông đi qua, dừng lại, nhìn cái sân, nhìn hắn.

— Quét lại.

— Sạch rồi mà.

Sư huynh mặt vuông cầm lấy cái chổi tre trên tay hắn, quét lại từ đầu. Chậm. Từng đường chổi đều nhau, song song, từ góc này sang góc kia, không bỏ sót một viên sỏi nào. Lá rụng không gom thành đống mà được đẩy dần về phía gốc tùng, nằm gọn ở đó, như vốn dĩ thuộc về chỗ ấy.

Khi ông ta quét xong, mặt trời vừa lên. Cái sân đá trắng sáng lên như mặt gương.

Ông ta đưa chổi lại cho hắn.

— Mai quét thế này.

Sáng hôm sau, hắn dậy sớm hơn, quét như thế. Mất gấp đôi thời gian. Sư huynh mặt vuông đi qua, nhìn, không nói gì. Hắn coi như đã đạt.

---

Rồi gánh nước.

Suối cách động một quãng xa, phải đi xuống một con dốc đá, rồi đi ngược lên. Hai thùng gỗ, một đòn gánh tre. Người ta gánh bằng vai. Hắn thử gánh bằng vai. Đòn gánh đè lên vai trái, chỗ có ba vết sẹo, nhói lên một chút. Hắn đổi sang vai phải.

Ngày đầu, nước sóng sánh đổ ra gần nửa thùng. Ngày thứ mười, đổ ra một phần ba. Đến tháng thứ hai, không đổ giọt nào.

Rồi nhổ cỏ. Vườn sau động rộng mênh mông, trồng rau, trồng thuốc, trồng hoa. Cỏ dại mọc chen vào giữa. Phải nhổ tận gốc, không được làm đứt rễ cây thuốc bên cạnh. Tay khỉ khéo hơn tay người ở chỗ này. Hắn nhổ nhanh hơn mọi người.

Mỗi rạng đông, trước khi quét sân, hắn vẫn ngồi luyện. Trên một tảng đá sau dãy nhà ngủ, chỗ nhìn được về phía đông. Không có biển, không có thác. Chỉ có rừng tùng và sương. Khí đến chậm hơn, nhẹ hơn. Nhưng vẫn đến.

Cuối vườn có mấy cây đào già.

Cuối mùa hè năm đầu tiên, đào chín. Các đệ tử được phép hái mỗi người một quả. Hắn hái một quả, ăn, ngọt lịm. Hắn giữ lại cái hạt, rửa sạch, mang về phòng, đặt lên bậu cửa sổ cạnh chỗ nằm.

Một hạt.

Ở Hoa Quả Sơn, con tai sứt vạch lên vách mỗi ngày một đường. Ở đây, hắn sẽ đếm bằng đào.

---

Có một đồng môn trẻ ngủ cách hắn ba chiếu.

Cậu ta gầy, trắng, mặt lúc nào cũng cúi xuống, ít nói tới mức hắn mất một tháng mới nghe thấy giọng cậu ta. Cậu ta có một thói quen: tối nào cũng ngồi bên ngọn đèn dầu nhỏ, đọc sách. Những cuốn sách bằng giấy vàng, chữ đen chi chít.

Một tối, hắn ngồi xuống cạnh cậu ta, nhìn vào trang sách.

— Đọc được không? — cậu ta hỏi, không ngẩng lên.

— Không.

Cậu ta im lặng một lúc. Rồi cậu ta lấy ngón tay chấm vào một chữ.

— Nhân. Người.

Hắn nhìn chữ ấy. Hai nét, như hai chân người đang bước.

— Nhân — hắn lặp lại.

Từ đó, tối nào cậu thư sinh gầy cũng dạy hắn mấy chữ. Không phải dạy không. Hắn gánh hộ cậu ta một chuyến nước mỗi sáng, vì cậu ta gầy, gánh nước là khổ nhất. Cậu ta dạy hắn đọc. Đọc trước, rồi viết. Viết bằng que trên đất, rồi bằng bút lông chấm nước lên phiến đá, viết xong nước khô thì viết lại.

Năm thứ hai, hắn đi qua cổng động, dừng lại trước tấm bia.

Linh. Đài. Phương. Thốn. Sơn. Tà. Nguyệt. Tam. Tinh. Động.

Hắn đọc được từng chữ. Không phải đoán. Không phải ghép theo trí nhớ. Đọc.

Tối hôm ấy, hắn ngồi trước phiến đá, chấm bút vào nước, viết một chữ. Rồi viết lại. Rồi viết lại. Bộ tử bên trái, bộ hệ bên phải.

Tôn.

Cậu thư sinh gầy nhìn qua vai hắn.

— Viết tên mình à?

— Ừ.

— Xấu quá.

Hắn cười, viết lại.

---

Chiều nào có giảng, các đệ tử ngồi kín giảng đường.

Tổ sư giảng đều đều, giọng không to không nhỏ, không nhanh không chậm. Giảng về đạo, về trời đất, về âm dương. Những chữ hắn mới học đọc trên giấy, giờ được nói ra thành tiếng, xâu thành những câu dài, nặng, rối như sợi lưới. Năm đầu, hắn hiểu được một phần mười. Năm thứ hai, hiểu được một phần năm.

Nhưng có những câu hắn nhớ mãi.

Một chiều, Tổ sư giảng về nước. Đại ý rằng nước không bị ai đẩy mà tự chảy. Nhưng nước chảy tràn lan thì thành đầm lầy. Có bờ thì nước mới thành sông, mới chảy được xa.

Hắn ngồi im, không nghe tiếp những câu sau.

Không đẩy, chỉ nhìn. Không đưa khí lên tay chân. Luật hắn tự đặt sau lần ép khí. Những luật ấy đã giữ hắn an toàn suốt mấy năm. Nhưng hắn đã nghĩ rằng không đưa khí lên tay là cấm hẳn, là cứ để nó nằm im ở bụng.

Không phải cấm. Mà phải có bờ.

Hắn đã ép nước lũ qua một cái rãnh hẹp, rãnh vỡ. Rồi hắn sợ, không dám cho nước đi đâu cả, để nó nằm trong bát. Bát đầy. Không có bờ, nước không đi được. Không có thầy, không ai chỉ cho hắn bờ ở đâu.

Từ hôm ấy, hắn ngồi luyện khác đi một chút. Không đẩy. Nhưng không giữ khư khư nữa. Hắn để khí lan ra, và chú ý xem nó tự muốn chảy về đâu, theo đường nào. Như ngày đầu tiên nhìn chim én bay vào thác.

Nhiều tháng sau, một sáng, hắn nhận ra đốm ấm dưới rốn đã lớn hơn. Không nhiều. Như cái bát được nong rộng ra một chút. Nhưng lớn hơn.

Không có tiếng sấm, không có hào quang. Chỉ là một buổi sáng hắn ngồi trên tảng đá, thấy cái bát hơi rộng ra, rồi đứng dậy đi quét sân.

---

Năm thứ ba. Năm thứ tư.

Bốn hạt đào trên bậu cửa sổ.

Có những đêm hắn nằm nhìn mấy hạt đào, nghĩ tới Hoa Quả Sơn. Mỗi hạt đào ở đây là ba trăm sáu mươi vạch trên vách động. Đã gần hai nghìn vạch rồi. Đã bao nhiêu mùa khô đi qua. Nước ở vũng cũ có cạn không. Con gấu có đắp chắn lại không. Nó có tôn trọng ba vết cào trên thân cây không. Khỉ con lông nâu nhạt chắc đã lớn, đã có con. Con tai sứt… con tai sứt có còn vạch không, hay đã chán, đã quên.

Hắn không có cách nào biết.

Có những đêm hắn muốn bỏ đi. Đứng dậy, ra cổng, xuống núi, về. Hắn đã có thứ không ai ở Hoa Quả Sơn có: tiếng người, chữ, một chút khí lớn hơn. Đủ để giữ đàn qua mấy mùa khô.

Nhưng không đủ để giữ đàn qua những thứ sách đã viết sẽ tới.

Có những đêm khác, hắn nghĩ tới chuyện dùng cái biết. Hắn biết rồi sẽ có một buổi giảng, Tổ sư sẽ hỏi hắn muốn học gì. Hắn biết những câu Tổ sư sẽ hỏi, những câu hắn phải đáp. Hắn có thể làm cho buổi ấy tới sớm hơn. Nhảy lên giữa buổi giảng, giả vờ vui mừng, để Tổ sư chú ý.

Ở đây, điều ngươi biết không thay được điều ngươi phải làm.

Hắn nằm im, nhìn hạt đào trên bậu cửa sổ, và không làm gì cả.

Năm thứ năm. Năm thứ sáu.

Đồng môn có người tới, có người đi. Có người ở được vài tháng, chán, bỏ về. Có người ở mấy năm, được Tổ sư dạy một môn gì đó, xuống núi. Cậu thư sinh gầy được dạy môn kinh sách, đọc ngày đọc đêm. Sư huynh mặt vuông vẫn quét sân. Mười tám năm, mười chín năm. Vẫn quét.

Có một lần hắn hỏi ông ta:

— Sư huynh không muốn học phép à?

Sư huynh mặt vuông dừng chổi, nhìn cái sân.

— Muốn chứ — ông ta nói. — Nhưng chưa tới lúc.

— Bao giờ thì tới lúc?

— Bao giờ quét sân mà không nghĩ tới chuyện học phép. — Ông ta lại cúi xuống, quét tiếp. — Ta chưa được.

---

Cuối mùa hè năm thứ bảy, hắn đặt hạt đào thứ bảy lên bậu cửa sổ.

Chiều hôm ấy có giảng.

Tổ sư giảng về đạo. Giảng về cái lý của trời đất, về cái gốc của vạn vật, về chỗ mà sinh và tử gặp nhau. Hắn ngồi ở hàng cuối, nghe.

Và lần này, hắn hiểu.

Không phải hiểu hết. Nhưng có một đoạn, chỉ một đoạn, khi Tổ sư nói tới chỗ khí đi vào thân thể như nước đi vào đất, hắn hiểu đến tận cùng. Không phải vì hắn đã đọc. Vì hắn đã ngồi trên bãi tiên thạch, trên gờ sau thác, trên bè giữa biển, trên ghềnh đá ven biển châu phía nam, trên tảng đá sau dãy nhà ngủ. Bảy năm, gần chín năm, mỗi sáng. Những lời ấy nói đúng thứ hắn đã cảm thấy, mà chưa bao giờ biết gọi tên.

Hắn thấy trong người như có ai mở toang một cánh cửa sổ.

Hắn không ngồi yên được. Hắn đứng bật dậy. Hai tay vò vào nhau, chân nhún nhún, đuôi tuột ra khỏi vạt áo ngoe nguẩy. Hắn nhảy. Không phải nhảy múa cho đẹp, không phải diễn. Một con khỉ vui quá thì nhảy, thế thôi.

Cả giảng đường quay lại nhìn.

Tổ sư ngừng giảng.

— Ngươi ở hàng sau — giọng ông vang lên. — Sao không ngồi nghe, lại nhảy nhót?

Hắn khựng lại giữa chừng. Mặt nóng bừng dưới lớp lông. Hắn quỳ xuống.

— Đệ tử nghe tới chỗ hay — hắn nói. — Vui quá, không kìm được. Xin sư phụ thứ tội.

Tổ sư nhìn hắn. Hắn không biết ông nhìn thấy gì. Có thể ông nhìn thấy một con khỉ vụng về. Có thể ông nhìn thấy một kẻ đang diễn đúng như một câu chuyện đã viết.

Hắn không diễn. Hắn chỉ mong ông thấy được điều ấy.

— Ngươi đã ở đây bao lâu? — Tổ sư hỏi.

— Đệ tử không nhớ năm — hắn nói. — Chỉ nhớ đào ở vườn sau chín bảy lần. Đệ tử ăn bảy quả.

— Bảy lần đào chín. — Tổ sư gật đầu. — Vậy là bảy năm.

Ông im lặng một lúc.

— Ngươi muốn học gì ở ta?

---

Hắn biết câu hỏi này sẽ tới. Đã biết từ bảy năm trước, từ trước cả khi đặt chân lên bè. Hắn đã nghĩ tới nó không biết bao nhiêu đêm.

— Đệ tử nghe theo sư phụ dạy — hắn nói. — Chỉ cần có chút mùi đạo là đệ tử học.

— Môn ta có ba trăm sáu mươi bàng môn — Tổ sư nói. — Bàng môn nào cũng có chính quả. Ta dạy ngươi chữ thuật nhé? Thuật là cầu tiên, hỏi quẻ, xem lành dữ, biết trước điều sắp tới.

Biết trước điều sắp tới.

Hắn suýt bật cười. Hắn đã biết trước. Và biết trước chẳng làm hắn khỏi phải quét sân bảy năm.

— Học thế có sống lâu được không?

— Không được.

— Thế thì không học.

— Chữ lưu nhé? Lưu là các nhà học thuyết. Nho, Thích, Đạo, Âm Dương… Đọc kinh, niệm Phật, thờ thần.

— Học thế có sống lâu được không?

— Học thế — Tổ sư nói — như chôn cây cột trong tường. Nhà còn thì cột còn. Một ngày nhà sập, cột cũng mục.

— Thế thì không học.

— Chữ tĩnh nhé? Tĩnh là ngồi yên, nhịn ăn, nín thở, nhập định.

— Học thế có sống lâu được không?

— Như viên gạch mộc chưa nung trong lò. Trông cũng ra hình. Một trận mưa to là rã.

— Thế thì không học.

— Chữ động nhé? Động là luyện đan, hái thuốc, uống thứ này thứ kia, làm việc này việc nọ.

— Học thế có sống lâu được không?

— Như mò trăng đáy nước.

— Thế thì không học.

Hắn quỳ đó, trả lời từng câu. Hắn biết từng câu trả lời của mình. Đã biết từ lâu. Nhưng không câu nào là diễn. Hắn không muốn biết trước điều sắp tới, hắn đã biết rồi. Hắn không muốn đọc kinh, kinh không cứu được khỉ già. Hắn không muốn ngồi nín thở cho tới khi thành gạch mộc. Hắn không muốn mò trăng.

Hắn muốn không chết. Thế thôi.

Hắn đã mong muốn điều ấy từ trước khi biết nó có trong sách.

---

Tổ sư đứng bật dậy.

Ông quát một tiếng, không to, nhưng cả giảng đường im bặt. Ông bước xuống đài, cầm cây thước gỗ trong tay, đi thẳng tới chỗ hắn quỳ.

— Con khỉ này! Môn này không học, môn kia không học, ngươi muốn gì?

Ông giơ thước lên. Gõ vào đầu hắn.

Một cái.

Hai cái.

Ba cái.

Rồi ông chắp hai tay sau lưng, quay đi, bước vào cánh cửa giữa sau đài giảng. Cánh cửa đóng lại sau lưng ông. Bỏ cả giảng đường ngồi đó.

Im lặng một nhịp. Rồi cả giảng đường ầm lên.

— Con khỉ khốn kiếp!

— Thầy hỏi dạy gì thì học nấy, còn kén cá chọn canh!

— Làm thầy giận bỏ vào, giờ ai còn được học nữa!

Các đồng môn xúm lại, chỉ vào mặt hắn, mắng. Có người còn đẩy vai hắn. Cậu thư sinh gầy đứng ở rìa, nhìn hắn bằng ánh mắt lo lắng. Sư huynh mặt vuông ngồi nguyên chỗ cũ, không nói gì.

Hắn không cãi. Không cúi đầu xin lỗi. Cũng không cười.

Đầu hắn còn ê ẩm chỗ ba cái gõ. Hắn quỳ đó, để mọi người mắng, cho tới khi họ chán, tản đi.

---

Đêm ấy, hắn nằm trên chiếu, mở mắt nhìn trần nhà.

Hắn biết.

Ba cái gõ là canh ba. Chắp tay sau lưng là phía sau. Đóng cửa giữa là không đi lối chính. Canh ba đêm nay, đi cửa sau, vào gặp thầy. Hắn biết điều ấy từ khi còn là một người ngồi đọc sách ở một thế giới khác.

Hắn có thể đứng dậy ngay bây giờ. Chờ canh ba, rồi đi.

Đừng dùng chúng ở đây trước khi ngươi hiểu chúng.

Hắn nằm im.

Hắn hiểu được bao nhiêu? Hắn biết ba cái gõ nghĩa là canh ba vì sách viết thế. Nhưng tại sao lại là gõ đầu? Tại sao không nói thẳng? Tại sao phải để cả giảng đường mắng hắn là khỉ khốn kiếp?

Hắn bắt đầu nghĩ. Không phải nhớ. Nghĩ.

Thầy không nói thẳng vì có người nghe. Hơn ba chục đệ tử ngồi đó. Thứ thầy định dạy không phải thứ dạy giữa giảng đường. Không phải thứ ai nghe cũng được.

Vậy thầy phải nói một cách mà chỉ người cần nghe mới nghe ra.

Gõ đầu. Không phải gõ vai, gõ lưng. Gõ vào đầu, chỗ người ta nghĩ. Như bảo: nghĩ đi. Ba cái. Một con số. Trong đêm, người ta đếm giờ bằng canh. Canh ba là lúc tối nhất, lúc mọi người ngủ say nhất.

Chắp tay sau lưng. Không chỉ tay về phía nào, mà để tay ở sau. Phía sau.

Đóng cửa giữa. Cửa giữa là lối thầy vẫn đi, lối ai cũng thấy. Thầy đóng nó lại. Không đi lối ấy.

Và để cả giảng đường mắng. Vì nếu ai cũng hiểu, thì không cần giấu. Những người mắng hắn là những người chỉ thấy cái bề ngoài: thầy giận, thầy đánh, thầy bỏ đi. Thầy muốn xem có ai nhìn thấy cái ở sau cái bề ngoài ấy không.

Hắn nằm đó, từng chút một, tự giải từng cử chỉ. Bằng cái đầu của mình. Không phải bằng trang sách.

Rồi hắn nghĩ tới một điều khác. Nếu hắn không đi. Nếu hắn sợ mình chỉ biết mà chưa hiểu, nằm đây cho tới sáng. Có thể thầy sẽ không bao giờ hỏi lại. Có thể hắn sẽ quét sân thêm mười năm, như sư huynh mặt vuông.

Không đi cũng là một lựa chọn. Và nó cũng có giá.

Khi hắn nghe tiếng mõ canh vọng lên từ xa, báo sang canh ba, hắn đứng dậy.

---

Cửa sau phòng Tổ sư khép hờ.

Hắn lách vào, không phát ra tiếng động. Trong phòng tối, chỉ có ánh trăng nghiêng lọt qua cửa sổ. Tổ sư nằm trên giường, quay mặt vào trong, như đang ngủ.

Hắn quỳ xuống trước giường. Không gọi. Chờ.

Rất lâu. Lâu đến mức hắn bắt đầu nghĩ mình đã hiểu sai.

Rồi Tổ sư trở mình. Ông ngồi dậy, khẽ ngâm một câu gì đó, như tự nói với mình. Rồi ông nhìn xuống, thấy hắn quỳ đó.

— Con khỉ. Ngươi không ngủ ở ngoài kia, tới đây làm gì?

— Hôm nay trước giảng đường — hắn nói — sư phụ hẹn đệ tử canh ba, đi cửa sau, vào đây.

Tổ sư im lặng một lúc. Trong bóng tối, hắn không thấy rõ mặt ông. Chỉ thấy đôi mắt, bình thản như mặt nước giếng sâu.

— Ngươi tới vì biết — ông hỏi — hay vì hiểu?

Hắn đã nghĩ câu hỏi này sẽ tới. Hắn đã không chuẩn bị câu trả lời.

— Lúc trời vừa tối — hắn nói chậm rãi — là vì biết. Đệ tử biết từ trước. Sư phụ đã nhìn ra điều đó từ ngày đầu.

Hắn dừng lại.

— Nằm tới nửa đêm, đệ tử tự nghĩ. Vì sao sư phụ gõ đầu mà không nói. Vì sao chắp tay sau lưng. Vì sao đóng cửa giữa, để mọi người mắng. Đệ tử nghĩ là đã hiểu vì sao sư phụ phải giấu. — Hắn cúi đầu. — Nếu đệ tử chưa hiểu đủ, đệ tử xin chịu.

Im lặng kéo dài. Ngoài cửa sổ, gió lùa qua ngọn tùng.

— Biết là của sách — cuối cùng Tổ sư nói. — Hiểu là của ngươi.

Ông vỗ nhẹ lên mép giường.

— Lại gần đây.

---

Hắn quay về phòng ngủ khi trời còn chưa sáng.

Các đồng môn vẫn ngủ say. Hắn nằm xuống chiếu, kéo tấm chăn mỏng lên ngực, không nhắm mắt.

Trong đầu hắn, những lời Tổ sư vừa nói vẫn vang lên. Không nhiều. Một bài ngắn, đọc chậm, mỗi câu như khắc vào đá. Về tinh, về khí, về thần. Về cách giữ chúng, cách để chúng quay về với nhau, cách để thân thể không rò rỉ như một cái chum nứt. Hắn đã thuộc từng chữ. Hắn sẽ không bao giờ quên.

Hắn quay đầu nhìn bậu cửa sổ.

Bảy hạt đào nằm thành hàng, nhạt màu dưới ánh trăng nghiêng.

Hắn nghĩ tới bãi tiên thạch, tới ngày đầu tiên ngồi xếp bằng, đuôi mắc dưới mông, đầu trống trơn, không biết phải làm gì với hơi thở. Nghĩ tới lần ép khí, nôn ra cả mật xanh. Nghĩ tới những luật tự đặt, không đẩy, chỉ nhìn, cái bát đầy không chứa thêm được.

Hắn đã đi một mình trên con đường ấy gần chín năm.

Lần đầu tiên từ khi ra khỏi đá, có người chỉ cho hắn biết nước phải chảy về đâu.
