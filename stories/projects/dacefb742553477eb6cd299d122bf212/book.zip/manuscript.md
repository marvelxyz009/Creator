# Tái sinh Tề Thiên

## Chương 1 · Ngày đá biết đau

Hắn tỉnh lại vì không thở được.

Ngực bị ép chặt, hai cánh tay mắc trước mặt. Muốn duỗi chân cũng không có chỗ. Hắn quẫy trong bóng tối, đầu gối thúc phải một lớp vỏ cứng; từ chỗ ấy, tiếng rạn chạy lên sát tai.

Một khe sáng hé ra. Gió lùa vào, lạnh buốt và tanh mùi biển. Hắn dồn hết sức đạp thêm lần nữa.

Vỏ đá bật tung. Cả khối tròn bọc lấy hắn lăn khỏi hõm đá; vừa gặp gió, lớp vỏ còn lại đã tách ra. Hắn ngã sấp giữa những mảnh vụn, ho sặc sụa, hai tay quào trên mặt đá nóng.

Không khí tràn vào phổi. Hắn nằm như thế một lúc, thở đến đau cả ngực mới dám ngẩng đầu.

Một luồng sáng chói lòa qua mắt khiến hắn vội cúi xuống. Khi những đốm trắng trước mặt tan dần, biển hiện ra dưới chân núi, xanh thẫm đến tận chân trời. Sóng vỡ quanh các cột đá đỏ; xa hơn một chút, mây thấp mắc giữa những chóp núi, che khuất từng mảng rừng.

Trước mắt hắn đáng lẽ phải là một màn hình. Bên cạnh màn hình có cốc nước uống dở. Điện thoại vừa rung, hay đã rung từ lâu? Càng cố nhớ, những hình ảnh ấy càng rời rạc. Tiếng xe ngoài cửa sổ, một cái tên trên màn hình, ngón tay chưa kịp chạm vào nút nghe.

Rồi chẳng còn gì.

Hắn chống tay ngồi dậy, định nhìn xem người có bị thương không. Ánh mắt vừa chạm xuống mu bàn tay đã dừng lại.

Lông. Một lớp lông vàng nâu mọc từ cổ tay xuống tận các ngón.

Hắn lật bàn tay, sờ lên mặt. Đầu ngón chạm phải cái mõm nhô ra, rồi lớp lông ngắn phủ hai bên má. Sau lưng, có thứ vừa quét qua đá. Hắn ngoái lại; một cái đuôi dài cong lên theo động tác ấy.

Nắm lấy nó, kéo nhẹ, hắn lập tức nhăn mặt.

Của mình thật.

Hắn bật dậy. Ít nhất, hắn đã định bật dậy như một con người. Nhưng hai bàn chân quá dài, trọng tâm lại dồn về phía trước. Chưa đứng thẳng được, hắn đã ngã ngồi xuống một mảnh đá, đau đến ứa nước mắt.

Lần này hắn không vội đứng nữa.

Phía sau là khối đá lớn đã nứt toác. Những lỗ nhỏ rải quanh mặt đá, còn ở giữa là một hõm rỗng phủ bụi trắng. Hắn nhìn khối đá, nhìn biển, rồi cúi xuống lớp lông trên ngực mình.

Khỉ sinh ra từ đá.

Một cái tên vốn chẳng liên quan gì đến đời hắn bỗng trở nên gần đến đáng sợ.

*Tôn Ngộ Không?*

Hắn ngẩng nhìn trời. Ngoài vài con chim bay vòng trên bãi đá, không có gì khác. Không tiếng chuông, không ai xuống giải thích. Gió vẫn thổi; dưới kia, biển cứ đập vào chân núi.

Hắn đưa tay vuốt mặt lần nữa. Cái mõm vẫn còn đó.

Nếu thật sự là Ngộ Không, nơi này hẳn là Hoa Quả Sơn. Hắn sẽ tìm được một cái động sau thác, làm vua của đàn khỉ, vượt biển tìm Bồ Đề rồi học phép trường sinh. Sau đó còn gậy Như Ý, Long Cung, Thiên Đình…

Nghĩ đến Ngũ Hành Sơn, hắn vô thức co vai.

Năm trăm năm dưới một ngọn núi. Chỉ cần tưởng tượng không trở mình được trong một đêm, hắn đã thấy khó chịu. Năm trăm năm ấy tuyệt đối không thể cứ thế rơi xuống đầu mình.

Hắn nhìn về phía rừng. Trước hết phải tìm thác. Có nơi trú rồi mới tính chuyện ra biển; tìm được thầy càng sớm, hắn càng có thời gian chuẩn bị.

Một ý nghĩ khác chen vào. Thạch hầu vốn do tinh hoa trời đất sinh ra, biết đâu chỉ cần ngồi xuống đã có thể luyện công?

Hắn thử xếp bằng. Đuôi mắc dưới mông, chân phải không chịu nằm yên, còn trong đầu thì trống trơn. Những câu từng nghe trên phim chỉ nhớ được đôi chữ. Đôi chữ ấy không cho hắn biết phải làm gì với hơi thở đang ra vào lồng ngực.

Ngồi thêm cũng chẳng có ích. Hắn gỡ cái đuôi ra, chống tay lên đá rồi chậm rãi đứng dậy. Hai chân vẫn loạng choạng, nhưng khi hơi cúi người và để đuôi duỗi ra sau, hắn giữ được thăng bằng.

Thử bước một bước, rồi thêm bước nữa. Đến mép bãi đá, hắn đã đi được mà không phải nhìn xuống chân.

---

Đường xuống núi không khó tìm. Những khe đá nhỏ dẫn vào rừng, nơi bóng cây che mát và mùi đất thay dần mùi muối. Hắn men theo một lối giữa bụi rậm, thỉnh thoảng phải dừng lại gỡ gai khỏi lông.

Thân thể này khỏe hơn hắn tưởng. Chỉ hơi nhún chân đã nhảy qua được một gốc cây; khổ nỗi, cú nhảy xa quá khiến hắn chúi vào bụi lá bên kia. Lần sau hắn co chân ít hơn, đáp trúng phiến đá mình đã chọn. Cái đuôi tự vung ra để giữ người lại.

Hắn quay nhìn khoảng cách vừa vượt qua. Nếu trước kia, chắc phải lấy đà mới nhảy nổi.

Đang định thử lần nữa thì từ dưới rừng vọng lên một tiếng gọi gấp. Hắn chưa từng nghe thứ tiếng ấy, nhưng lại hiểu ngay lời cảnh báo.

*Đừng xuống!*

Một con khỉ đực nhảy lên cành thấp ngay trước mặt. Nó có bộ lông nâu sẫm, vành tai trái mất một mẩu. Vừa trông thấy hắn, nó khựng lại, bàn tay vẫn nắm cành phía trên, mắt liếc về đỉnh núi.

— Tiếng động trên ấy là gì?

Hắn định trả lời như thường lệ, nhưng tiếng phát ra khỏi miệng là một chuỗi âm ngắn và lạ. Con khỉ kia vẫn hiểu. Chính hắn cũng nghe ra nghĩa của chúng.

— Đá vỡ.

— Ngươi ở đó à?

Hắn phủi bụi trắng trên ngực.

— Vừa ra khỏi đó.

Con tai sứt nhìn hắn thêm một cái. Chưa kịp hỏi tiếp, nó đã quay phắt xuống dưới khi tiếng gọi lại vang lên. Lần này có cả tiếng đá lở.

Hắn chạy theo.

Qua vài bụi cây, mặt đất bỗng mở ra thành một khe sâu. Một cây lớn đứng sát bờ, rễ bò qua các kẽ đá rồi thòng xuống vách. Đất dưới gốc cây vừa sụp một mảng, để lộ lớp đá nhẵn bên trong.

Một khỉ con nằm co trên gờ đá phía dưới. Gờ chỉ vừa đủ chỗ cho nó; mỗi lần nó cựa, sỏi lại tuột khỏi chân, lăn mất vào bóng tối. Từ chỗ hắn đứng xuống đó khoảng hai thân khỉ. Còn từ gờ tới đáy khe, hắn không muốn đoán.

Khỉ mẹ lông nâu đỏ đang nằm sấp trên bờ, cố với xuống. Phía sau, một khỉ cái già giữ chặt chân bà, kéo ngược lại.

— Lùi lên! Bờ còn lở đấy!

Khỉ mẹ chẳng buồn nghe, cứ gọi con:

— Mầm! Nhìn mẹ này!

Khỉ con ngẩng đầu, kêu lên. Bàn tay nhỏ xíu cào trên đá nhưng không tìm được chỗ bám.

Con tai sứt lao tới một mỏm đất nhô ra gần gờ hơn.

— Để ta xuống.

Nó vừa đặt chân lên, đất đã trượt. Hắn túm cánh tay kéo nó lại, đúng lúc mỏm đất rời khỏi bờ, đập vào vách rồi vỡ tung.

— Ngươi làm gì thế? — Nó giằng tay.

Hắn chỉ xuống chỗ vừa lở.

— Muốn rơi cùng nó à?

Con tai sứt còn định nói, nhưng dưới chân khỉ con có tiếng rạn. Cả hai cùng quay lại. Một vết nứt mới chạy ngang gờ đá.

Hắn nhìn quanh tìm đường xuống. Bên trái, một lối đất chắc chạy khỏi mép khe rồi vòng lên sườn núi. Xa xa giữa lá cây có một dải trắng mờ; có thể là thác nước hắn đang tìm.

Chỉ cần đi theo lối ấy, hắn sẽ rời được chỗ này.

Khỉ mẹ vẫn không với tới con. Bàn tay bà quờ xuống rồi lại phải chống lên bờ đang rã, mỗi lần như thế khỉ con đều chồm về phía mẹ. Sớm muộn gì nó cũng trượt.

Hắn nhìn dải trắng lần nữa, rồi quay về gốc cây.

— Rễ nào bám chắc?

Khỉ già ngẩng đầu. Lông bà bạc xám, hai bàn tay vẫn ghì cổ chân khỉ mẹ.

— Cái lớn bên trái. Đừng nắm cái vỏ trắng.

Hắn kéo thử rễ bên trái. Lá trên cây rung lên, mấy hạt đất rơi ra từ vách, nhưng gốc rễ không nhúc nhích. Hắn dồn sức kéo thêm lần nữa.

— Ngươi giữ chỗ này giúp ta.

Con tai sứt nhìn xuống khỉ con, rồi bò lên một rễ ngang phía trên, chèn chân vào chạc rễ. Nó ôm đoạn rễ thòng sát gốc cây, thúc hắn:

— Xuống đi. Đưa nó lên ta đỡ.

Khỉ mẹ chồm tới định theo. Khỉ già kéo bà về phía đất chắc sau gốc cây.

— Sang đây đón con. Ngươi đứng trên đầu nó, đất lại rơi xuống.

Hắn bám rễ, xoay người ra ngoài vách. Gió từ đáy khe tạt lên làm lông trên ngực dựng cả lên. Đến lúc chân rời khỏi bờ, hắn mới thấy hai bàn tay mình ướt mồ hôi.

Rơi từ đây xuống thì thạch hầu có sống nổi không?

Hắn không muốn thử.

Bàn chân trái tìm được một chỗ lồi trên vách. Chân phải kẹp rễ; hắn dồn thử trọng lượng lên đó, thấy giữ được mới hạ tay xuống. Cứ thế, từng chút một, hắn xuống ngang gờ đá.

Khỉ con lập tức nhào tới.

— Khoan!

Đã muộn. Hai bàn tay nhỏ chộp lấy cổ tay phải hắn, kéo cả người lệch sang bên. Chân trái tuột khỏi chỗ bám. Vai trái va mạnh vào vách, đau đến tối sầm mắt.

Khỉ con treo ở tay hắn, chân cào loạn. Trên đầu, con tai sứt siết rễ, chửi một tiếng. Hắn cắn răng giữ tay trái, quờ chân tìm lại điểm tựa. Vỏ rễ cứa sâu vào lòng bàn tay phải.

— Lên vai ta! Đừng bám tay!

Khỉ con càng bấu chặt hơn. Hắn cúi xuống sát nó, nhưng cái cổ tay đang chịu cả sức nặng khiến ngón tay tê dần.

Tiếng khỉ mẹ vang lên từ trên bờ:

— Mầm, ôm cổ! Như bám mẹ ấy!

Nó nhìn lên. Một bàn tay rời khỏi cổ tay hắn, nắm lấy lông ngực, rồi bàn tay còn lại cũng buông. Nó trèo qua vai trái, vòng chân quanh cổ hắn. Chỗ vừa đập vào đá đau nhói, nhưng bàn tay phải đã nhẹ đi.

Hắn giữ người sát vách, chờ nó bám chắc rồi mới nhấc tay phải lên cao hơn. Da trong lòng bàn tay đã rách; máu làm rễ trơn hơn mỗi lần hắn đổi chỗ nắm.

Phải đưa nó lên trước khi tay mất sức.

Hắn đạp vào vách, kéo người lên một đoạn. Trên rễ ngang, con tai sứt thò tay xuống, nhưng khoảng cách vẫn còn quá xa. Hắn nhấc chân phải, kẹp vào khúc rễ cao hơn và kéo tiếp.

Gờ đá dưới họ gãy lìa.

Khỉ con siết cổ hắn. Hơi thở mắc lại trong ngực. Hắn không nhìn xuống; ngay trước mắt là bàn tay đang chìa ra của con tai sứt. Chỉ cần lên thêm một chút.

Những ngón tay nâu sẫm cuối cùng cũng khóa vào cẳng tay hắn.

— Buông một tay ra! Ta giữ được!

— Giữ rễ. Đỡ nó trước.

Con tai sứt lùi chân sâu vào chạc, đổi chỗ bám. Hắn rướn vai cho khỉ con với lên. Khỉ mẹ đã nằm đợi phía sau gốc cây; vừa chộp được cánh tay con, bà liền kéo nó vào lòng, còn con tai sứt đỡ chân nó qua rễ ngang.

Tiếng khóc nấc vang trên bờ. Hắn nghe mà biết ít nhất khỉ con đã thoát.

Tay phải gần như không còn cảm giác. Hắn bám bằng tay trái, dùng chân đẩy người lên; tới gần mép thì con tai sứt túm lông sau lưng kéo thêm. Hắn bò qua rễ ngang rồi nằm vật dưới gốc cây, thở hổn hển.

Máu từ lòng bàn tay nhỏ xuống lá khô. Vai trái vừa cử động đã đau.

Con tai sứt ngồi bên cạnh, cũng đang thở dốc.

— Ngươi nặng hơn ta tưởng.

Hắn nằm thêm một lúc mới đủ hơi đáp:

— Ta cũng chưa biết mình nặng thế.

Nó cúi nhìn hắn. Hắn khép mắt, để mặc nó nhìn. Chuyện sinh từ đá cứ để sau; lúc này, ngay việc ngồi dậy cũng phải tính.

---

Khỉ già trở lại với một nắm lá mềm.

— Bà Xám, tay nó chảy máu nhiều quá — Tai Sứt nói, nhường chỗ cho bà. Bà gỡ bụi quanh vết rách, đặt lá sạch vào tay hắn rồi khép các ngón lại.

— Ép lấy. Đừng mở ra xem mãi.

Hắn giữ bàn tay sát ngực. Lá mát, một lúc sau máu mới thấm ra ngoài, chậm hơn trước. Mẹ Mầm ngồi cách đó vài bước, ôm con trong lòng; khỉ con thỉnh thoảng giật mình, lại dụi mặt sâu hơn vào bụng mẹ.

Khỉ mẹ nhìn sang hắn. Bà cúi đầu khẽ, rồi bẻ một quả xanh đặt bên cạnh.

Hắn nhận bằng tay trái. Vị chua làm quai hàm tê đi, nhưng vừa nuốt miếng đầu đã nhận ra mình đói đến thế nào. Hắn ăn gần hết quả, chỉ bỏ lại phần sát hạt.

Con tai sứt đang phủi đất trên đùi bị khỉ già gọi lại:

— Lần sau đừng đứng lên mép ấy.

— Hôm qua ta vẫn đứng ở đó.

— Hôm qua có đứa nào rơi đâu.

Nó ngậm miệng. Hắn nhìn hai con khỉ, bỗng thấy cuộc cãi vã ấy quen hơn tất cả những gì đã gặp từ lúc ra đời.

Khỉ già gọi bầy. Những con trốn trong tán cây lần lượt xuống: khỉ lớn, khỉ nhỏ, vài con mẹ địu con trên bụng. Có con xuống đến nơi vẫn cố nhặt một quả rơi, bị giục mới vội chạy theo.

Hắn đếm được mười bảy con, rồi một tiếng gọi từ trên cành khiến phải ngẩng lên đếm lại.

Khỉ già tới trước mặt hắn.

— Ngươi đi với đàn nào?

Hắn nhìn về đỉnh núi đã khuất sau cây.

— Chưa có đàn.

Bà chờ thêm, nhưng hắn không biết giải thích thế nào mà khỏi bị xem là vừa ngã hỏng đầu.

— Vậy theo chúng ta. Còn đi được chứ?

Hắn chống tay trái đứng dậy. Chân hơi run, nhưng đã đỡ nhiều. Bà nhìn bàn tay phải hắn đang ôm trước ngực, rồi chỉ về lối bên trái.

— Đi sau ta. Thấy ta vòng chỗ nào thì vòng theo. Đừng chạy như Tai Sứt.

— Ta có chạy đâu! — Tiếng phản đối vọng xuống từ một cành cây.

Khỉ già chỉ liếc lên. Con tai sứt tụt xuống một cành thấp hơn, chờ bầy đi qua rồi mới theo.

Hắn bước sau bà, thỉnh thoảng phải quay bàn tay để chỗ rách khỏi cọ vào ngực. Nếu đúng là Ngộ Không, thương tích này hẳn chẳng đáng gì so với những thứ sẽ phải chịu sau này. Nhưng hắn vẫn ước lúc kéo khỉ con lên, mình đã chọn được chỗ nắm khác.

Làm sao học phép càng sớm càng tốt? Hắn nghĩ lại đến câu hỏi ấy khi đàn khỉ bắt đầu leo lên một dốc thấp. Trong ngực có hơi ấm lan ra sau khi ăn, nhưng hắn không biết đó là linh khí hay chỉ vì vừa đỡ đói. Công pháp chưa có; ngay đến phương hướng vượt biển cũng mới là mấy dòng nhớ mang máng.

Khỉ Xám dừng trước một thân cây nghiêng về phía khe. Trên vỏ cây có ba vết cào dài, cao hơn đầu bà. Bà ngửi rồi kéo Tai Sứt khỏi lối bên phải, dẫn cả đàn vòng qua một tảng đá chẻ đôi.

Hắn ghi nhớ tảng đá, nhớ cả bụi quả đỏ bên cạnh mà không con nào hái. Chỗ này không có trong trí nhớ về Tây Du. Từng lối đi, từng thứ ăn được, hắn vẫn phải học lại từ đầu.

---

Đến vũng nước, Khỉ Xám đột ngột đứng lại.

Tai Sứt nhảy xuống tảng đá bên bờ, cúi người rồi cũng dừng. Hắn bước tới sau nó và thấy đáy vũng đã lộ ra, lá mục dính thành mảng trên lớp bùn đen. Chỉ ở chỗ sâu nhất còn một hõm nước đục, nổi đầy xác côn trùng.

— Sáng còn nước mà. — Tai Sứt nhìn ngược lên lòng suối.

Khỉ Xám cúi sờ bùn. Lớp mặt đã se, nhưng bên dưới còn mềm. Bà xua mấy khỉ nhỏ đang muốn xuống uống, đẩy chúng về phía các con mẹ.

Hắn nhìn vệt ẩm trên đá. Nước trước đó cao hơn rất nhiều; chẳng biết vì sao lại rút nhanh đến thế.

Ngay cạnh hõm nước cuối cùng có một dấu chân lớn. Hắn xòe tay trái bên cạnh để so, thấy dấu ấy rộng hơn cả bàn tay. Đầu mỗi ngón hằn một lỗ nhọn, nước đang rịn trở lại một trong những lỗ đó.

Chưa cũ.

Hắn nhìn lên bờ, tìm được dấu thứ hai đè trên lá và một cành thấp vừa gãy. Mặt gãy còn sáng màu. Dấu chân hướng ngược lên lòng suối, nhưng hai dấu ấy chưa đủ cho hắn đoán con vật đi một mình hay theo đàn.

Tai Sứt đã nhặt một hòn đá.

— Ta lên xem.

Khỉ Xám chắn trước mặt nó.

— Không đi một mình. Đến cây gãy thì quay về.

Hắn ngẩng lên. Cách đó không xa, một thân cây đổ ngang suối; bên kia, lòng suối khuất sau các tảng đá lớn.

Mầm lại kêu. Mẹ nó đang dỗ, nhưng khỉ con cứ với tay về phía vũng. Mấy con nhỏ khác cũng nhìn hõm nước, bị giữ lại thì bắt đầu nhốn nháo.

Hắn có thể hỏi Khỉ Xám về dải trắng mình thấy trên sườn núi. Nếu là thác, có lẽ nước ở đó chưa cạn. Nhưng bà biết lối quanh đây, còn hắn mới chỉ nhìn được từ xa; muốn đem cả đàn đi, trước hết cũng phải biết có đường tới nơi hay không.

— Ta đi cùng nó — hắn nói.

Khỉ Xám nhìn chiếc lá đã thấm máu trong tay hắn.

— Leo được nữa không?

— Chỉ xem rồi về. Chỗ nào phải leo thì để nó lên.

Tai Sứt xoay hòn đá trong tay.

— Nếu gặp con để lại dấu này?

Hắn nhìn những lỗ móng cạnh vũng nước.

— Chạy. Đừng ném đá vào nó.

Khỉ Xám chìa tay. Tai Sứt chần chừ một lát mới đặt hòn đá vào đó.

— Xem nước chảy đi đâu — bà dặn. — Đừng qua cây gãy.

Tai Sứt bước vào lòng suối trước. Hắn theo sau, tránh chạm bàn tay phải xuống đá, mắt nhìn hai bên bờ tìm thêm dấu chân. Khi tới một đoạn đá trơn, hắn đợi Tai Sứt đi qua rồi mới đặt chân vào đúng chỗ nó vừa đứng.

Phía sau vẫn còn tiếng gọi khát nước của lũ khỉ nhỏ. Hắn quay lại, thấy mẹ Mầm bẻ phần quả còn sót, đưa cho con ngậm.

Hắn siết chiếc lá trong tay, bước tiếp.

Công pháp, trường sinh, Thiên Đình… những việc ấy chưa đi đâu cả. Nhưng trước khi trời tối, hắn cần biết nước ở ngọn núi này đã chảy về đâu.


# Tái sinh Tề Thiên

## Chương 2 · Đàn khỉ không chờ vua

Lòng suối cạn đi lên dốc, mỗi đoạn lại hẹp thêm một chút.

Tai Sứt đi trước, nhảy từ tảng đá này sang tảng đá khác như thể chân nó tự biết chỗ nào chắc. Hắn theo sau, chậm hơn nhiều. Bàn tay phải vẫn ôm trước ngực, nên mỗi lần phải bám, hắn chỉ còn tay trái, hai bàn chân và cái đuôi. Cái đuôi ấy giờ đã chịu nghe lời hơn lúc mới ra khỏi đá; lúc hắn chao người trên một hòn đá tròn, nó tự quấn lấy mỏm đá bên cạnh, giữ hắn lại trước khi hắn kịp nghĩ.

— Đi chậm thế thì tối mất. — Tai Sứt ngoái lại, đứng chờ trên một tảng đá cao.

— Ngươi có hai tay.

— Ngươi có cái đuôi dài hơn ta.

Hắn không cãi nữa. Nói thêm câu nào cũng phải thở, mà leo dốc thì hơi thở không thừa.

Hai bên bờ, vệt rêu khô vẽ thành một đường ngang trên đá, cao gần tới ngực hắn. Nước từng chảy đến tận đó. Giờ lòng suối chỉ còn những hốc bùn se mặt, vài con cá nhỏ nằm cứng đờ giữa lá mục. Mùi tanh bốc lên mỗi khi gió lặng.

Ở một khúc quanh, hắn dừng lại. Trên mặt bùn có thêm một dấu móng, giống hệt dấu ở vũng nước, mũi chân vẫn hướng lên thượng nguồn. Cạnh đó, trên cạnh sắc của một tảng đá, mắc vài sợi lông thô, màu sẫm như vỏ cây ướt. Hắn nhón lấy một sợi bằng tay trái. Sợi lông cứng và dài hơn ngón tay hắn, đầu hơi xoăn.

Không phải lông khỉ.

Tai Sứt nhảy xuống bên cạnh, ngửi sợi lông rồi nhăn mũi.

— Hôi.

— Ngươi từng ngửi mùi này chưa?

Nó nghĩ một lúc.

— Có thể rồi. Mùa trước, bên sườn cây cào. — Nó liếc về phía tay phải, nơi rừng dày lên thành một mảng tối. — Bà không cho tới đó.

Hắn thả sợi lông xuống, nhìn theo dấu chân. Con vật đi ngược suối, cùng hướng với dòng nước đã biến mất. Nếu nó khát, nó sẽ đi tìm nước. Nếu nó đi tìm nước, chỗ nó tới cũng là chỗ đàn khỉ cần.

Ý nghĩ ấy không làm hắn yên tâm hơn chút nào.

---

Cây gãy hiện ra khi bóng chiều đã ngả dài qua lòng suối.

Đó là một thân cây lớn đổ chéo từ bờ trái sang bờ phải, rễ bật tung lên như một bàn tay xòe ngửa, đất bám ở rễ đã khô thành tảng. Thân cây cao hơn đầu hắn, vỏ bong từng mảng. Phía bên kia, lòng suối khuất sau mấy tảng đá to như mái nhà.

Hắn vừa tới gần thì nghe thấy.

Tiếng nước. Rất khẽ, lẫn trong tiếng lá, nhưng đúng là tiếng nước chảy, đều đều ở đâu đó phía trên.

Tai Sứt cũng nghe. Tai nó vểnh lên, cả người đã nghiêng về phía thân cây.

— Có nước.

— Bà bảo đến cây gãy thì quay về.

— Bà bảo thế vì bà không biết bên kia có nước. — Tai Sứt đặt tay lên vỏ cây. — Ta qua xem rồi về ngay. Ngươi đợi ở đây.

Hắn nhìn thân cây. Trèo qua không khó, ngay cả với một tay. Bên kia có tiếng nước, và ở đâu đó trên sườn núi có dải trắng hắn đã thấy lúc đứng bên khe. Nếu đúng là thác, nếu sau thác có động, thì chỉ cần qua cây gãy là hắn đã đi được nửa đường tới thứ mình biết chắc sẽ có.

Mình biết chắc thật không?

Hắn nhớ những vết cào trên thân cây nghiêng, nhớ bà Xám đã kéo Tai Sứt khỏi lối bên phải mà chẳng cần giải thích. Trong trí nhớ của hắn không có cái cây nào như thế, cũng không có dấu móng rộng hơn bàn tay. Trong trí nhớ của hắn, khỉ đá chỉ cần nhảy qua thác là thành vua.

— Không qua — hắn nói.

Tai Sứt quay lại, mắt mở to.

— Ngươi sợ à?

— Ta không biết bên kia có gì. Ngươi cũng không biết. Gặp nó ở chỗ hẹp, ngươi chạy được, ta thì chạy bằng một tay.

— Thế thì ngươi đợi.

— Rồi về nói với bà thế nào? Rằng ta đứng nhìn ngươi đi?

Tai Sứt mím miệng. Nó nhìn thân cây, rồi nhìn tay phải đang ôm lá của hắn, rồi lại nhìn thân cây.

Hắn nắm một cành chĩa ra từ thân cây đổ, kéo người lên. Tay trái gồng, chân kẹp vỏ cây, đuôi quấn quanh một mấu gỗ. Hắn không bước sang bờ bên kia, chỉ ngồi xổm trên thân cây, ở chỗ cao nhất.

Từ đó, hắn nhìn được qua mấy tảng đá lớn.

Lòng suối phía trên vẫn khô. Đá trắng bạc dưới nắng chiều, cành khô mắc thành từng đống. Xa hơn một đoạn, ở chỗ lòng suối uốn sang trái, có một vệt sáng lấp lánh. Nước. Nhưng nước không chảy xuống phía hắn. Nó rẽ ngang, đổ vào một khe đá bên phải rồi mất hút sau sườn núi.

Ngay chỗ rẽ, đá và cành cây chất thành một đống ngổn ngang, chắn ngang dòng cũ. Từ xa thế này, hắn không nhìn ra đống ấy do đất lở xuống hay do thứ gì kéo tới. Hắn chỉ thấy nó cao, và nước đã tìm đường khác.

— Thấy gì? — Tai Sứt hỏi từ dưới.

— Nước còn. Nhưng nó chảy đi chỗ khác.

— Chỗ nào?

Hắn chưa kịp trả lời thì một hòn đá lăn xuống ở phía trên, va vào đá khác, lộc cộc một hồi dài. Rồi im. Trong cái im ấy có một tiếng thở, nặng và chậm, như hơi phì ra từ một lồng ngực rất lớn.

Lông trên gáy hắn dựng đứng.

Hắn không thấy gì cả. Chỉ có đá, cành khô và bóng chiều. Nhưng tiếng thở ấy vang lên lần nữa, gần hơn, hoặc hắn tưởng là gần hơn.

Hắn tụt xuống khỏi thân cây, gần như rơi, chân đáp xuống cạnh Tai Sứt.

— Về.

Lần này Tai Sứt không cãi.

---

Họ về tới vũng nước khi trời đã chuyển màu tím xám.

Vũng trống trơn.

Hõm nước đục cuối cùng vẫn nằm đó, xác côn trùng vẫn nổi. Nhưng trên bờ không còn con khỉ nào. Không bà Xám, không mẹ Mầm, không lũ khỉ nhỏ kêu khát. Chỉ có dấu chân khỉ giẫm lẫn lộn trên bùn và vài vỏ quả bị vứt lại.

Hắn đứng giữa bờ vũng, nhìn quanh. Một cảm giác lạ chạy qua ngực, không hẳn là sợ. Giống như ở đời trước, đến muộn một buổi hẹn, đẩy cửa vào thì phòng đã tắt đèn.

— Đi rồi.

— Ừ. — Tai Sứt đã cúi xuống bên một bụi cây ở rìa bờ, chẳng có vẻ gì ngạc nhiên.

— Không đợi chúng ta?

— Đàn không chờ ai. — Nó nói như thể hắn vừa hỏi vì sao nước lại ướt. — Trời tối rồi. Lũ nhỏ khát.

Nó vạch một cành thấp ra cho hắn xem. Cành bị bẻ gập ngang giữa, chưa gãy hẳn, đầu cành chĩa về phía tay trái.

— Bà để lại đấy. Đi theo hướng này.

Hắn nhìn cành cây gập ấy một lúc lâu. Lúc mới ra khỏi đá, hắn còn nghĩ chuyện làm vua đàn khỉ, chuyện dẫn cả bầy vào động. Giờ cả bầy đã đi mất mà không cần hỏi ý hắn. Họ để lại cho hắn một cái cành bẻ cong, đúng như để lại cho Tai Sứt, không hơn.

Hắn bật cười một tiếng, khô khốc.

— Cười gì?

— Không có gì. Đi thôi.

Đi trong rừng lúc chạng vạng khó hơn hắn tưởng. Bóng cây hòa vào nhau, rễ nổi lên chỗ nào cũng giống đá, đá chỗ nào cũng giống rễ. Tai Sứt đi trước, cứ vài chục bước lại dừng, sờ tay lên một cành cây ngang tầm mắt. Lần nào cũng thấy một cành bẻ gập. Có lần nó tìm mãi không thấy, phải đi vòng ba lượt mới gặp một bụi cỏ bị vặn xoắn ở gốc.

— Sao ngươi biết cái này là của bà? — hắn hỏi.

— Bà bẻ thấp. Mẹ Mầm bẻ cao hơn, bẻ đứt luôn. — Tai Sứt lại dừng, chỉ một cành. — Kia, đứt. Mẹ Mầm.

Hắn nhìn mãi mới thấy cái cành đứt ấy. Nếu chỉ có một mình, chắc giờ này hắn vẫn còn đứng ở vũng nước.

Bàn tay phải bắt đầu nhức theo nhịp tim. Lá ép đã khô, dính vào vết thương. Hắn không dám gỡ ra, chỉ siết nhẹ các ngón lại như bà Xám dặn.

---

Chỗ đàn dừng chân là một vách đá thấp dưới tán cây lớn.

Trăng mỏng đã lên, đủ để hắn thấy mặt vách phủ một lớp rêu sẫm, ẩm và bóng. Từ khe đá trên cao, nước rỉ ra thành giọt, nhỏ xuống một hõm đá dưới chân vách. Mỗi giọt rơi kêu một tiếng tách rất nhỏ. Hõm đá chỉ to cỡ vài lòng bàn tay, nước trong đó chưa đầy một ngụm.

Cả đàn ngồi quanh vách, im lặng hơn hắn từng nghe. Mẹ Mầm đang cúi bên hõm nước, Mầm áp mặt cạnh mẹ, cái lưỡi nhỏ liếm liếm mặt đá ướt. Sau họ là hai con mẹ khác địu con, rồi mấy khỉ nhỏ ngồi xếp hàng không ra hàng, đứa nào cũng nhìn chằm chằm vào hõm nước.

Bà Xám ngồi trên một mỏm đá ngay cạnh vách. Thấy hai đứa về, bà chỉ nhìn qua từ đầu đến chân, như đếm xem có thiếu gì không.

— Về rồi. Ngồi đó.

Bà hất cằm về phía cuối hàng.

Hắn ngồi xuống. Cổ họng khô rát từ lúc leo dốc, càng nghe tiếng nước nhỏ giọt lại càng khát. Hắn nhìn một khỉ đực to con ngồi trước mình, nó cũng chẳng chen lên, chỉ chờ.

Mẹ trước, con nhỏ trước, rồi đến già, rồi đến đực. Kẻ mới đến ngồi cuối. Không ai nói ra luật ấy, nhưng hắn nhìn một lúc là hiểu.

Tai Sứt ngồi xuống cạnh hắn, gãi tai.

— Ngươi đi trước ta được mà — hắn nói nhỏ.

— Hôm nay ta đi xa với ngươi. Bà bảo ngồi cuối thì ngồi cuối.

Trong lúc chờ, bà Xám gọi hắn lại gần.

— Nói đi. Thấy gì?

Hắn kể. Dấu móng thứ ba, sợi lông thô, mùi hôi mà Tai Sứt bảo giống mùi bên sườn cây cào. Cây gãy, tiếng nước. Chỗ nước rẽ vào khe đá bên phải, đống đá và cành ở chỗ rẽ. Tiếng đá lăn và tiếng thở.

— Thấy con vật không?

— Không.

— Đống đá ấy, ở bên này hay bên kia cây gãy?

— Bên kia. Xa hơn một đoạn.

— Ngươi có qua không?

Hắn liếc sang Tai Sứt. Tai Sứt nhìn đi chỗ khác.

— Không. Ta trèo lên thân cây để nhìn.

Bà Xám im lặng một lúc. Tiếng nước tách, tách sau lưng bà.

— Được.

Chỉ một chữ. Hắn không biết bà khen hay chỉ ghi nhận, nhưng cái nhìn của bà đã bớt đi chút gì đó dè chừng.

Hắn nuốt khan, rồi nói tiếp điều đã định hỏi từ lúc ở vũng nước:

— Trên sườn núi phía kia có một dải trắng. Từ chỗ khe lúc cứu Mầm nhìn sang. Có thể là thác. Nếu có thác thì có nước.

— Ta biết chỗ đó.

Hắn khựng lại.

— Bà biết?

— Muốn tới đó phải qua sườn cây cào. Mùa trước có hai đứa đi. — Bà nói đều đều, như kể chuyện quả chín muộn. — Một đứa về.

Bà nhìn bàn tay phải của hắn.

— Ngươi thấy từ xa. Ta đi qua rồi.

Hắn không nói được gì. Cả ngày nay hắn vẫn nghĩ dải trắng ấy là bí mật chỉ mình hắn biết, là con đường hắn sẽ dẫn đàn đi. Hóa ra bà đã biết từ trước khi hắn ra đời, và bà có lý do để không đi.

— Đá này — bà gõ ngón tay lên vách ẩm — mùa khô nào cũng khóc. Ban ngày khóc ít, ban đêm khóc nhiều. Đủ cho lũ nhỏ. Không đủ cho cả đàn lâu.

— Bao lâu?

— Đến khi rêu khô.

Hắn nhìn lớp rêu trên vách. Ở mép dưới, rêu đã ngả màu nâu.

Khi đến lượt hắn, hõm đá đã cạn gần hết. Hắn cúi xuống, liếm lớp nước mỏng còn đọng ở đáy, rồi chờ thêm ba giọt nữa mới có được một ngụm nhỏ. Nước lạnh và có vị đá. Nó không làm hết khát, nhưng cổ họng bớt rát.

Tai Sứt chờ sau hắn. Hắn nhích sang, nhường chỗ.

---

Cả đàn ngủ trên cây lớn cạnh vách.

Hắn chọn một chạc ba khá chắc, kê lưng vào thân cây, quấn đuôi quanh một cành để khỏi trượt. Tai Sứt leo lên chạc bên cạnh, cao hơn hắn một chút. Dưới kia, vẫn nghe tiếng nước tách tách.

Ngủ không được. Bàn tay nhức, vai trái đau mỗi lần cựa. Còn đầu hắn thì cứ quay về cái đống đá chắn dòng, về tiếng thở trong bóng chiều.

— Này. — Giọng Tai Sứt vọng xuống. — Sao lúc ấy ngươi không qua?

— Ta nói rồi.

— Ngươi nói là không biết bên kia có gì. — Nó cựa mình, cành cây kêu cót két. — Nhưng ngươi to hơn bà. Ngươi kéo được cả ta với Mầm lên khe. Sao lại nghe bà?

Hắn nghĩ một lúc. Có rất nhiều câu trả lời. Vì trong trí nhớ của hắn chưa từng có con vật nào để lại dấu như thế. Vì hắn mới sống được một ngày. Vì nếu Tai Sứt chết ở bên kia cây gãy, hắn sẽ phải nhìn bà Xám mà kể lại.

— Vì bà biết chỗ này. Ta thì không.

— Ngươi sẽ biết.

— Ừ. Nhưng chưa phải hôm nay.

Tai Sứt không nói gì nữa. Một lúc sau, hắn nghe nó trở mình, thở đều. Nó vẫn nằm ở chạc cây ấy, cách hắn chưa tới một sải tay.

Hắn nhắm mắt, thử thở như lúc mới ra khỏi đá, khi còn ngồi xếp bằng trên bãi đá. Hít vào, chậm, để không khí xuống tận bụng. Thở ra. Trong ngực vẫn có hơi ấm mơ hồ, ở đâu đó sau xương ức, nhưng chẳng biết là linh khí hay chỉ là cơ thể đang cố giữ nhiệt trong đêm. Hắn thử dồn chú ý vào chỗ ấm. Vai trái nhói lên một cái, mọi thứ tan biến.

Hắn mở mắt, nhìn lên. Qua tán lá, trời đầy sao, nhiều đến mức hắn chưa từng thấy ở đời trước.

Thác, động, thầy, phép trường sinh. Kế hoạch ấy vẫn còn đó. Chỉ là giờ nó có thêm một điều kiện mà lúc ở bãi đá hắn chưa hề nghĩ tới: đàn khỉ này phải sống được đến lúc đó. Mà muốn chúng sống, trước hết phải có nước khi rêu trên vách khô.

---

Sáng hôm sau, đàn đi kiếm ăn từ lúc sương chưa tan.

Bà Xám dẫn đầu, theo một lối hắn nhận ra là lối hôm qua: qua thân cây có ba vết cào, vòng quanh tảng đá chẻ đôi. Bụi quả đỏ vẫn ở đó, trĩu quả, đỏ au dưới nắng sớm. Đàn đi qua mà không con nào ngoái lại.

Hắn chậm bước.

Cả bụi chưa ai động tới. Trong khi các cây khác quanh đây đã bị vặt trụi tới tầm khỉ với được, bụi này vẫn nguyên. Hôm qua hắn để ý nhưng chưa nghĩ ra vì sao. Giờ bụng đói, hắn nghĩ ra một lời giải có vẻ hợp lý: có lẽ quả này mọc chỗ trống, khỉ sợ bị chim săn để ý, nên bỏ qua. Mà bỏ qua thì càng nhiều.

Hắn với tay trái, ngắt một chùm.

Bên cạnh, một khỉ nhỏ chẳng biết đã đi theo từ lúc nào, thấy hắn hái cũng lập tức chồm lên với tay vào bụi.

Một cái bóng xám lao tới. Bà Xám gạt phăng tay khỉ nhỏ, rồi đập mạnh vào cổ tay trái của hắn. Chùm quả rơi xuống đất, lăn mấy vòng.

— Ném đi.

Hắn sững người. Cả đàn đã dừng lại, quay nhìn.

— Ta chỉ…

— Ăn vào thì đau bụng. Nôn cả đêm. — Bà vẫn giữ cổ tay khỉ nhỏ, giọng không to nhưng ai cũng nghe rõ. — Năm trước một đứa ăn. Sáng ra không dậy nữa.

Khỉ nhỏ rụt tay, chạy về sau lưng một con mẹ.

Hắn nhìn chùm quả đỏ dưới đất. Mặt nóng lên dưới lớp lông. Hắn đã tự nghĩ ra cả một lý do nghe rất thông minh. Lý do ấy suýt nữa giết một đứa nhỏ chỉ biết bắt chước hắn.

— Ta không biết — hắn nói.

— Giờ biết rồi. — Bà buông tay, quay đi. — Không biết thì hỏi. Hoặc nhìn đàn ăn gì.

Tai Sứt đi ngang qua, chẳng nói gì, chỉ liếc hắn một cái. Cái liếc ấy còn khó chịu hơn một lời chê.

---

Bà dẫn đàn tới một cây lớn mọc giữa khoảng rừng thưa. Dưới gốc rụng đầy những hạt nâu to cỡ đầu ngón cái, vỏ dày và cứng.

Đàn tản ra. Khỉ lớn lùng sục quanh gốc, tìm những hạt đã nứt sẵn hoặc bị sâu đục, cạy ruột ra ăn. Khỉ nhỏ cắn thử hạt nguyên, gặm mãi không thủng, đành vứt đi. Mầm cầm một hạt, xoay xoay trong tay, đưa lên miệng cắn, rồi nhăn mặt nhìn mẹ.

Hắn nhặt một hạt, bóp thử bằng tay trái. Cứng như đá cuội.

Hạt nguyên nằm đầy dưới gốc, hạt nứt sẵn thì ít. Cả đàn đang đói ngồi giữa một đống thức ăn không cắn được.

Hắn nhìn quanh. Cách gốc cây vài bước có một tảng đá phẳng, mặt hơi lõm. Hắn đi tới, đặt hạt lên chỗ lõm, rồi nhặt một hòn đá cỡ nắm tay.

Ở đời trước, hắn từng xem một đoạn phim về những con khỉ ở xa lắm, dùng đá đập hạt bên bờ sông. Hắn chỉ nhớ có thế. Không nhớ chúng cầm đá thế nào, kê hạt ra sao.

Tay phải không dùng được. Hắn ngồi xổm, dùng ngón chân trái giữ hạt cho khỏi lăn, tay trái giơ đá lên, đập xuống.

Hạt bắn ra khỏi chỗ lõm. Đá đập trúng ngón chân cái.

Hắn rít lên một tiếng, ôm chân. Mấy con khỉ gần đó ngẩng lên nhìn. Tai Sứt, đang ngồi cạy một hạt nứt dở trên cành thấp, phát ra một tiếng nghe như cười.

Hắn không nhìn lên. Nhặt hạt lại, đặt vào chỗ lõm, lần này xoay cho phần đầu nhọn chúc xuống, để chỗ lõm giữ nó. Ngón chân lùi ra xa hơn, chỉ chặn ở mép. Đập nhẹ hơn.

Cạch. Hạt chưa vỡ, nhưng đã có một vết nứt chạy dọc.

Lần thứ ba, vỏ tách đôi. Bên trong là một nhân trắng ngà, to gần bằng cả hạt.

Hắn nhặt lên, cho vào miệng. Ngậy, hơi chát ở vỏ lụa. Ngon hơn quả chua hôm qua nhiều.

Khi hắn ngẩng lên, Mầm đã ngồi ngay trước mặt, cách chỉ một sải tay. Hai mắt tròn xoe nhìn hòn đá trong tay hắn. Đằng sau Mầm, hai khỉ nhỏ khác cũng đã bò lại gần, rồi một con mẹ.

Hắn đặt thêm một hạt lên đá, đập. Lần này chỉ hai cú. Hắn bẻ đôi nhân, đưa một nửa cho Mầm.

Mầm nhìn mẹ. Mẹ Mầm ngồi xuống cạnh con, không ngăn. Khỉ con cầm lấy, ngửi, rồi nhét cả vào miệng.

Sau đó thì chẳng còn ai cạy hạt sâu nữa.

Hắn đập cho đến khi cổ tay trái mỏi nhừ. Lũ khỉ nhỏ nhặt hạt nguyên mang tới, chất thành đống bên cạnh tảng đá. Mấy con lớn đứng xem một lúc rồi cũng tìm đá thử. Phần lớn đập trượt, có con đập vỡ nát cả nhân, có con giữ hạt bằng tay rồi đập trúng tay, kêu toáng lên.

Tai Sứt tụt xuống từ cành cây từ lúc nào. Nó ngồi xổm cạnh hắn, nhìn hắn đập thêm hai hạt.

— Chậm quá — nó nói. — Ta làm nhanh hơn.

— Làm đi.

Nó tìm một tảng đá khác, nhặt một hòn đá to gấp đôi hòn của hắn, đập xuống một cú. Hạt vỡ vụn, nhân văng tung tóe. Nó nhìn đống vụn, rồi nhìn hắn.

— Nhỏ tay thôi — hắn nói. — Đầu nhọn chúc xuống.

Tai Sứt hừ một tiếng. Nhưng hạt tiếp theo, nó xoay đầu nhọn xuống, đập nhẹ hơn. Vỏ tách đôi gọn gàng. Nó cầm nửa hạt lên, nhìn rất lâu như không tin.

— Dễ thế à?

— Ngươi tự làm đấy chứ.

Đến khi nắng lên quá ngọn cây, Tai Sứt đã đập nhanh hơn hắn thật. Hai tay nó đều lành, nó dùng tay giữ hạt rồi rụt tay ra đúng lúc đá rơi xuống. Hắn nhìn mà vừa buồn cười vừa hơi tức.

---

Bà Xám gọi cả đàn lại quanh đống nhân hạt.

Bà chia. Không ai giành. Mẹ và con nhỏ trước, rồi đến khỉ già, rồi các con khác theo thứ tự hắn đã thấy ở vách đá đêm qua. Hắn ngồi cuối như đêm qua, không đòi gì.

Đến lượt hắn, bà đặt vào lòng bàn tay trái hắn một nắm nhân. Nắm ấy không nhiều hơn của Tai Sứt, cũng không ít hơn. Bằng phần của một con khỉ đã làm việc cả buổi sáng.

— Mai — bà nói — ngươi với Tai Sứt dạy lũ nhỏ đập. Ta không muốn ngón tay chúng gãy hết.

Chỉ thế. Bà không hỏi hắn từ đâu tới, cũng không gọi hắn bằng tên gì khác ngoài “ngươi”. Nhưng hắn ngồi nhìn nắm nhân trong tay khá lâu mới ăn.

Mầm bò tới, ngồi sát chân hắn, chìa tay. Hắn cho nó hai hạt. Mẹ Mầm nhìn sang, rồi ngồi dịch lại gần thêm một chút.

---

Gần trưa, đàn quay về vách đá để uống.

Bà Xám đi trước. Đến gốc cây lớn, bà dừng lại đột ngột, giống hệt hôm qua bên bờ vũng nước. Cả đàn phía sau dồn lại.

Hắn lách lên.

Dưới chân vách, lớp bùn quanh hõm đá đã bị giẫm nát. Hõm nước khô khốc, đến đáy cũng không còn ẩm. Mép đá quanh hõm có vệt trơn bóng, như đã bị liếm đi liếm lại nhiều lần. Lớp rêu thấp nhất trên vách bị cào toạc một mảng, rủ xuống thành từng sợi.

Giữa bùn là một dấu chân. Rộng hơn bàn tay hắn, đầu mỗi ngón hằn một lỗ nhọn.

Cạnh đó, dấu thứ hai, rồi thứ ba, nối nhau đi về phía sườn cây cào, nơi rừng dày lên thành một mảng tối.

Không ai lên tiếng. Lũ khỉ nhỏ nhìn hõm đá khô, rồi nhìn mẹ. Mầm kêu khẽ một tiếng.

Bà Xám cúi xuống, đặt bàn tay vào trong dấu chân. Bàn tay bà chỉ chiếm được một nửa.

— Nó cũng khát — bà nói.

Hắn nhìn những dấu chân dẫn về sườn cây cào, rồi quay lại nhìn về phía thượng nguồn, nơi hôm qua hắn đã thấy nước rẽ vào khe đá. Nước ở ngọn núi này không biến mất. Nó đã chảy sang chỗ khác.

Và giờ, thứ để lại dấu chân này cũng đang tìm nước, ở đúng những chỗ đàn khỉ cần.
